/*
�D�q���t��ƪ��R���A�q�L�b�ݭn���p�R�������W�j�wĲ�o����{�C
*/
IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.tdiu_bacr003'))
   DROP TRIGGER dbo.tdiu_bacr003
GO
CREATE TRIGGER dbo.tdiu_bacr003 ON bacr003 
FOR DELETE, INSERT, UPDATE
AS
BEGIN
	
	with opbacr003(item_no, pk_id) as
	(
		select item_no=b.mst_no, pk_id = isnull((select min(pk_id) from bacr003 where bacr003.mst_recid=b.mst_recid and bacr003.file_type='1'), 0)
		from inserted b
	)
	update dbo.bacr005
	set bacre05 = opbacr003.pk_id
	from opbacr003
	where bacr005.item_no = opbacr003.item_no; 
	
	with opbacr003(item_no, pk_id) as
	(
		select item_no=b.mst_no, pk_id = isnull((select min(pk_id) from bacr003 where bacr003.mst_recid=b.mst_recid and bacr003.file_type='1'), 0)
		from deleted b
	)
	update dbo.bacr005
	set bacre05 = opbacr003.pk_id
	from opbacr003
	where bacr005.item_no = opbacr003.item_no; 

END
GO
