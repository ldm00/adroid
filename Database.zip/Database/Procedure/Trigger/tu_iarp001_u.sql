IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.tu_iarp001_u'))
   DROP TRIGGER dbo.tu_iarp001_u
GO
CREATE TRIGGER dbo.tu_iarp001_u ON dbo.iarp001
FOR UPDATE, INSERT,DELETE
AS
DECLARE @ls_bbusa42  NVARCHAR(10),
		@ls_biz_type NVARCHAR(1),
		@ls_biz_no   NVARCHAR(10),
		@ld_new_value NUMERIC(19,5),
		@ld_old_value NUMERIC(19,5),
		@ld_exrate		NUMERIC(9,5),
		@ls_doc_comp NVARCHAR(10),
		@ls_iarpa01a NVARCHAR(2),
		@ldt_date DATETIME,

		@ls_doc_curr NVARCHAR(10),
		@ld_comp_exrate	NUMERIC(9,5),
		@ld_iarpa31	NUMERIC(19,5),
		@ld_iarpa32	NUMERIC(19,5),
		@ld_iarpa33	NUMERIC(19,5),

		@ls_doc_curr_old NVARCHAR(10),
		@ld_comp_exrate_old	NUMERIC(9,5),
		@ld_iarpa31_old	NUMERIC(19,5),
		@ld_iarpa32_old	NUMERIC(19,5),
		@ld_iarpa33_old	NUMERIC(19,5)
BEGIN
	--INSERT
	IF NOT EXISTS(SELECT 1 FROM DELETED) 
	BEGIN
		IF EXISTS(SELECT 1 FROM bbus001 JOIN INSERTED 
			ON bbus001.biz_type = INSERTED.iarpa05 AND bbus001.biz_no = INSERTED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = doc_curr,@ls_bbusa42 = bbusa42 ,@ld_new_value = (iarpa31+iarpa32+iarpa33-iarpa34-iarpa35-iarpa36),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = INSERTED.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = doc_date,@ld_comp_exrate = comp_exrate
			FROM bbus001 JOIN INSERTED 
			ON bbus001.biz_type = INSERTED.iarpa05 AND bbus001.biz_no = INSERTED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr = @ls_bbusa42
			BEGIN
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
			END
			ELSE
			BEGIN
				SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
				SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
			END
		END 
	END
	--UPDATE
	IF EXISTS(SELECT 1 FROM INSERTED) AND EXISTS(SELECT 1 FROM DELETED) 
	BEGIN
		--�޸�(doc_curr,comp_exrate,iarpa31,32,33)�r, ҪUpdate �͑������~��
		IF EXISTS(SELECT 1 FROM bbus001 JOIN INSERTED 
			ON bbus001.biz_type = INSERTED.iarpa05 AND bbus001.biz_no = INSERTED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = doc_curr,@ls_bbusa42 = bbusa42 ,@ld_new_value = (iarpa31+iarpa32+iarpa33-iarpa34-iarpa35-iarpa36),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = INSERTED.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = doc_date,
					@ld_comp_exrate = comp_exrate,@ld_iarpa31 = iarpa31,@ld_iarpa32 = iarpa32,@ld_iarpa33 = iarpa33
			FROM bbus001 JOIN INSERTED 
			ON bbus001.biz_type = INSERTED.iarpa05 AND bbus001.biz_no = INSERTED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			SELECT @ld_old_value = (iarpa31+iarpa32+iarpa33-iarpa34-iarpa35-iarpa36),
				@ls_doc_curr_old = doc_curr,@ld_comp_exrate_old = comp_exrate,@ld_iarpa31_old = iarpa31,@ld_iarpa32_old = iarpa32,@ld_iarpa33_old = iarpa33
			FROM bbus001 JOIN DELETED 
			ON bbus001.biz_type = DELETED.iarpa05 AND bbus001.biz_no = DELETED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr_old <> @ls_doc_curr OR @ld_comp_exrate_old <> @ld_comp_exrate OR @ld_iarpa31_old <> @ld_iarpa31
				OR @ld_iarpa32_old <> @ld_iarpa32 OR @ld_iarpa33_old <> @ld_iarpa33
			BEGIN
				IF @ls_doc_curr = @ls_bbusa42
				BEGIN
					UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_old_value + @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
				END
				ELSE
				BEGIN
					SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
					SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
					SET @ld_old_value = @ld_old_value*@ld_comp_exrate/@ld_exrate;
					UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_old_value + @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
				END
			END
		END	
	END
	--DELETED
	IF NOT EXISTS(SELECT 1 FROM INSERTED) 
	BEGIN
		IF EXISTS(SELECT 1 FROM bbus001 JOIN DELETED 
			ON bbus001.biz_type = DELETED.iarpa05 AND bbus001.biz_no = DELETED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = doc_curr,@ls_bbusa42 = bbusa42 ,@ld_old_value = (iarpa31+iarpa32+iarpa33-iarpa34-iarpa35-iarpa36),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = DELETED.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = doc_date,@ld_comp_exrate = comp_exrate
			FROM bbus001 JOIN DELETED 
			ON bbus001.biz_type = DELETED.iarpa05 AND bbus001.biz_no = DELETED.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr = @ls_bbusa42
			BEGIN
				UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_old_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
			END
			ELSE
			BEGIN
				SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
				SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
				UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_old_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
			END
		END 
	END
END
GO
