IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.tu_iarp008_u'))
   DROP TRIGGER dbo.tu_iarp008_u
GO
CREATE TRIGGER dbo.tu_iarp008_u ON dbo.iarp008
FOR UPDATE, INSERT,DELETE
AS
DECLARE @ls_doc_curr NVARCHAR(10),
		@ls_bbusa42  NVARCHAR(10),
		@ls_biz_type NVARCHAR(1),
		@ls_biz_no   NVARCHAR(10),
		@ld_new_value NUMERIC(19,5),
		@ld_old_value NUMERIC(19,5),
		@ld_exrate		NUMERIC(9,5),
		@ls_doc_comp NVARCHAR(10),
		@ls_iarpa01a NVARCHAR(2),
		@ldt_date DATETIME,
		@ld_comp_exrate	NUMERIC(9,5)
BEGIN
	--INSERT
	IF NOT EXISTS(SELECT 1 FROM DELETED) 
	BEGIN
		IF EXISTS(SELECT 1 	FROM INSERTED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = iarp001.doc_curr,@ls_bbusa42 = bbusa42 ,@ld_new_value = (iarph05+iarph06+iarph07),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = iarp001.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = iarph15,@ld_comp_exrate = iarp001.comp_exrate
			FROM INSERTED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr = @ls_bbusa42
			BEGIN
				UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
			END
			ELSE
			BEGIN
				SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
				SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
				UPDATE bbus001 SET bbusa44 = bbusa44 - @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
			END
		END 
	END
	--UPDATE
	IF EXISTS(SELECT 1 FROM INSERTED) AND EXISTS(SELECT 1 FROM DELETED) 
	BEGIN
		IF EXISTS(SELECT 1 	FROM INSERTED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = iarp001.doc_curr,@ls_bbusa42 = bbusa42 ,@ld_new_value = (iarph05+iarph06+iarph07),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = iarp001.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = iarph15,@ld_comp_exrate = iarp001.comp_exrate
			FROM INSERTED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			SELECT @ld_old_value = (iarph05+iarph06+iarph07)
			FROM DELETED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr = @ls_bbusa42
			BEGIN
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_old_value - @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
			END
			ELSE
			BEGIN
				SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
				SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
				SET @ld_old_value = @ld_old_value*@ld_comp_exrate/@ld_exrate;
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_old_value - @ld_new_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
			END
		END	
	END
	--DELETED
	IF NOT EXISTS(SELECT 1 FROM INSERTED) 
	BEGIN
		IF EXISTS(SELECT 1 	FROM DELETED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0)
		BEGIN
			SELECT @ls_doc_curr = iarp001.doc_curr,@ls_bbusa42 = bbusa42 ,@ld_old_value = (iarph05+iarph06+iarph07),
					@ls_biz_type = bbus001.biz_type,@ls_biz_no = bbus001.biz_no,@ls_doc_comp = iarp001.doc_comp,@ls_iarpa01a = iarpa01a,
					@ldt_date = iarph15,@ld_comp_exrate = iarp001.comp_exrate
			FROM DELETED 
			JOIN iarp001 ON iarpa01a = iarph02a AND iarpa01b = iarph02b AND iarpa01c = iarph02c
			JOIN bbus001 ON bbus001.biz_type = iarp001.iarpa05 AND bbus001.biz_no = iarp001.iarpa06 AND bbusa42 <>'' AND bbusa43 > 0

			IF @ls_doc_curr = @ls_bbusa42
			BEGIN
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_old_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no
			END
			ELSE
			BEGIN
				SELECT @ld_exrate = dbo.fn_ReadExRate(@ls_doc_comp,@ls_bbusa42,dbo.fn_ReadExRateBy(@ls_doc_comp,@ls_iarpa01a,''),@ldt_date)
				SET @ld_new_value = @ld_new_value*@ld_comp_exrate/@ld_exrate;
				UPDATE bbus001 SET bbusa44 = bbusa44 + @ld_old_value WHERE biz_type = @ls_biz_type AND biz_no = @ls_biz_no				
			END
		END 
	END
END
GO
