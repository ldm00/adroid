IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_GetReportBizHistory') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_GetReportBizHistory
GO
/*
�z�L�s�x�L�{, ��lhis001 + ��L/����ڪ�������v
*/
CREATE PROCEDURE [dbo].usp_GetReportBizHistory
    @as_ProgId   NVARCHAR(8),		--�{���s�X 
    @as_CompID NVARCHAR(3),			--�n�����q
	@as_Arigd04 NVARCHAR(10),		--�ާ@���O
    @as_UserID NVARCHAR(10),		--�n���Τ�
	@as_RoleId NVARCHAR(10), 		--�n�J����
	@as_SameCus NVARCHAR(1),        --�P�Ȥ�
	@ai_ShowCount INT
AS
BEGIN 
	--.�U���L�o���q�O�M�\Ū�v��
	--Step1:�����q�O�C��comp_list[]:
	DECLARE @comp_list TABLE(doc_comp NVARCHAR(3));
	--�H�l���q�n����, comp_list�u�tLogin.Comp
	--�H�����q�n����, comp_list�tLogin.Comp�������l���q, �����tLogin.Comp�����q����
	WITH C1 AS
	(
	SELECT bcoma01 FROM bcom001
	WHERE EXISTS(SELECT * FROM bcom002 WHERE bcomb02 = @as_CompID) AND bcoma01 = @as_CompID 
	UNION
	SELECT bcoma01 FROM bcom001
	WHERE bcoma01 IN (SELECT bcomb02 FROM bcom002 WHERE bcomb01 = @as_CompID)  
	)
	INSERT INTO @comp_list (doc_comp)
	SELECT * FROM C1

	--Step2:��O�O�_���d���v 
	DECLARE @A2_right NVARCHAR(1),
			@A2_group NVARCHAR(20),
			@B2_right NVARCHAR(1),
			@B2_group NVARCHAR(20),
			@C1_right NVARCHAR(1),
			@C1_group NVARCHAR(20)

	SELECT @A2_group = '',@B2_group = '',@C1_group = ''
	SELECT @A2_right = arigf04d FROM arig006 
			WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
						  AND arigf07 = 'A2' AND arigf06 = '1'
			IF @@RowCount = 0
			BEGIN
				SELECT TOP 1 @A2_right = arigf04d FROM arig006 
				WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
							  AND arigf07 = 'A2'
			END
	IF @A2_right = '2'
	BEGIN
		SELECT @A2_group = dbo.fn_GetDefaultGroupByDocType(@as_ProgId,@as_UserID,@as_RoleId,'A2') 
	END
	SELECT @B2_right = arigf04d FROM arig006 
			WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
						  AND arigf07 = 'B2' AND arigf06 = '1'
			IF @@RowCount = 0
			BEGIN
				SELECT TOP 1 @B2_right = arigf04d FROM arig006 
				WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
							  AND arigf07 = 'B2'
			END
	IF @B2_right = '2'
	BEGIN
		SELECT @B2_group = dbo.fn_GetDefaultGroupByDocType(@as_ProgId,@as_UserID,@as_RoleId,'B2') 
	END
	SELECT @C1_right = arigf04d FROM arig006 
			WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
						  AND arigf07 = 'C1' AND arigf06 = '1'
			IF @@RowCount = 0
			BEGIN
				SELECT TOP 1 @C1_right = arigf04d FROM arig006 
				WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
							  AND arigf07 = 'C1'
			END
	IF @C1_right = '2'
	BEGIN
		SELECT @C1_group = dbo.fn_GetDefaultGroupByDocType(@as_ProgId,@as_UserID,@as_RoleId,'C1') 
	END	

	--Step3:���͸��
	SELECT *,' ' AS query_right,'          ' AS query_group INTO #lhis001 FROM lhis001 WHERE 1=0
	SELECT * INTO #Temp FROM lhis001 WHERE 1=0
	SELECT * INTO #Result FROM lhis001 WHERE 1=0;

	DECLARE @ls_dordb01a NVARCHAR(2),
			@ls_dordb01b NVARCHAR(16),
			@ls_item_no  NVARCHAR(20),
			@ls_item_sub NVARCHAR(10)
	DECLARE dord002_cur CURSOR FOR 
	SELECT dordb01a,dordb01b,item_no,item_sub FROM #dord002  
	OPEN dord002_cur
	FETCH NEXT FROM dord002_cur INTO @ls_dordb01a,@ls_dordb01b,@ls_item_no,@ls_item_sub
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DELETE FROM #lhis001
		DELETE FROM #Temp
		DECLARE @ls_biz_no NVARCHAR(10)
		SELECT @ls_biz_no = biz_no FROM dord001 WHERE dorda01a = @ls_dordb01a AND dorda01b = @ls_dordb01b
		IF @as_SameCus = '1' 
		BEGIN
			--�P�Ȥ�
			INSERT INTO #lhis001
			SELECT *,
				(CASE WHEN lhisa04a = 'A2' THEN  @A2_right ELSE 
				(CASE WHEN lhisa04a = 'B2' THEN  @B2_right ELSE @C1_right END)END),
				(CASE WHEN lhisa04a = 'A2' THEN  @A2_group ELSE 
				(CASE WHEN lhisa04a = 'B2' THEN  @B2_group ELSE @C1_group END)END)
			FROM lhis001 
			WHERE biz_type = 'C' AND biz_no = @ls_biz_no AND lhisa02a = @ls_item_no AND lhisa02b = @ls_item_sub  
				AND (lhisa04a = 'A2' OR lhisa04a = 'B2' OR lhisa04a = 'C1');
			DELETE FROM #lhis001 WHERE lhisa04a = @ls_dordb01a AND lhisa04b = @ls_dordb01b; ----�R������
	/*   10/25 US$ 23.50  <�w�{         ====> �L�X�Ӭ�  10/25 US$ 23.50
		 10/03 US$ 23.50     �x Last��                 08/10 US$ 24.25
		 08/29 US$ 23.50  <�w�}                         05/31 US$ 23.50 <�w �P�W�@�����P���Y�L�X.
		 08/10 US$ 24.25  <�w�{ Last��
		 07/05 US$ 24.25  <�w�}
		 05/31 US$ 23.50  <�w�w Last��
		 04/15 US$ 23.50*/
			WITH T1 AS
			(
				SELECT #lhis001.* FROM #lhis001 JOIN @comp_list ON lhisa40 = doc_comp 
				WHERE (query_right='1' AND lhisa41=@as_UserID) 
					OR (query_right='2' AND lhisa41 IN (SELECT arigc01 FROM arig003 
						WHERE right_group =
						(CASE WHEN lhisa04a = 'A2' THEN @A2_group ELSE 
						(CASE WHEN lhisa04a = 'B2' THEN @B2_group ELSE 
						(CASE WHEN lhisa04a = 'C1' THEN @C1_group END) END)END)))
					OR (query_right='0' AND lhisa41='')
					OR (query_right='3') 
			),
			T2 AS
			(
				SELECT biz_no,lhisa08,lhisa21,MAX(lhisa05) AS lhisa05 FROM T1   
				GROUP BY biz_no,lhisa08,lhisa21
			),
			T3 AS
			(
				SELECT C.* FROM T2 A
				CROSS APPLY 
				(
					SELECT TOP(1) * FROM lhis001 B 
					WHERE A.biz_no = B.biz_no AND A.lhisa08 = B.lhisa08 AND A.lhisa21 = B.lhisa21 AND A.lhisa05 = B.lhisa05
				) AS C
			)
			--Step4:Result Last3
			INSERT INTO #Temp
			SELECT TOP(@ai_ShowCount)* FROM  T3
		END
		ELSE
		BEGIN 	--���P�Ȥ�
			INSERT INTO #lhis001
			SELECT *,
				(CASE WHEN lhisa04a = 'A2' THEN  @A2_right ELSE 
				(CASE WHEN lhisa04a = 'B2' THEN  @B2_right ELSE @C1_right END)END),
				(CASE WHEN lhisa04a = 'A2' THEN  @A2_group ELSE 
				(CASE WHEN lhisa04a = 'B2' THEN  @B2_group ELSE @C1_group END)END)
			FROM lhis001 
			WHERE biz_type = 'C' AND biz_no <> @ls_biz_no AND lhisa02a = @ls_item_no AND lhisa02b = @ls_item_sub  
				AND (lhisa04a = 'A2' OR lhisa04a = 'B2' OR lhisa04a = 'C1')
			DELETE FROM #lhis001 WHERE lhisa04a = @ls_dordb01a AND lhisa04b = @ls_dordb01b; ----�R������
			WITH T4 AS
			(
				SELECT lhisaid FROM #lhis001 
				JOIN @comp_list ON lhisa40 = doc_comp 
				JOIN #Customer ON #Customer.biz_no = #lhis001.biz_no 
				WHERE (query_right='1' AND lhisa41=@as_UserID) 
					OR (query_right='2' AND lhisa41 IN (SELECT arigc01 FROM arig003 
						WHERE right_group =
						(CASE WHEN lhisa04a = 'A2' THEN @A2_group ELSE 
						(CASE WHEN lhisa04a = 'B2' THEN @B2_group ELSE 
						(CASE WHEN lhisa04a = 'C1' THEN @C1_group END) END)END)))
					OR (query_right='0' AND lhisa41='')
					OR (query_right='3') 
			),
			T5 AS
			(
				SELECT lhis001.* FROM lhis001 JOIN T4 ON T4.lhisaid = lhis001.lhisaid
			),
			T6 AS
			(
				SELECT T5.* FROM T5 WHERE create_date IN (SELECT MAX(create_date) FROM T5 GROUP BY biz_type,biz_no)
			)
			--Step5:History
			INSERT INTO #Temp
			SELECT * FROM  T6
		END
		UPDATE #Temp SET lhisa04a = @ls_dordb01a ,lhisa04b = @ls_dordb01b
		INSERT INTO #Result
		SELECT * FROM #Temp
		FETCH NEXT FROM dord002_cur INTO @ls_dordb01a,@ls_dordb01b,@ls_item_no,@ls_item_sub
	END
	CLOSE dord002_cur
	DEALLOCATE dord002_cur
	
	DROP TABLE #lhis001
	DROP TABLE #Temp
	SELECT * FROM #Result ORDER BY lhisa05 DESC
	DROP TABLE #Result
END
GO