﻿IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].fn_GetPackingData'))
   DROP FUNCTION dbo.fn_GetPackingData
GO
CREATE FUNCTION dbo.fn_GetPackingData
(
	@as_dinva01a	 NVARCHAR(2),		    --單別
	@as_dinva01b	 NVARCHAR(16)		    --單號
)
RETURNS @Retuen_Table TABLE			--返回bbit001
(
	dorddid UNIQUEIDENTIFIER,
	num FLOAT,
	dorde30a NVARCHAR(2),
	dorde30b NVARCHAR(16),
    item_no NVARCHAR(20),
    item_sub NVARCHAR(10),
    dorde31 NVARCHAR(10),
    dordd10 NVARCHAR(6),
    dordd11 NVARCHAR(20),
    dordd12 NVARCHAR(10),
    dorde05 NUMERIC(19,5),
    dorde06 NVARCHAR(6),
    item_desc1 NVARCHAR(30),
    item_desc2 NVARCHAR(30),
    item_desce1 NVARCHAR(30),
    item_desce2 NVARCHAR(30)
)
AS
BEGIN
	DECLARE @lt_tmp TABLE(id1 UNIQUEIDENTIFIER,id2 UNIQUEIDENTIFIER,Dcount NUMERIC(19,5),dordd10 NVARCHAR(6),dordd11 NVARCHAR(20),dordd12 NVARCHAR(10))
    DECLARE @ld_id1 UNIQUEIDENTIFIER,
			@ld_id2 UNIQUEIDENTIFIER, --dorde15 = dordbid = dordd01
			@ld_count NUMERIC(19,5),
			@ls_dordd10 NVARCHAR(6),
			@ls_dordd11 NVARCHAR(20),
			@ls_dordd12 NVARCHAR(10)
    DECLARE Cur_pending CURSOR FOR 
    SELECT dord005.recid,dorde15,dorde05,dordd10,dordd11,dordd12 FROM dord005 JOIN dord004 ON dorde01 = dorddid 
    WHERE dorde05>0 AND dorde03a=@as_dinva01a AND dorde03b=@as_dinva01b --dorde15 = dordbid = dordd01
    OPEN Cur_pending
    FETCH NEXT FROM Cur_pending INTO @ld_id1,@ld_id2,@ld_count,@ls_dordd10,@ls_dordd11,@ls_dordd12
    WHILE @@FETCH_STATUS = 0
    BEGIN	
		IF NOT EXISTS(SELECT * FROM @lt_tmp WHERE id2 = @ld_id2 AND dordd10 = @ls_dordd10 AND dordd11 = @ls_dordd11 AND dordd12 = @ls_dordd12) --依dord004(dordd01+dordd10+dordd11+dordd12), 相同的合併
		BEGIN
			INSERT INTO @lt_tmp(id1,id2,Dcount,dordd10,dordd11,dordd12) VALUES(@ld_id1,@ld_id2,@ld_count,@ls_dordd10,@ls_dordd11,@ls_dordd12)
		END
	ELSE
	BEGIN
		UPDATE @lt_tmp SET Dcount = Dcount + @ld_count WHERE id2 = @ld_id2 AND dordd10 = @ls_dordd10 AND dordd11 = @ls_dordd11 AND dordd12 = @ls_dordd12
	END
    FETCH NEXT FROM Cur_pending INTO @ld_id1,@ld_id2,@ld_count,@ls_dordd10,@ls_dordd11,@ls_dordd12
    END
    CLOSE Cur_pending
    DEALLOCATE Cur_pending  ;
    
	WITH C1 AS
	(SELECT dordd01,num=dord005.auto_seq,dorde30a,dorde30b,dord005.item_no,dord005.item_sub,dorde31,dord004.dordd10,dord004.dordd11,dord004.dordd12,dorde05 = Dcount,dorde06,item_desc1,item_desc2,item_desce1,item_desce2 FROM dord005
	 JOIN @lt_tmp ON id1 = dord005.recid
	 JOIN dord004 ON dorde01=dorddid
	 JOIN dord002 ON dorde15=dordbid
	 WHERE dorde05>0 AND dorde03a=@as_dinva01a AND dorde03b=@as_dinva01b
	 --ORDER BY dorde30b,item_no,item_sub,dorde31,num
	)
	INSERT INTO @Retuen_Table
	SELECT * FROM C1 ORDER BY dorde30b,item_no,item_sub,dorde31,num
	RETURN   ;                                     
END
GO

