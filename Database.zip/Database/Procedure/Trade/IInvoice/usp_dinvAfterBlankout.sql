IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_dinvAfterBlankout') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_dinvAfterBlankout
GO
CREATE PROCEDURE [dbo].[usp_dinvAfterBlankout]
	@as_dinva01a	 NVARCHAR(2),	--����
	@as_dinva01b	 NVARCHAR(16),	--����
	@as_UserId	 NVARCHAR(16)
AS
BEGIN
	--P1.		�Γ����P��������Ҫ���U
	UPDATE dinv001 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinva01a = @as_dinva01a AND dinva01b = @as_dinva01b
	UPDATE dinv002 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinvb01a = @as_dinva01a AND dinvb01b = @as_dinva01b
	UPDATE dinv003 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinvc01a = @as_dinva01a AND dinvc01b = @as_dinva01b
	UPDATE dinv004 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinvd01a = @as_dinva01a AND dinvd01b = @as_dinva01b
	UPDATE dinv007 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinvg01a = @as_dinva01a AND dinvg01b = @as_dinva01b
	
	UPDATE ldoc005 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE ldoce01a = @as_dinva01a AND ldoce01b = @as_dinva01b
	UPDATE ldoc006 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE ldocf01a = @as_dinva01a AND ldocf01b = @as_dinva01b AND ldocf01c=0
	UPDATE ldoc008 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE ldoch01a = @as_dinva01a AND ldoch01b = @as_dinva01b AND ldoch01c=0
	
	UPDATE dord005 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dorde03a = @as_dinva01a AND dorde03b = @as_dinva01b 
	UPDATE dord002 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dordb01a = @as_dinva01a AND dordb01b = @as_dinva01b 
	
	UPDATE dinv005 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE dinve04a = @as_dinva01a AND dinve04b = @as_dinva01b 
	UPDATE epur005 SET last_user =  @as_UserId,last_date = GETDATE(),doc_status = 'V' WHERE epure03a = @as_dinva01a AND epure03b = @as_dinva01b 
	
	--P2.		���U�Į��әn, ҪUpdate���������ų̙n
	--P2.1		dord005 Update dord004
	DECLARE @lui_dorddid UNIQUEIDENTIFIER
	DECLARE Cur_dord005 CURSOR FOR 
	SELECT dorde01 FROM dord005 WHERE dorde03a = @as_dinva01a AND dorde03b = @as_dinva01b
	OPEN Cur_dord005
	FETCH NEXT FROM Cur_dord005 INTO @lui_dorddid
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @ld_dordd18  NUMERIC(19,5)
		SELECT @ld_dordd18 = 0.0;
		
		SELECT @ld_dordd18 = ISNULL(SUM(dorde05),0) FROM dord005 WHERE dorde01 = @lui_dorddid AND 
			EXISTS(SELECT 1 FROM asys018 WHERE asysr01 = dorde30a AND asysr02 = 'dord004' AND asysr03 = @as_dinva01a AND CHARINDEX(dord005.doc_status, asysr09) > 0)
		
		UPDATE dord004 SET 
		dordd18 = @ld_dordd18,
		dordd15=CASE WHEN dordd17+@ld_dordd18>=dordd13 THEN '1' ELSE '0' END 
		WHERE dorddid = @lui_dorddid;
		FETCH NEXT FROM Cur_dord005 INTO @lui_dorddid
	END
	CLOSE Cur_dord005
	DEALLOCATE Cur_dord005
	
	--P2.2		epur005 Update epur004
	DECLARE @lui_epurdid UNIQUEIDENTIFIER
	DECLARE Cur_epur005 CURSOR FOR 
	SELECT epure01 FROM epur005 WHERE epure03a = @as_dinva01a AND epure03b = @as_dinva01b
	OPEN Cur_epur005
	FETCH NEXT FROM Cur_epur005 INTO @lui_epurdid
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @ld_epurd19  NUMERIC(19,5)	
		SELECT @ld_epurd19 = 0.0;
		
		SELECT @ld_epurd19 = ISNULL(SUM(epure05),0) FROM epur005 WHERE epure01 = @lui_epurdid AND 
			EXISTS(SELECT 1 FROM asys018 WHERE asysr01 = epure30a AND asysr02 = 'epur004' AND asysr03 = @as_dinva01a AND CHARINDEX(epur005.doc_status, asysr09) > 0)
		
		UPDATE epur004 SET 
		epurd19 = @ld_epurd19,
		epurd19a=CASE WHEN @ld_epurd19+epurd17>=epurd13 THEN '1' ELSE '0' END 
		WHERE epurdid = @lui_epurdid;
		FETCH NEXT FROM Cur_epur005 INTO @lui_epurdid
	END
	CLOSE Cur_epur005
	DEALLOCATE Cur_epur005	
END 
GO
