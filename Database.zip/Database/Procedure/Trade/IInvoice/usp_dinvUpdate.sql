IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_dinvUpdate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_dinvUpdate
GO
CREATE PROCEDURE [dbo].[usp_dinvUpdate]
	@as_dinva01a	 NVARCHAR(2),	--����
	@as_dinva01b	 NVARCHAR(16)	--����
AS
BEGIN
	EXEC usp_PackingQtyCompare @as_dinva01a,@as_dinva01b
	EXEC usp_InvoiceQtyCompare @as_dinva01a,@as_dinva01b
	EXEC usp_SupplyQtyCompare @as_dinva01a,@as_dinva01b
	EXEC usp_ARAmtCompare @as_dinva01a,@as_dinva01b
	EXEC usp_APAmtCompare @as_dinva01a,@as_dinva01b
END 
GO
