IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_item_asm]'))
   DROP FUNCTION [dbo].[fv_item_asm];
GO
CREATE FUNCTION [dbo].[fv_item_asm]
(
	@as_doc_comp NVARCHAR(3),
	@as_biz_type NVARCHAR(1),
	@as_biz_no NVARCHAR(10),
	@as_dlv_biz_no NVARCHAR(10),
	@as_doc_type NVARCHAR(2),
	@as_doc_no NVARCHAR(16),
	@as_read_seq NVARCHAR(10),
	@as_item_no NVARCHAR(20),
	@as_item_sub NVARCHAR(10),
	@as_asm_ver NVARCHAR(20),
	@adc_qty_main NUMERIC(19,5),
	@adc_unit_main_trans1 NUMERIC(19,5),
	@adc_unit_main_trans2 NUMERIC(19,5),
	@adt_date DATETIME,
	@as_desc_seq NVARCHAR(10)
)
RETURNS @at_result TABLE
(
	main_item_no NVARCHAR(20),
	main_item_sub NVARCHAR(10),
	num INT IDENTITY,
	item_no NVARCHAR(20),
	item_sub NVARCHAR(10),
	item_desc1 NVARCHAR(30),
	item_desc2 NVARCHAR(30),
	item_desce1 NVARCHAR(30),
	item_desce2 NVARCHAR(30),
	bitmh03 NUMERIC(19,5),
	bitmh04 NUMERIC(19,5),
	bitmh05a NVARCHAR(6),
	bitmh05b NUMERIC(19,5),
	bitmh05c NUMERIC(19,5),
	bitmh06 NVARCHAR(10),
	bitmh07 INT,
	bbitf02 NVARCHAR(5),
	bbitf03 NUMERIC(19,8),
	bbitf04 NVARCHAR(6),
	bbitf05 NUMERIC(19,5),
	bbitf06 NUMERIC(19,5),
	tax_type NVARCHAR(1),
	tax_rate NUMERIC(9,5),
	bitmh08  NUMERIC(9,5),
	bitmh09 NUMERIC(19,5),
	bitmh10 NVARCHAR(1),
	bitmh13 NUMERIC(19,8),
	bitmh14 NUMERIC(9,5),
	bitmh15 NVARCHAR(256),
	bitmh16 NVARCHAR(256),
	bitmh17 NVARCHAR(10),
	user_text1 NVARCHAR(30),
	user_text2 NVARCHAR(30),
	user_text3 NVARCHAR(30),
	user_num1  NUMERIC(19,8),
	user_num2 NUMERIC(19,8),
	user_num3 NUMERIC(19,8),
	sr_doc_type NVARCHAR(2),
	sr_doc_no NVARCHAR(16),
	qty_main  NUMERIC(19,5),
	qty_sub NUMERIC(19,5)
)
AS
BEGIN
	DECLARE 
		@ls_read_seq NVARCHAR(1),
		@li_i INT
	
	IF @as_item_no = N''
		RETURN;

	
		
	IF @adc_qty_main = 0 SET @adc_qty_main = 1;
	IF @adc_unit_main_trans1 = 0 SET @adc_unit_main_trans1 = 1;
	IF @adc_unit_main_trans2 = 0 SET @adc_unit_main_trans2 = 1;

	IF @as_read_seq NOT LIKE '%1%'
		SET @as_read_seq = @as_read_seq + N'1';
		
	SET @li_i = 1;
	SET @ls_read_seq = LEFT(@as_read_seq,1);
	
	WHILE (@li_i <= LEN(@as_read_seq))
	BEGIN
		
		IF @ls_read_seq = N'1'
		BEGIN
			IF @as_asm_ver = N'' SET @as_asm_ver = @as_item_no;
			/*
			INSERT @at_result(main_item_no,main_item_sub,item_no,item_sub,item_desc1,
				item_desc2,item_desce1,item_desce2,bitmh03,bitmh04,
				bitmh05a,bitmh05b,bitmh05c,bitmh06,bitmh07,bitmh08,
				bitmh09,bitmh10,bitmh13,bitmh14,bitmh15,bitmh16,bitmh17,
				user_text1,user_text2,user_text3,user_num1,user_num2,user_num3,
				sr_doc_type,sr_doc_no,qty_main,qty_sub)
			SELECT
				@as_item_no,@as_item_sub,
				a.item_no,a.item_sub,b.item_desc1,b.item_desc2,
				b.item_desce1,b.item_desce2,
				bitmh03*@adc_unit_main_trans1/@adc_unit_main_trans2,
				bitmh04,bitmh05a,bitmh05b,bitmh05c,bitmh06,bitmh07,
				bitmh08,bitmh09,bitmh10,bitmh13,bitmh14,bitmh15,
				bitmh16,bitmh17,a.user_text1,a.user_text2,a.user_text3,a.user_num1,
				a.user_num2,a.user_num3,N'',N'',@adc_qty_main,
				@adc_qty_main*(bitmh03/bitmh04)*(1+bitmh08) + bitmh09
			FROM dbo.bitm008 AS a 
				JOIN dbo.bitm001 AS b ON a.item_no = b.item_no
			WHERE bitmh01 = @as_asm_ver
				AND bitmh02 = N'1'
				--bitmh03,04,05b,05c��һ�ڞ�0��, ���J���ǲ��Ϸ���ӛ�
				AND bitmh03*bitmh04*bitmh05b*bitmh05c <> 0
				AND bitmh11 <> N'1'
			ORDER BY num;
			*/
			
			 WITH cte_desc
			 AS
			 (
			 SELECT a.item_no,a.item_sub,a.auto_seq,
				MAX(CASE WHEN b.main_desc = N'1' THEN b.[desc] ELSE '' END) AS item_desc1,
				MAX(CASE WHEN b.main_desc = N'2' THEN b.[desc] ELSE '' END) AS item_desc2,
				MAX(CASE WHEN b.main_desc = N'3' THEN b.[desc] ELSE '' END) AS item_desce1,
				MAX(CASE WHEN b.main_desc = N'4' THEN b.[desc] ELSE '' END) AS item_desce2
			 FROM dbo.bitm008 AS a 
				CROSS APPLY dbo.fv_item_desc(@as_doc_comp,@as_biz_type,@as_biz_no,
							@as_dlv_biz_no,@as_doc_type,@as_doc_no,@as_desc_seq,a.item_no,a.item_sub,N'10') AS b
			 WHERE bitmh01 = @as_asm_ver
				AND bitmh02 = N'1'
				--bitmh03,04,05b,05c��һ�ڞ�0��, ���J���ǲ��Ϸ���ӛ�
				AND bitmh03*bitmh04*bitmh05b*bitmh05c <> 0
				AND bitmh11 = N'1'
			 GROUP BY a.item_no,a.item_sub,a.auto_seq
			 )
			INSERT @at_result(main_item_no,main_item_sub,item_no,item_sub,item_desc1,
				item_desc2,item_desce1,item_desce2,bitmh03,bitmh04,
				bitmh05a,bitmh05b,bitmh05c,bitmh06,bitmh07,bitmh08,
				bitmh09,bitmh10,bitmh13,bitmh14,bitmh15,bitmh16,bitmh17,
				user_text1,user_text2,user_text3,user_num1,user_num2,user_num3,
				sr_doc_type,sr_doc_no,qty_main,qty_sub)			 
			SELECT
				@as_item_no,@as_item_sub,
				a.item_no,a.item_sub,d.item_desc1,d.item_desc2,
				d.item_desce1,d.item_desce2,
				bitmh03*@adc_unit_main_trans1/@adc_unit_main_trans2,
				bitmh04,bitmh05a,bitmh05b,bitmh05c,bitmh06,bitmh07,
				bitmh08,bitmh09,bitmh10,bitmh13,bitmh14,bitmh15,
				bitmh16,bitmh17,a.user_text1,a.user_text2,a.user_text3,a.user_num1,
				a.user_num2,a.user_num3,N'',N'',@adc_qty_main,
				@adc_qty_main*(bitmh03/bitmh04)*(1+bitmh08) + bitmh09	
			FROM cte_desc AS d 
				JOIN dbo.bitm008 AS a ON d.item_no = a.item_no AND d.item_sub = a.item_sub AND d.auto_seq = a.auto_seq
				JOIN dbo.bitm001 AS b ON a.item_no = b.item_no
			ORDER BY a.num;
				
		END
		ELSE IF (@ls_read_seq = N'2' AND @as_biz_no <> N'' AND @as_biz_type <> N'')
				OR
				(@ls_read_seq =N'3' AND @as_doc_no <> N'' AND @as_doc_type <> N'')
		BEGIN

			INSERT @at_result(main_item_no,main_item_sub,item_no,item_sub,item_desc1,
				item_desc2,item_desce1,item_desce2,bitmh03,bitmh04,
				bitmh05a,bitmh05b,bitmh05c,bitmh06,bitmh07,bitmh08,
				bitmh09,bitmh10,bitmh13,bitmh14,bitmh15,bitmh16,bitmh17,
				user_text1,user_text2,user_text3,user_num1,user_num2,user_num3,
				sr_doc_type,sr_doc_no,qty_main,qty_sub)			
			SELECT 
				@as_item_no,@as_item_sub,
				b.item_no,b.item_sub,b.item_desc1,b.item_desc2,
				b.item_desce1,b.item_desce2,
				CASE WHEN a.qunit_trans1 = @adc_unit_main_trans1 AND a.qunit_trans2 = @adc_unit_main_trans2
					THEN b.ldocb06a
					ELSE b.ldocb06a*(@adc_unit_main_trans1/@adc_unit_main_trans2)/(a.qunit_trans1/a.qunit_trans2) END,
				b.ldocb06b,b.ldocb16,b.ldocb17a,b.ldocb17b,b.ldocb08b,b.ldocb09,
				ldocb06c,ldocb06d,ldocb05,ldocb10a,ldocb10b,ldocb12,ldocb11,ldocb13,
				N'',N'',N'',0,0,0,a.doc_type,a.doc_no,@adc_qty_main,
				@adc_qty_main*(
				(CASE WHEN a.qunit_trans1 = @adc_unit_main_trans1 AND a.qunit_trans2 = @adc_unit_main_trans2
					THEN b.ldocb06a
					ELSE b.ldocb06a*(@adc_unit_main_trans1/@adc_unit_main_trans2)/(a.qunit_trans1/a.qunit_trans2) END
					)/ldocb06b)*(1+ldocb06c) + ldocb06d
			FROM dbo.fv_his_item(@as_doc_comp,@as_biz_type,@as_biz_no,@as_doc_type,
							@as_doc_no,@as_item_no,@as_item_sub,
							CASE WHEN @ls_read_seq = N'3' THEN N'2' ELSE N'1' END) AS a
				JOIN dbo.ldoc002 AS b ON a.doc_type = b.ldocb01a AND a.doc_no = b.ldocb01b
					AND a.lhisaid = b.ldocb02 AND ldocb03 = N'0'
			ORDER BY ldocb01a,ldocb01b,ldocb02,num;
				
		END	
	
		IF NOT EXISTS(SELECT * FROM @at_result)
		BEGIN
			SET @li_i = @li_i + 1;
			SET @ls_read_seq = SUBSTRING(@as_read_seq,@li_i,1)
		END
		ELSE
			BREAK;
		
	END
	
	UPDATE a
		SET a.bbitf02 = b.bbitf02,
			a.bbitf03 = b.bbitf03,
			a.bbitf04 = b.bbitf04,
			a.bbitf05 = b.bbitf05,
			a.bbitf06 = b.bbitf06,
			a.tax_type = b.tax_type,
			a.tax_rate = b.tax_rate
	FROM @at_result AS a JOIN dbo.bbit006 AS b
		ON b.biz_no = a.bitmh06 AND b.item_no = a.item_no AND b.item_sub = N'' 
			AND b.bbitf01 = a.bitmh07;
			
	RETURN;
END
GO
