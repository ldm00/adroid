﻿
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_his_biz]'))
   DROP FUNCTION [dbo].fv_his_biz;
GO
CREATE FUNCTION [dbo].fv_his_biz
(
	@as_doc_comp NVARCHAR(3),    --公司別
	@as_biz_type NVARCHAR(1),    --對象別
	@as_def_biz_no NVARCHAR(10), --對象編號
	@as_def_dlv_biz NVARCHAR(20),--交貨對象編號
	@as_sort NVARCHAR(10)        --排序方式
)

RETURNS @at_result TABLE
(
	biz_type NVARCHAR(1),    --對象別
	biz_no   NVARCHAR(20),   --客戶編號
	biz_abbr NVARCHAR(20),   --客戶簡稱
	dlv_biz  NVARCHAR(20),   --交貨對象
	dlv_abbr NVARCHAR(20),   --對象簡稱
	tel      NVARCHAR(20),   --電話
	fax      NVARCHAR(20),   --傳真
	atten    NVARCHAR(20),   --業務連絡人
	master   NVARCHAR(30),   --負責人
	category NVARCHAR(20),   --分類
	area     NVARCHAR(20),   --地區
	doc_staff NVARCHAR(20),  --負責業務
	reg_no    NVARCHAR(30),  --統一編號
	sal_grade NVARCHAR(20),  --交易等級
	pr_grade  NVARCHAR(20),  --價格等級
	[name]    NVARCHAR(80),  --客戶名稱
	address   NVARCHAR(200)   --客戶地址
)
AS
BEGIN
	--3. @doc_comp不為空不為*, 過濾客戶歸屬公司
    --3.1 @doc_comp為母公司的, 取各子公司列表: comp_list=bcom002(bcomb01=@doc_comp).bcomb02
    --3.2 comp_list.add @doc_comp
    --3.3 存在bbus004(biz_type,biz_no = bbus001).bbusd01 in comp_list 即可
	IF (NOT EXISTS(SELECT 1 FROM bbus004 WHERE (@as_def_biz_no='*' OR biz_no=@as_def_biz_no) AND biz_type = @as_biz_type AND 
			(bbusd01 IN (SELECT bcoma01 FROM bcom001 WHERE 
					bcoma01=@as_doc_comp OR bcoma01 IN (SELECT bcomb02 FROM bcom002 WHERE bcomb01=@as_doc_comp)) OR bbusd01='*')))
    RETURN;
     --1. 過濾 bbit001.biz_type=@biz_type
    --2. 相同biz_type+biz_no+bbita01產生一筆記錄, 寫入臨時表tmp_biz	
    IF @as_biz_type IN (N'C',N'M') 
    BEGIN
      WITH tmp_biz
      AS
      (
  	  SELECT biz_type,biz_no,bbita01
  	  FROM bbit001 WHERE biz_type=@as_biz_type AND (@as_def_biz_no='*' OR biz_no=@as_def_biz_no) AND (@as_def_dlv_biz='*' OR bbita01=@as_def_dlv_biz)
  	  GROUP BY biz_type,biz_no,bbita01
      )
	  INSERT INTO @at_result		
      SELECT A.biz_type,A.biz_no,A.bbusa03,B.biz_no,B.bbusa03,C.lbasd14,C.lbasd16,A.bbusa39a,
           A.bbusa08,A.bbusa12,A.bbusa11,A.doc_staff,C.lbasd18,A.bbusa13,A.bbusa14,A.bbusa02,C.lbasd12
      FROM tmp_biz JOIN bbus001 AS A ON tmp_biz.biz_type=A.biz_type AND tmp_biz.biz_no=A.biz_no
      LEFT JOIN bbus001 AS B ON tmp_biz.biz_type=B.biz_type AND tmp_biz.bbita01=B.biz_no
      LEFT JOIN lbas004 AS C ON C.biz_type=A.biz_type AND C.biz_no=A.biz_no AND C.lbasd23='000001' 
      ORDER BY ( CASE @as_sort WHEN '1' THEN A.bbusa03 ELSE A.biz_no END)
    END
    
    IF @as_biz_type =N'P' 
    BEGIN
      WITH tmp_biz
      AS
      (
  	  SELECT biz_type,biz_no,bbita01
  	  FROM bbit001 WHERE biz_type=@as_biz_type AND (@as_def_biz_no='*' OR biz_no=@as_def_biz_no) AND (@as_def_dlv_biz='*' OR bbita01=@as_def_dlv_biz)
  	  GROUP BY biz_type,biz_no,bbita01
      )
	  INSERT INTO @at_result		
      SELECT A.biz_type,A.biz_no,A.bbusb03,B.biz_no,B.bbusb03,C.lbasd14,C.lbasd16,A.bbusb39a,
           A.bbusb08,A.bbusb12,A.bbusb11,A.doc_staff,C.lbasd18,A.bbusb13,A.bbusb14,A.bbusb02,C.lbasd12
      FROM tmp_biz JOIN bbus002 AS A ON tmp_biz.biz_type=A.biz_type AND tmp_biz.biz_no=A.biz_no
      LEFT JOIN bbus002 AS B ON tmp_biz.biz_type=B.biz_type AND tmp_biz.bbita01=B.biz_no
      LEFT JOIN lbas004 AS C ON C.biz_type=A.biz_type AND C.biz_no=A.biz_no AND C.lbasd23='000001' 
      ORDER BY ( CASE @as_sort WHEN '1' THEN A.bbusb03 ELSE A.biz_no END)
    END
    
    IF @as_biz_type =N'S' 
    BEGIN
      WITH tmp_biz
      AS
      (
  	  SELECT biz_type,biz_no,bbita01
  	  FROM bbit001 WHERE biz_type=@as_biz_type AND (@as_def_biz_no='*' OR biz_no=@as_def_biz_no) AND (@as_def_dlv_biz='*' OR bbita01=@as_def_dlv_biz)
  	  GROUP BY biz_type,biz_no,bbita01
      )
	  INSERT INTO @at_result		
      SELECT A.biz_type,A.biz_no,A.bbusc03,B.biz_no,B.bbusc03,C.lbasd14,C.lbasd16,A.bbusc39a,
           A.bbusc08,A.bbusc12,A.bbusc11,A.doc_staff,C.lbasd18,A.bbusc13,A.bbusc14,A.bbusc02,C.lbasd12
      FROM tmp_biz JOIN bbus003 AS A ON tmp_biz.biz_type=A.biz_type AND tmp_biz.biz_no=A.biz_no
      LEFT JOIN bbus003 AS B ON tmp_biz.biz_type=B.biz_type AND tmp_biz.bbita01=B.biz_no
      LEFT JOIN lbas004 AS C ON C.biz_type=A.biz_type AND C.biz_no=A.biz_no AND C.lbasd23='000001' 
      ORDER BY ( CASE @as_sort WHEN '1' THEN A.bbusc03 ELSE A.biz_no END)
    END
			
	RETURN;
  
END
GO
