IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_item_supp]'))
   DROP FUNCTION [dbo].[fv_item_supp];
GO
CREATE FUNCTION [dbo].[fv_item_supp]
(
	@as_doc_comp NVARCHAR(3),
	@as_item_comp NVARCHAR(3),
	@as_doc_type NVARCHAR(2),
	@as_doc_no NVARCHAR(16),
	@as_item_no NVARCHAR(20),
	@as_item_sub NVARCHAR(10),
	--@as_biz_type NVARCHAR(1) �̶�Ϊ'M',
	@as_biz_no NVARCHAR(10),
	@ai_cost_seq INT,
	@adc_item_qty NUMERIC(19,5),
	@as_tax_type NVARCHAR(1),
	@adc_tax_rate NUMERIC(9,5),
	@as_read_seq NVARCHAR(10),
	@as_cost_from NVARCHAR(1)
)
RETURNS @at_result TABLE
(
	item_no NVARCHAR(20),
	item_sub NVARCHAR(10),
	biz_no NVARCHAR(10),
	bbitf01 INT,
	bbitf02 NVARCHAR(5),
	bbitf03 NUMERIC(19,8),
	bbitf04 NVARCHAR(6),
	bbitf05 NUMERIC(19,5),
	bbitf06 NUMERIC(19,5),
	tax_type NVARCHAR(1),
	tax_rate NUMERIC(9,5),
	bbitf07 NUMERIC(19,5),
	bbitf08 NUMERIC(19,5),
	bbitf09 NVARCHAR(6),
	bbitf10 NUMERIC(19,5),
	bbitf11 NUMERIC(19,5),
	bbitf12 NVARCHAR(1),
	bbitf13 NUMERIC(19,8),
	bbitf14 NUMERIC(19,8),
	bbitf15 NUMERIC(19,8),
	bbitf16 NVARCHAR(6),
	bbitf17 NUMERIC(19,5),
	bbitf18 NUMERIC(19,5),
	bbitf19 NVARCHAR(20),
	bbitf20 NVARCHAR(2),
	bbitf21 NVARCHAR(16),
	bbitf22 DATETIME,
	bbitf23 NVARCHAR(6),
	bbitf24 NVARCHAR(20),
	bbitf25 NVARCHAR(20),
	bbitf26 DATETIME,
	bbitf27 DATETIME

)
AS
BEGIN

	DECLARE @ls_read_seq NCHAR(1),
			@li_i INT,
			@li_rowcount INT;
	
	IF @as_item_no = N''
		RETURN;

	IF @as_read_seq NOT LIKE N'%1%'	SET @as_read_seq = @as_read_seq + N'1';
	IF @as_item_comp = N''
		SELECT @as_item_comp = item_comp FROM dbo.fv_item_comp(@as_doc_comp);
	
	SELECT TOP (1)
		--@as_biz_type = CASE WHEN @as_cost_from IN(N'1',N'3',N'4') THEN N'M' ELSE @as_biz_type END,
		@as_biz_no = CASE @as_cost_from WHEN N'1' THEN bcita34
			WHEN N'3' THEN bcita47
			WHEN N'4' THEN bcita45 ELSE @as_biz_no END,
		@ai_cost_seq = CASE @as_cost_from WHEN N'1' THEN bcita35
			WHEN N'3' THEN bcita48
			WHEN N'4' THEN bcita46 ELSE @ai_cost_seq END
	FROM dbo.bcit001
	WHERE doc_comp IN(N'*',@as_item_comp)
		AND item_no = @as_item_no
		AND item_sub = N''	
	ORDER BY CASE WHEN doc_comp = N'*' THEN 0 ELSE 1 END DESC;

	--ȡ�ԮaƷ�����Y��
	IF @as_biz_no <> N''
	BEGIN
		INSERT @at_result
		SELECT
			item_no,@as_item_sub,biz_no,bbitf01,bbitf02,
			bbitf03,bbitf04,bbitf05,bbitf06,tax_type,
			tax_rate,bbitf07,bbitf08,bbitf09,bbitf10,
			bbitf11,bbitf12,bbitf13,bbitf14,bbitf15,
			bbitf16,bbitf17,bbitf18,bbitf19,bbitf20,
			bbitf21,bbitf22,bbitf23,bbitf24,bbitf25,
			bbitf26,bbitf27
		FROM dbo.bbit006
		WHERE biz_no = @as_biz_no AND item_no = @as_item_no
			AND (@ai_cost_seq = 0 OR bbitf01 = @ai_cost_seq)
			AND (@adc_item_qty = 0 OR @adc_item_qty BETWEEN bbitf07 AND bbitf08);
	END
	ELSE
		INSERT @at_result
		SELECT
			item_no,@as_item_sub,biz_no,bbitf01,bbitf02,
			bbitf03,bbitf04,bbitf05,bbitf06,tax_type,
			tax_rate,bbitf07,bbitf08,bbitf09,bbitf10,
			bbitf11,bbitf12,bbitf13,bbitf14,bbitf15,
			bbitf16,bbitf17,bbitf18,bbitf19,bbitf20,
			bbitf21,bbitf22,bbitf23,bbitf24,bbitf25,
			bbitf26,bbitf27
		FROM dbo.bbit006
		WHERE item_no = @as_item_no
			AND (@ai_cost_seq = 0 OR bbitf01 = @ai_cost_seq)
			AND (@adc_item_qty = 0 OR @adc_item_qty BETWEEN bbitf07 AND bbitf08);	
	
	SET @li_i = 1;
	SET @li_rowcount = 0;
	SET @ls_read_seq = LEFT(@as_read_seq,1);
	
	WHILE (@li_i <= LEN(@as_read_seq))
	BEGIN
		IF (@ls_read_seq = N'2' AND @as_biz_no <> N'') --AND @as_biz_type <> N''
			OR
		   (@ls_read_seq = N'3' AND @as_doc_no <> N'' AND @as_doc_type <> N'')
		BEGIN
			UPDATE a
				SET bbitf02 = doc_curr,
					bbitf03 = price,
					bbitf04 = punit,
					bbitf05 = punit_trans1,
					bbitf06 = punit_trans2,
					tax_type = b.tax_type,
					tax_rate = b.tax_rate,
					bbitf20 = doc_type,
					bbitf21 = doc_no,
					bbitf22 = doc_date,
					bbitf23 = term,
					bbitf24 = port_from,
					bbitf25 = port_to,
					bbitf26 = doc_date,
					bbitf27 = N''
			FROM @at_result AS a
				CROSS APPLY dbo.fv_his_item(@as_doc_comp,N'M',biz_no,@as_doc_type,
				@as_doc_no,item_no,item_sub,
				CASE WHEN @ls_read_seq = N'2' THEN N'1' ELSE N'2' END) AS b;
				
			SET @li_rowcount = @@ROWCOUNT;
		END
		
		IF @li_rowcount = 0
		BEGIN
			SET @li_i = @li_i + 1;
			SET @ls_read_seq = SUBSTRING(@as_read_seq,@li_i,1);
		END
		ELSE
			BREAK;
		
	END	
	
	UPDATE a
		SET tax_type = @as_tax_type,
			tax_rate = @adc_tax_rate,
			bbitf03 = dbo.fn_AmountTaxTrans(tax_type,tax_rate,bbitf03,@as_tax_type)
	FROM @at_result AS a
	WHERE tax_type <> @as_tax_type;
	
	RETURN;
END
GO
