IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_item_cbs]'))
   DROP FUNCTION [dbo].[fv_item_cbs];
GO
CREATE FUNCTION [dbo].[fv_item_cbs]
(
	@as_doc_comp NVARCHAR(3),
	@as_country NVARCHAR(20),
	@as_biz_type NVARCHAR(1),
	@as_biz_no NVARCHAR(10),
	@as_doc_type NVARCHAR(2),
	@as_doc_no NVARCHAR(16),
	@as_reg_no NVARCHAR(40),
	@as_read_seq NVARCHAR(10),	
	@as_item_no NVARCHAR(20),
	@as_item_sub NVARCHAR(10),
	@adc_price NUMERIC(19,5),
	@adc_weight NUMERIC(19,5)
)
RETURNS @at_result TABLE
(
	country NVARCHAR(20),
	item_no NVARCHAR(20),
	item_sub NVARCHAR(10),
	num INT IDENTITY,
	asm_material NVARCHAR(20),
	reg_item_no NVARCHAR(20),
	item_desc1 NVARCHAR(30),
	item_desc2 NVARCHAR(30),
	item_desce1 NVARCHAR(30),
	item_desce2 NVARCHAR(30),
	hs_code NVARCHAR(20),
	hs_desc NVARCHAR(40),
	unit_weight NUMERIC(19,5),
	wunit NVARCHAR(6),
	weight_rate NUMERIC(9,5),
	qty NUMERIC(19,5),
	wear_percent NUMERIC(9,5),
	price_rate NUMERIC(9,5),
	tax_type NVARCHAR(1),
	tax_number NUMERIC(9,5),
	tax_rate_type NVARCHAR(1),
	tax_rate_number NUMERIC(9,5),
	duty_amt NUMERIC(19,5)
)
AS
BEGIN

	DECLARE @ls_read_seq NCHAR(1),
			@li_i INT,
			@ls_odutd02 NCHAR(1);
	
	IF @as_item_no = N''
		RETURN;

	IF @as_reg_no <> N''
	BEGIN

		INSERT @at_result
		SELECT
			@as_country,@as_item_no,@as_item_sub,
			odutc03,odutc04,item_desc1,item_desc2,item_desce1,
			item_desce2,odutb03,oduta03,odutc05,N'KG',
			odutc06,odutc07,odutc08,odutc09,
			CASE WHEN oduta04 > 0 THEN N'1'
				WHEN oduta05 > 0 THEN N'2'
				WHEN oduta06 > 0 THEN N'3'
				WHEN oduta07 > 0 THEN N'4' END,
			CASE WHEN oduta04 > 0 THEN oduta04
				WHEN oduta05 > 0 THEN oduta05
				WHEN oduta06 > 0 THEN oduta06
				WHEN oduta07 > 0 THEN oduta07 END,
			CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN N'3'
				WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc05 > 0 THEN N'1'
				WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc06 > 0 THEN N'2'
				ELSE N'1' END,
			CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN odutc09
				WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc05 > 0 THEN odutc05
				WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc06 > 0 THEN odutc06
				ELSE 0 END,
			CASE WHEN oduta04 > 0 THEN @adc_price*oduta04*odutc09
				WHEN oduta06 > 0 THEN @adc_price*oduta06*odutc09
				WHEN oduta05 > 0 AND odutc05 > 0 THEN oduta05*odutc05
				WHEN oduta05 > 0 AND odutc06 > 0 THEN @adc_weight*oduta05*odutc06
				WHEN oduta07 > 0 AND odutc05 > 0 THEN oduta07*odutc05
				WHEN oduta07 > 0 AND odutc06 > 0 THEN @adc_weight*oduta07*odutc06
				ELSE 0 END
		FROM dbo.odut003
			JOIN dbo.odut002 ON odutc01 = odutb01 AND odutc04 = odutb02
			JOIN dbo.odut001 ON odutb01 = oduta01 AND odutb03 = oduta02
		WHERE odutc01 = @as_country AND odutc02 = @as_reg_no
		ORDER  BY odut003.num,odut003.auto_seq;
		
		RETURN;

	END

	SET @li_i = 1;
	SET @ls_read_seq = LEFT(@as_read_seq,1);
	
	WHILE (@li_i <= LEN(@as_read_seq))
	BEGIN

		IF @ls_read_seq = N'1'
		BEGIN
		
			SET @ls_odutd02 = NULL;
			
			SELECT @ls_odutd02 = odutd02 
			FROM dbo.odut004
			WHERE item_no = @as_item_no AND odutd01 = @as_country;
			
			IF @ls_odutd02 = N'1' OR @ls_odutd02 IS NULL
				RETURN;

			IF @ls_odutd02 = N'2'
			BEGIN
				INSERT @at_result
				SELECT
					@as_country,@as_item_no,@as_item_sub,
					odutc03,odutc04,c.item_desc1,c.item_desc2,c.item_desce1,
					c.item_desce2,odutb03,oduta03,odutc05,N'KG',
					odutc06,odutc07,odutc08,odutc09,
					CASE WHEN oduta04 > 0 THEN N'1'
						WHEN oduta05 > 0 THEN N'2'
						WHEN oduta06 > 0 THEN N'3'
						WHEN oduta07 > 0 THEN N'4' END,
					CASE WHEN oduta04 > 0 THEN oduta04
						WHEN oduta05 > 0 THEN oduta05
						WHEN oduta06 > 0 THEN oduta06
						WHEN oduta07 > 0 THEN oduta07 END,
					CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN N'3'
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc05 > 0 THEN N'1'
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc06 > 0 THEN N'2'
						ELSE N'1' END,
					CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN odutc09
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc05 > 0 THEN odutc05
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odutc06 > 0 THEN odutc06
						ELSE 0 END,
					CASE WHEN oduta04 > 0 THEN @adc_price*oduta04*odutc09
						WHEN oduta06 > 0 THEN @adc_price*oduta06*odutc09
						WHEN oduta05 > 0 AND odutc05 > 0 THEN oduta05*odutc05
						WHEN oduta05 > 0 AND odutc06 > 0 THEN @adc_weight*oduta05*odutc06
						WHEN oduta07 > 0 AND odutc05 > 0 THEN oduta07*odutc05
						WHEN oduta07 > 0 AND odutc06 > 0 THEN @adc_weight*oduta07*odutc06
						ELSE 0 END
				FROM dbo.odut004 AS a
					JOIN dbo.odut003 AS b ON a.odutd01 = b.odutc01 AND a.item_no = b.odutc02
					JOIN dbo.odut002 AS c ON b.odutc01 = c.odutb01 AND b.odutc04 = c.odutb02
					JOIN dbo.odut001 AS d ON c.odutb01 = d.oduta01 AND c.odutb03 = d.oduta02
				WHERE a.item_no = @as_item_no
					AND odutd01 = @as_country
				ORDER BY odutc01,odutc02,num,auto_seq;
			END
			ELSE IF @ls_odutd02 = N'3'
			BEGIN
			
				INSERT @at_result
				SELECT
					@as_country,@as_item_no,@as_item_sub, 
					odute02,odute03,c.item_desc1,c.item_desc2,c.item_desce1,
					c.item_desce2,odute05,odute06,odute07,N'KG',
					odute08,odute09,odute10,odute11,
					CASE WHEN oduta04 > 0 THEN N'1'
						WHEN oduta05 > 0 THEN N'2'
						WHEN oduta06 > 0 THEN N'3'
						WHEN oduta07 > 0 THEN N'4' END,
					CASE WHEN oduta04 > 0 THEN oduta04
						WHEN oduta05 > 0 THEN oduta05
						WHEN oduta06 > 0 THEN oduta06
						WHEN oduta07 > 0 THEN oduta07 END,
					CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN N'3'
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odute07 > 0 THEN N'1'
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odute08 > 0 THEN N'2'
						ELSE N'1' END,			
					CASE WHEN oduta04 > 0 OR oduta06 > 0 THEN odute11
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odute07 > 0 THEN odute07
						WHEN (oduta05 > 0 OR oduta07 > 0) AND odute08 > 0 THEN odute08
						ELSE 0 END,			
					CASE WHEN oduta04 > 0 THEN @adc_price*oduta04*odute11
						WHEN oduta06 > 0 THEN @adc_price*oduta06*odute11
						WHEN oduta05 > 0 AND odute07 > 0 THEN oduta05*odute07
						WHEN oduta05 > 0 AND odute08 > 0 THEN @adc_weight*oduta05*odute08
						WHEN oduta07 > 0 AND odute07 > 0 THEN oduta07*odute07
						WHEN oduta07 > 0 AND odute08 > 0 THEN @adc_weight*oduta07*odute08
						ELSE 0 END				
				FROM dbo.odut004 AS a
					JOIN dbo.odut005 AS b ON a.item_no = b.item_no AND a.odutd01 = b.odute01
					JOIN dbo.odut002 AS c ON b.odute01 = c.odutb01 AND b.odute04 = c.odutb02
					JOIN dbo.odut001 AS d ON b.odute01 = d.oduta01 AND b.odute05 = d.oduta02
				WHERE a.item_no = @as_item_no
					AND odutd01 = @as_country
				ORDER BY b.item_no,odute01,num,auto_seq;
				
			END		
		END
		ELSE IF (@ls_read_seq = N'2' AND @as_biz_type <> N'' AND @as_biz_no <> N'')
				OR
				(@ls_read_seq = N'3' AND @as_doc_type <> N'' AND @as_doc_no <> N'')
		BEGIN
		
			INSERT @at_result
			SELECT
				@as_country,@as_item_no,@as_item_sub,ldocc03,ldocc04,ldocc05,
				c.item_desc1,c.item_desc2,c.item_desce1,c.item_desce2,oduta03,
				CASE WHEN ldocc07a = N'1' THEN ldocc07b ELSE 0 END,
				N'KG',CASE WHEN ldocc07a = N'2' THEN ldocc07b ELSE 0 END,0,0,
				CASE WHEN ldocc07a = N'3' THEN ldocc07b ELSE 0 END,
				ldocc06a,ldocc06b,ldocc07a,ldocc07b,
				CASE WHEN ldocc06a IN (N'1',N'3') AND ldocc07a = N'3'
						THEN @adc_price * ldocc06b * ldocc07b
					WHEN ldocc06a IN (N'2',N'4') AND ldocc07a = N'1'
						THEN ldocc06b * ldocc07b
					WHEN ldocc06a IN (N'2',N'4') AND ldocc07a = N'2'
						THEN @adc_weight * ldocc06b * ldocc07b
					ELSE 0 END
			FROM dbo.fv_his_item(@as_doc_comp,@as_biz_type,@as_biz_no,
					@as_doc_type,@as_doc_no,@as_item_no,@as_item_sub,
					CASE WHEN @ls_read_seq = N'2' THEN N'1' ELSE N'2' END) AS a
				JOIN dbo.ldoc003 AS b ON a.doc_type = b.ldocc01a AND a.doc_no = b.ldocc01b
					AND a.lhisaid = b.ldocc02
				LEFT JOIN dbo.odut002 AS c ON c.odutb01 = @as_country AND c.odutb02 = b.ldocc05
				LEFT JOIN dbo.odut001 AS d ON d.oduta01 = c.odutb01 AND d.oduta02 = c.odutb03
			ORDER BY ldocc01a,ldocc01b,ldocc02,num;

		END

		IF NOT EXISTS(SELECT * FROM @at_result)
		BEGIN
			SET @li_i = @li_i + 1;
			SET @ls_read_seq = SUBSTRING(@as_read_seq,@li_i,1);
		END
		ELSE
			BREAK;
		
	END	
	
	RETURN;
	
END
GO
