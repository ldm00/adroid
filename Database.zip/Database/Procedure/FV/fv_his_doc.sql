﻿
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_his_doc]'))
   DROP FUNCTION [dbo].fv_his_doc;
GO
CREATE FUNCTION [dbo].fv_his_doc
(
	@as_doc_comp NVARCHAR(3),    --公司別
	@as_biz_type NVARCHAR(1),    --對象別
	@as_biz_no NVARCHAR(10),     --對象編號
	@as_dlv_biz NVARCHAR(20),    --交貨對象編號
	@as_item_no NVARCHAR(20),    --產品編號
    @as_item_sub NVARCHAR(20),    --產品副編號
    @as_TypeSub  NVARCHAR(200),    --单别、类别
    @as_item_type NVARCHAR(10),    --產品交易類別
    @as_doc_date     DATETIME      --交易日期
)

RETURNS @at_result TABLE
(
	doc_date     DATETIME,      --單據日期
	doc_type     NVARCHAR(2),   --單別
	tax_type     NVARCHAR(1),   --稅別
	doc_curr     NVARCHAR(6),   --幣別
	price        NUMERIC(19,5), --交易單價
	unit         NVARCHAR(10),  --/單位
	qty          NUMERIC(19,5), --數量
	qunit        NVARCHAR(20),  --單位
	comp_exrate  NUMERIC(19,5), --匯率
	doc_comp     NVARCHAR(3),   --公司
	doc_no       NVARCHAR(16),  --單號
	doc_no_seq   INT,           --單號數值號
	term         NVARCHAR(6),   --交易條件
	port_to      NVARCHAR(20),  --到貨港口
	doc_sub      NVARCHAR(2),   --類別
	tax_rate     NUMERIC(19,5), --稅率%
	discount     NUMERIC(19,5), --折扣%
	profit1      NUMERIC(19,5), --製造利潤%
	profit2      NUMERIC(19,5), --銷售利潤%
	supp_no      NVARCHAR(20),  --廠商編號
	ref_cost_curr NVARCHAR(6),  --參考成本
	ref_cost      NUMERIC(19,5),  --
	doc_staff     NVARCHAR(10)
)
AS
BEGIN
    --取公司列表
   	DECLARE @comp_list TABLE(doc_comp NVARCHAR(3));
    --1) @doc_comp為母公司的, 取各子公司列表: comp_list=bcom002(bcomb01=@doc_comp).bcomb02
    --2) comp_list.add @doc_comp
	WITH C1
    AS
   (  
      SELECT bcoma01 FROM bcom001 WHERE 
		  bcoma01=@as_doc_comp OR bcoma01 IN (SELECT bcomb02 FROM bcom002 WHERE bcomb01=@as_doc_comp)
    )
    INSERT INTO @comp_list (doc_comp)
	SELECT * FROM C1
	
    --交易 單別、類別 列表
    DECLARE @as_TypeStr  NVARCHAR(200)
    SET @as_TypeStr=@as_TypeSub;
    
	DECLARE @lt_doc_list TABLE(doc_type NVARCHAR(2),doc_sub NVARCHAR(2))
	IF @as_TypeSub<>''
	BEGIN
	    WHILE LEN(@as_TypeSub)>0
	    BEGIN
	        DECLARE @ls_db NVARCHAR(2), --分割單別
	                @ls_lb NVARCHAR(2), --分割類別
	                @li_Index INT
	        --获取单别
	        SELECT  @li_Index= CHARINDEX(',',@as_TypeSub,1)
	        IF @li_Index>1
	        BEGIN
	            SELECT @ls_db = LEFT(@as_TypeSub,@li_Index-1)
	            SET  @as_TypeSub = SUBSTRING(@as_TypeSub, @li_Index+1, LEN(@as_TypeSub) - @li_Index)
	        END
	        --获取類別
	        SELECT  @li_Index= CHARINDEX(',',@as_TypeSub,1)
	        IF @li_Index>1
	        BEGIN
	            SELECT @ls_lb = LEFT(@as_TypeSub,@li_Index-1)
	            SET  @as_TypeSub = SUBSTRING(@as_TypeSub, @li_Index+1, LEN(@as_TypeSub) - @li_Index)
	        END
	        ELSE
	        BEGIN
	            SELECT @ls_lb = ''
	            SET  @as_TypeSub = SUBSTRING(@as_TypeSub, @li_Index+1, LEN(@as_TypeSub) - @li_Index)
	        END
	        INSERT @lt_doc_list VALUES (@ls_db,@ls_lb)
	    END
	END 
	
	--產品交易類別	
	DECLARE @lt_item_type TABLE(item_type NVARCHAR(2))
	IF @as_item_type <> ''
	BEGIN
		WHILE LEN(@as_item_type) > 0
		BEGIN
			DECLARE @ls_kind NVARCHAR(2), --分割
					@li_indexA INT      
			SELECT  @li_indexA = CHARINDEX(',',@as_item_type,1)
			IF @li_indexA > 1
			BEGIN	
				SELECT @ls_kind = LEFT(@as_item_type,@li_indexA-1)
				SET @as_item_type = SUBSTRING(@as_item_type, @li_indexA+1, LEN(@as_item_type) - @li_indexA)
			END
			INSERT @lt_item_type VALUES (@ls_kind)
		END
	END
	
	DECLARE @A10000       NVARCHAR(10)
    --读取A10000
    SELECT @A10000=String1 FROM dbo.fn_GetSysSetup(@as_doc_comp,N'A10000','',0,0)
   
  -- .fv_his_doc.sql的参数：@as_TypeSub 如果类别传入空，表示不过滤类别
  IF  LEN(@as_TypeStr)<> 0
  BEGIN
    --1. 從lhis001中取
	INSERT INTO @at_result
	SELECT D.lhisa05,D.lhisa04a,D.lhisa06,D.lhisa08,D.lhisa21,D.lhisa13,D.lhisa12,D.lhisa09,D.comp_exrate,D.lhisa40,
	D.lhisa04b,D.lhisa04c,D.lhisa20,D.lhisa24,D.lhisa04d,D.lhisa07,D.lhisa25,D.lhisa26,D.lhisa27,D.lhisa30b,D.lhisa32,D.lhisa34,D.lhisa41
	FROM lhis001 AS D
	JOIN @comp_list AS H ON D.lhisa40=H.doc_comp
    JOIN @lt_doc_list AS P ON D.lhisa04a=P.doc_type AND (P.doc_sub='' OR D.lhisa04d=P.doc_sub)
	WHERE D.lhisa52='1' AND D.biz_type=@as_biz_type AND D.biz_no=@as_biz_no
	      AND (D.lhisa54=@as_dlv_biz OR @as_biz_type=N'M') AND (D.lhisa50='' OR D.lhisa50 IN (SELECT item_type FROM @lt_item_type)) 
	      AND D.lhisa02a=@as_item_no AND (@A10000=N'1' OR D.lhisa02b=@as_item_sub)
	      AND D.lhisa05>=@as_doc_date    
	      
	--2. 銷貨/出貨資料從單據中取
	IF EXISTS(SELECT * FROM @lt_doc_list WHERE doc_type = N'F1')
	BEGIN
	   INSERT INTO @at_result
	   SELECT E.doc_date,E.dinva01a,E.tax_type,E.doc_curr,F.dinvd14,F.dinvd10,F.dinvd09,F.dinvd06,E.comp_exrate,
	   E.doc_comp,E.dinva01b,0,E.dinva05d,E.dinva05b,E.dinva02,E.tax_rate,G.dordb61,G.dordb22a,G.dordb22b,G.dordb16b,G.dordb18,G.dordb20,E.doc_staff
	   FROM dinv001 AS E
	   JOIN @comp_list AS Q ON Q.doc_comp=E.doc_comp
	   JOIN dinv004 AS F ON E.dinva01a =F.dinvd01a AND E.dinva01b=F.dinvd01b
	   LEFT JOIN dord002 AS G ON G.dordb01a=F.dinvd02a AND G.dordb01b=F.dinvd02b AND G.item_no=F.item_no AND G.item_sub=F.item_sub AND G.dordb04=F.dinvd03
	   WHERE E.biz_type=@as_biz_type AND E.biz_no=@as_biz_no 
	   AND E.dinva15b=@as_dlv_biz AND (F.dinvd04='' OR F.dinvd04 IN (SELECT item_type FROM @lt_item_type)) 
	   AND F.item_no=@as_item_no AND (@A10000=N'1' OR F.item_sub=@as_item_sub)
	   AND E.doc_date>=@as_doc_date  
	END
	--3. 詢價資料從單據中取
	IF EXISTS(SELECT * FROM @lt_doc_list WHERE doc_type = N'D0' OR doc_type = N'D1')
	BEGIN
	   INSERT INTO @at_result
	   SELECT E.doc_date,E.eqrya01a,F.tax_type,F.doc_curr,F.eqryb20,F.eqryb09,F.eqryb05,F.eqryb06,F.comp_exrate,
	   E.doc_comp,E.eqrya01b,0,E.eqrya25a,E.eqrya08b,E.eqrya02,F.tax_rate,0,0,0,'','',0,E.doc_staff
	   FROM eqry001 AS E
	   JOIN @comp_list AS Q ON Q.doc_comp=E.doc_comp
	   JOIN eqry002 AS F ON E.eqrya01a =F.eqryb01a AND E.eqrya01b=F.eqryb01b
	   WHERE E.biz_type=@as_biz_type AND E.biz_no=@as_biz_no 
	   AND E.eqrya20b=@as_dlv_biz
	   AND F.item_no=@as_item_no AND (@A10000=N'1' OR F.item_sub=@as_item_sub)
	   AND E.doc_date>=@as_doc_date  
	END
  END
  ELSE
  BEGIN
       --1. 從lhis001中取
	INSERT INTO @at_result
	SELECT D.lhisa05,D.lhisa04a,D.lhisa06,D.lhisa08,D.lhisa21,D.lhisa13,D.lhisa12,D.lhisa09,D.comp_exrate,D.lhisa40,
	D.lhisa04b,D.lhisa04c,D.lhisa20,D.lhisa24,D.lhisa04d,D.lhisa07,D.lhisa25,D.lhisa26,D.lhisa27,D.lhisa30b,D.lhisa32,D.lhisa34,D.lhisa41
	FROM lhis001 AS D
	JOIN @comp_list AS H ON D.lhisa40=H.doc_comp
	WHERE D.lhisa52='1' AND D.biz_type=@as_biz_type AND D.biz_no=@as_biz_no
	      AND (D.lhisa54=@as_dlv_biz OR @as_biz_type=N'M') AND (D.lhisa50='' OR D.lhisa50 IN (SELECT item_type FROM @lt_item_type)) 
	      AND D.lhisa02a=@as_item_no AND (@A10000=N'1' OR D.lhisa02b=@as_item_sub)
	      AND D.lhisa05>=@as_doc_date
	
	 INSERT INTO @at_result
	   SELECT E.doc_date,E.dinva01a,E.tax_type,E.doc_curr,F.dinvd14,F.dinvd10,F.dinvd09,F.dinvd06,E.comp_exrate,
	   E.doc_comp,E.dinva01b,0,E.dinva05d,E.dinva05b,E.dinva02,E.tax_rate,G.dordb61,G.dordb22a,G.dordb22b,G.dordb16b,G.dordb18,G.dordb20,E.doc_staff
	   FROM dinv001 AS E
	   JOIN @comp_list AS Q ON Q.doc_comp=E.doc_comp
	   JOIN dinv004 AS F ON E.dinva01a =F.dinvd01a AND E.dinva01b=F.dinvd01b
	   LEFT JOIN dord002 AS G ON G.dordb01a=F.dinvd02a AND G.dordb01b=F.dinvd02b AND G.item_no=F.item_no AND G.item_sub=F.item_sub AND G.dordb04=F.dinvd03
	   WHERE E.biz_type=@as_biz_type AND E.biz_no=@as_biz_no 
	   AND E.dinva15b=@as_dlv_biz AND (F.dinvd04='' OR F.dinvd04 IN (SELECT item_type FROM @lt_item_type)) 
	   AND F.item_no=@as_item_no AND (@A10000=N'1' OR F.item_sub=@as_item_sub)
	   AND E.doc_date>=@as_doc_date      
	      
  END
			
	RETURN;
END
GO
