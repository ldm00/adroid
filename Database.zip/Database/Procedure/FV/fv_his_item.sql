IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_his_item]'))
   DROP FUNCTION [dbo].[fv_his_item];
GO
CREATE FUNCTION [dbo].[fv_his_item]
(
	@as_doc_comp NVARCHAR(3),
	@as_biz_type NVARCHAR(1),
	@as_biz_no NVARCHAR(10),
	@as_doc_type NVARCHAR(2),
	@as_doc_no NVARCHAR(16),
	@as_item_no NVARCHAR(20),
	@as_item_sub NVARCHAR(10),
	@as_read_type NVARCHAR(1)
)
RETURNS @at_result TABLE
(
	biz_type NVARCHAR(1),
	biz_no NVARCHAR(10),
	item_no NVARCHAR(20),
	item_sub NVARCHAR(10),
	lhisaid UNIQUEIDENTIFIER,
	doc_type NVARCHAR(2),
	doc_no NVARCHAR(16),
	doc_no_seq INT,
	doc_sub NVARCHAR(2),
	doc_date DATETIME,
	tax_type NVARCHAR(1),
	tax_rate NUMERIC(9,5),
	doc_curr NVARCHAR(5),
	comp_exrate NUMERIC(9,5),
	sys_exrate NUMERIC(9,5),
	item_desc1 NVARCHAR(30),
	item_desc2 NVARCHAR(30),
	item_desce1 NVARCHAR(30),
	item_desce2 NVARCHAR(30),
	biz_item_no NVARCHAR(20),
	bar_code NVARCHAR(30),
	oem_no NVARCHAR(30),
	hs_code NVARCHAR(20),
	cata_code NVARCHAR(20),
	asm_ver NVARCHAR(20),
	att_ver NVARCHAR(20),
	wunit NVARCHAR(6),
	munit NVARCHAR(6),
	qty NUMERIC(19,5),
	qunit NVARCHAR(6),
	qunit_trans1 NUMERIC(19,5),
	qunit_trans2 NUMERIC(19,5),
	pqty NUMERIC(19,5),
	punit NVARCHAR(6),
	punit_trans1 NUMERIC(19,5),
	punit_trans2 NUMERIC(19,5),
	cost_biz_type NVARCHAR(1),
	cost_biz_no NVARCHAR(10),
	cost_seq INT,
	cost_curr NVARCHAR(5),
	cost NUMERIC(19,5),
	term NVARCHAR(6),
	port_from NVARCHAR(20),
	port_to NVARCHAR(20),
	price_bas NUMERIC(19,5),
	price_doc NUMERIC(19,5),
	price_tax NUMERIC(19,5),
	price NUMERIC(19,5),
	prod_profit NUMERIC(19,5),
	sale_profit NUMERIC(19,5),
	discount NUMERIC(19,5)
)
AS
BEGIN
	IF @as_biz_type = N'' OR @as_biz_no = N'' 
		OR @as_item_no = N'' OR @as_doc_comp = N''
		RETURN;
	
	IF @as_doc_type = N'' OR @as_doc_no = N''
	BEGIN
		IF @as_item_sub = N''
			INSERT @at_result
			SELECT TOP 1
				biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
				lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
				lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
				item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
				lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
				lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
				lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
				CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
				CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
				lhisa26,lhisa27,lhisa25
			FROM dbo.lhis001
			WHERE lhisa40 = @as_doc_comp 
				AND biz_type = @as_biz_type
				AND biz_no = @as_biz_no
				AND lhisa02a = @as_item_no
				AND lhisa51 <> N'0'
				AND lhisa52 <> N'0'
			ORDER BY lhisa05 DESC;
		ELSE
			INSERT @at_result
			SELECT TOP 1
				biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
				lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
				lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
				item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
				lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
				lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
				lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
				CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
				CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
				lhisa26,lhisa27,lhisa25
			FROM dbo.lhis001
			WHERE lhisa40 = @as_doc_comp 
				AND biz_type = @as_biz_type
				AND biz_no = @as_biz_no
				AND lhisa02a = @as_item_no
				AND lhisa02b = @as_item_sub
				AND lhisa51 <> N'0'
				AND lhisa52 <> N'0'
			ORDER BY lhisa05 DESC;
		
	END
	ELSE
	BEGIN
		IF @as_item_sub = N''
			IF @as_read_type = N'1'
				INSERT @at_result
				SELECT TOP 1
					biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
					lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
					lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
					item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
					lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
					lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
					lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
					CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
					CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
					lhisa26,lhisa27,lhisa25
				FROM dbo.lhis001
				WHERE lhisa40 = @as_doc_comp 
					AND biz_type = @as_biz_type
					AND biz_no = @as_biz_no
					AND lhisa02a = @as_item_no
					--AND lhisa04a LIKE LEFT(@as_doc_type,1) + '%'
					AND lhisa04a LIKE CASE WHEN @as_doc_type LIKE N'[AB]%' THEN N'[AB]%' ELSE N'C%' END
					AND (lhisa04a <> @as_doc_type OR lhisa04b <> @as_doc_no)
					AND lhisa51 <> N'0'
					AND lhisa52 <> N'0'
				ORDER BY lhisa05 DESC;
			ELSE
				INSERT @at_result
				SELECT TOP 1
					biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
					lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
					lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
					item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
					lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
					lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
					lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
					CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
					CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
					lhisa26,lhisa27,lhisa25
				FROM dbo.lhis001
				WHERE lhisa40 = @as_doc_comp 
					AND biz_type = @as_biz_type
					AND biz_no = @as_biz_no
					AND lhisa02a = @as_item_no
					AND lhisa04a = @as_doc_type AND lhisa04b = @as_doc_no
					AND lhisa51 <> N'0'
					AND lhisa52 <> N'0'
				ORDER BY lhisa05 DESC;
		ELSE
			IF @as_read_type = N'1'
				INSERT @at_result
				SELECT TOP 1
					biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
					lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
					lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
					item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
					lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
					lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
					lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
					CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
					CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
					lhisa26,lhisa27,lhisa25
				FROM dbo.lhis001
				WHERE lhisa40 = @as_doc_comp 
					AND biz_type = @as_biz_type
					AND biz_no = @as_biz_no
					AND lhisa02a = @as_item_no
					AND lhisa02b = @as_item_sub
					--AND lhisa04a LIKE LEFT(@as_doc_type,1) + '%'
					AND lhisa04a LIKE CASE WHEN @as_doc_type LIKE N'[AB]%' THEN N'[AB]%' ELSE N'C%' END
					AND (lhisa04a <> @as_doc_type OR lhisa04b <> @as_doc_no)
					AND lhisa51 <> N'0'
					AND lhisa52 <> N'0'
				ORDER BY lhisa05 DESC;
			ELSE
				INSERT @at_result
				SELECT TOP 1
					biz_type,biz_no,lhisa02a,lhisa02b,lhisaid,lhisa04a,
					lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,
					lhisa08,comp_exrate,sys_exrate,item_desc1,item_desc2,
					item_desce1,item_desce2,biz_item_no,bar_code,oem_no,hs_code,cata_code,
					lhisa56,lhisa57,wunit,munit,lhisa12,lhisa09,lhisa10,
					lhisa11,lhisa16,lhisa13,lhisa14,lhisa15,lhisa30a,lhisa30b,lhisa31,
					lhisa32,lhisa34,lhisa20,lhisa23,lhisa24,lhisa22,lhisa21,
					CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END,
					CASE WHEN @as_doc_type LIKE N'C%' AND lhisa06 = N'1' THEN CASE WHEN @as_doc_type LIKE N'C%' THEN lhisa28 ELSE lhisa21 * (1 + lhisa07/100) END ELSE lhisa22 END,
					lhisa26,lhisa27,lhisa25
				FROM dbo.lhis001
				WHERE lhisa40 = @as_doc_comp 
					AND biz_type = @as_biz_type
					AND biz_no = @as_biz_no
					AND lhisa02a = @as_item_no
					AND lhisa02b = @as_item_sub
					AND lhisa04a = @as_doc_type AND lhisa04b = @as_doc_no
					AND lhisa51 <> N'0'
					AND lhisa52 <> N'0'
				ORDER BY lhisa05 DESC;	
	END
	
	RETURN;
END
GO
