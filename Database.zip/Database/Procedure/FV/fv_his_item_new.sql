﻿
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fv_his_item_new]'))
   DROP FUNCTION [dbo].fv_his_item_new;
GO
CREATE FUNCTION [dbo].fv_his_item_new
(
	@as_doc_comp   NVARCHAR(3),    --公司別
	@as_biz_type   NVARCHAR(1),    --對象別
	@as_biz_no     NVARCHAR(10),   --對象編號
	@as_dlv_biz    NVARCHAR(20)   --交貨對象編號
)

RETURNS @at_result TABLE
(
	item_no     NVARCHAR(20),    --產品編號
	item_sub    NVARCHAR(10),   --副編號
	biz_item_no NVARCHAR(20),   --對象產品編號
	bar_code    NVARCHAR(30),   --產品條碼
	oem_no      NVARCHAR(30),   --產品自定編號(OEM)
	item_desc1  NVARCHAR(30),   --產品中文名稱1
	item_desc2  NVARCHAR(30),   --產品中文名稱2
	item_desce1 NVARCHAR(30),   --產品英文名稱1
	item_desce2 NVARCHAR(30),   --產品英文名稱2
	inv_desc1   NVARCHAR(30),   --發票品名1
	inv_desc2   NVARCHAR(30),   --發票品名2
	category    NVARCHAR(10),   --產品大類
	doc_staff   NVARCHAR(10),   --產品承辦人
	sale_staff  NVARCHAR(10),   --產品負責業務
	po_staff    NVARCHAR(10),   --產品負責採購
	bitma01     NVARCHAR(10),  
	bitec03a    NVARCHAR(10),   
	bitec03f    NVARCHAR(10)
)
AS
BEGIN   
		DECLARE @A10000       NVARCHAR(10),
				@as_item_comp NVARCHAR(3)
		--读取A10000
		SELECT @A10000=String1 FROM dbo.fn_GetSysSetup(@as_doc_comp,N'A10000','',0,0)
		--2.1 item_comp = fv_item_comp(@doc_comp).item_comp	
		SELECT @as_item_comp = item_comp FROM dbo.fv_item_comp(@as_doc_comp);		
	    --1. 過濾 bbit001.biz_type, biz_no, bbita01=@biz_type,@biz_no,@dlv_biz
        --依@A10000的控管,@A10000='0'時,不需要副編號; PS. bbit001().item_no相同的只取一筆記錄
	    WITH C
	    AS
	     (
	      SELECT item_no,MIN(item_sub) AS item_sub,MIN(biz_item_no) AS biz_item_no,MIN(bar_code) AS bar_code,MIN(oem_no) AS oem_no,
	      MIN(item_desc1) AS item_desc1,MIN(item_desc2) AS item_desc2,MIN(item_desce1) AS item_desce1,MIN(item_desce2) AS item_desce2, MIN(doc_staff) AS doc_staff
	      FROM bbit001 WHERE biz_type=@as_biz_type AND biz_no=@as_biz_no AND bbita01=@as_dlv_biz
	      GROUP BY item_no,CASE WHEN @A10000 = N'0' THEN item_sub ELSE '1' END
	     ) 
	    INSERT INTO @at_result
	    SELECT item_no,item_sub,biz_item_no,bar_code,oem_no,item_desc1,item_desc2,item_desce1,item_desce2,
	    bcita12a,bcita12b,bitma04,doc_staff,bcita08,bcita22,bitma01,bitec03a,bitec03f
        FROM
	    (    
	    SELECT C.item_no,C.item_sub,C.biz_item_no,C.bar_code,C.oem_no,C.item_desc1,C.item_desc2,C.item_desce1,C.item_desce2,
	    B.bcita12a,B.bcita12b,bitma04,C.doc_staff,B.bcita08,B.bcita22,bitma01,bitec03a,bitec03f,
	    ROW_NUMBER() OVER ( PARTITION BY B.item_no,C.item_sub ORDER BY B.doc_comp DESC ) AS rn
	    FROM bcit001 AS B
	    JOIN C ON B.item_no=C.item_no
	    LEFT JOIN bitm001 ON bitm001.item_no=C.item_no
	    LEFT JOIN bite003 ON bite003.bitec01=C.item_no
	    WHERE B.doc_comp IN(@as_item_comp,'*') AND B.item_sub='' AND bcita51<>'0'
	    ) D WHERE D.rn=1		
	RETURN;
  
END
GO
