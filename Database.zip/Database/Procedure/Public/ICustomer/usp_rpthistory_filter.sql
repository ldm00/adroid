IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_rpthistory_filter') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_rpthistory_filter
GO
/*
�i���L�o�i���J������v����O�C��(���s�b��lhis001��������v)
*/
CREATE PROCEDURE [dbo].usp_rpthistory_filter
	@as_biz_type NVARCHAR(1),		--��H�O
	@as_biz_no NVARCHAR(16),		--��H�O
    @as_ProgId   NVARCHAR(8),		--�{���s�X 
    @as_CompID NVARCHAR(3),			--�n�����q
	@as_Arigd04 NVARCHAR(10),		--�ާ@���O
    @as_UserID NVARCHAR(10),		--�n���Τ�
	@as_RoleId NVARCHAR(10),		--�n�J����
	@as_danbie NVARCHAR(10)         --��O
AS
BEGIN 
	--1.���ͥ����ӳ�O���
	SELECT * INTO #lhis001 FROM lhis001 WHERE 1=2
	INSERT INTO #lhis001
	(recid,lhisaid,biz_type,biz_no,lhisa02a,lhisa02b,lhisa03,
	lhisa04a,lhisa04b,lhisa04c,lhisa04d,lhisa05,lhisa06,lhisa07,lhisa08,comp_exrate,sys_exrate,
	lhisa09,lhisa10,lhisa11,lhisa12,lhisa13,lhisa14,lhisa15,lhisa16,
	lhisa20,lhisa21,lhisa22,
	lhisa23,lhisa24,lhisa25,lhisa26,lhisa27,lhisa28,
	lhisa30a,lhisa30b,lhisa31,lhisa32,lhisa33,lhisa34,lhisa35,
	lhisa40,lhisa41,lhisa42,
	lhisa50,lhisa51,lhisa52,lhisa53,lhisa54,lhisa55,
	biz_item_no,bar_code,oem_no,hs_code,cata_code,
	lhisa56,lhisa57,create_user,create_date,modify_user,modify_date
	)	
	SELECT 
	NEWID(),NEWID(),@as_biz_type,@as_biz_no,A.item_no,A.item_sub,A.dinvd03,
	B.dinva01a,B.dinva01b,0,B.dinva02,B.doc_date,B.tax_type,B.tax_rate,B.doc_curr,B.comp_exrate,B.sys_exrate,
	dinvd06,dinvd07,dinvd08,dinvd09,dinvd10,dinvd11,dinvd12,dinvd13,
	ISNULL(D.dorda25a,''),dinvd14,(CASE WHEN C.dordb10a = 0 OR dinvd12 = 0 THEN 0 ELSE ISNULL(C.dordb23*C.dordb10b*dinvd11/(C.dordb10a*dinvd12),0) END),
	ISNULL(D.dorda08a,''),ISNULL(D.dorda08b,''),ISNULL(C.dordb61,0),ISNULL(C.dordb22a,0),ISNULL(C.dordb22b,0),ISNULL(C.dordb64,0),
	ISNULL(C.dordb16a,''),ISNULL(C.dordb16b,''),ISNULL(C.dordb17,0),ISNULL(C.dordb18,''),ISNULL(C.dordb19,0),ISNULL(C.dordb20,0),ISNULL(C.dordb21,0),
	ISNULL(D.doc_comp,''),ISNULL(D.doc_staff,''),ISNULL(D.staff_group,''),
	ISNULL(C.dordb02,'0'),ISNULL(C.dordb56,''),'1',B.dinva15a,B.dinva15b,0,	
	A.biz_item_no,A.bar_code,A.oem_no,A.hs_code,ISNULL(C.cata_code,''),
	ISNULL(C.dordb72,''),ISNULL(C.dordb73,''),A.create_user,A.create_date,A.modify_user,A.modify_date
	FROM dinv004 AS A
	LEFT JOIN dinv001 AS B ON A.dinvd01a = B.dinva01a AND A.dinvd01b = B.dinva01b 
	LEFT JOIN dord002 AS C ON C.dordb01a = A.dinvd02a AND C.dordb01a = A.dinvd02a 
					AND C.item_no = A.item_no AND C.item_sub = A.item_sub AND C.dordb04 = A.dinvd03
	LEFT JOIN dord001 AS D ON D.dorda01a = C.dordb01a AND D.dorda01b = C.dordb01b 
	WHERE A.dinvd01a = @as_danbie AND B.biz_type = @as_biz_type AND B.biz_no = @as_biz_no


	--2.�U���L�o���q�O�M�\Ū�v��

	--2.1�����q�O�C��comp_list[]:
	DECLARE @comp_list TABLE(doc_comp NVARCHAR(3));
	--�H�l���q�n����, comp_list�u�tLogin.Comp
	--�H�����q�n����, comp_list�tLogin.Comp�������l���q, �����tLogin.Comp�����q����
	WITH C1 AS
	(
	SELECT bcoma01 FROM bcom001
	WHERE EXISTS(SELECT * FROM bcom002 WHERE bcomb02 = @as_CompID) AND bcoma01 = @as_CompID 
	UNION
	SELECT bcoma01 FROM bcom001
	WHERE bcoma01 IN (SELECT bcomb02 FROM bcom002 WHERE bcomb01 = @as_CompID)  
	)
	INSERT INTO @comp_list (doc_comp)
	SELECT * FROM C1

	--2.3���s�դU���v�����Τ�
	--�L�o��o�ǳ�O�O�_���d���v
	--IProg.GetQueryRightByDocType(doc_type[i])="1","2","3"
	DECLARE @query_right NVARCHAR(1),
			@right_group NVARCHAR(20)

	DECLARE @user_list TABLE(users NVARCHAR(10))
	SELECT @query_right = arigf04d FROM arig006 
			WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
						  AND arigf07 = @as_danbie AND arigf06 = '1'
			IF @@RowCount = 0
			BEGIN
				SELECT TOP 1 @query_right = arigf04d FROM arig006 
				WHERE portal_id = @as_ProgId AND arigf01 = @as_Arigd04 AND arigf03 = 'M'
							  AND arigf07 = @as_danbie
			END
			IF(@query_right = '1')
				INSERT INTO @user_list(users) VALUES (@as_UserID) 
			IF(@query_right = '2')--�p�G�d���v�O"2"-�P�ժ�, �n�A����s��= IProg.GetDefaultGroupByDocType(doc_type[i])
			BEGIN
				SELECT @right_group = dbo.fn_GetDefaultGroupByDocType(@as_ProgId,@as_UserID,@as_RoleId,@as_danbie)
				INSERT INTO @user_list(users)
				SELECT arigc01 FROM arig003 WHERE right_group = @right_group
			END
			IF(@query_right = '3')
			BEGIN
				INSERT INTO @user_list(users)
				SELECT arigb01 FROM arig002 
			END

	--3.�R���L�o���
	DECLARE @lu_Guid UNIQUEIDENTIFIER,
			@ls_comp NVARCHAR(10),
			@ls_doc_staff NVARCHAR(20)

	DECLARE Cur_history CURSOR FOR
	SELECT recid,lhisa40,lhisa41 FROM #lhis001
	OPEN Cur_history 
	FETCH NEXT FROM Cur_history INTO @lu_Guid,@ls_comp,@ls_doc_staff
	WHILE @@FETCH_STATUS = 0
	BEGIN
		--���q�L�o
		IF NOT EXISTS(SELECT * FROM @comp_list WHERE doc_comp = @ls_comp)
		BEGIN
			DELETE #lhis001 WHERE recid = @lu_Guid
			FETCH NEXT FROM Cur_history INTO @lu_Guid,@ls_comp,@ls_doc_staff
		END
		--�\Ū�v���L�o
		IF NOT EXISTS(SELECT * FROM @user_list WHERE users = @ls_doc_staff)
		BEGIN
			DELETE #lhis001 WHERE recid = @lu_Guid
			FETCH NEXT FROM Cur_history INTO @lu_Guid,@ls_comp,@ls_doc_staff	
		END
		FETCH NEXT FROM Cur_history INTO @lu_Guid,@ls_comp,@ls_doc_staff	
	END

	SELECT * FROM  #lhis001
	DROP TABLE #lhis001
END
GO