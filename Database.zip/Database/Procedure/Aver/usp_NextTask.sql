﻿
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_NextTask') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_NextTask
GO
CREATE PROCEDURE [dbo].[usp_NextTask]
	@as_doc_type NVARCHAR(2),		  
	@as_doc_no NVARCHAR(10),
	@as_status_in NVARCHAR(2),
	@as_LoginUser NVARCHAR(10),
	@as_company NVARCHAR(3),		  
	@as_content NVARCHAR(MAX),
	@as_qcontent NVARCHAR(MAX),
	@as_type  NVARCHAR(2), --下階/子任務指定對象別
	@as_no NVARCHAR(10),    --下階/子任務指定對象代號
	@as_trans_code NVARCHAR(20)
AS  
BEGIN
	DECLARE @ls_type NVARCHAR(10),
			@ls_exec_user NVARCHAR(10),  
			@ls_task_no NVARCHAR(10),
			@ls_content NVARCHAR(MAX),
			@ls_user_set NVARCHAR(1), 
			@ls_user_settype NVARCHAR(2),
			@ls_user_setno NVARCHAR(10),
			@ls_mod_type NVARCHAR(2),
			@ls_mod_name NVARCHAR(100),
			@ls_status_out NVARCHAR(2),
			@ls_sub_set NVARCHAR(1),
			@ls_top_no NVARCHAR(10),
			@ls_qno NVARCHAR(10),
			@ls_qset NVARCHAR(1),
			@lt_vss_time DATETIME,
			@ls_qstatus_out NVARCHAR(2),
			@li_track_id INT,
			@li_seq_id INT,
			@li_active_from INT,
			@ls_mark NVARCHAR(1),
			@li_cur_qdlevel INT
	DECLARE @lt_task_id TABLE(seq_id INT PRIMARY KEY,doc_no NVARCHAR(10))

	SELECT @ls_type = [type],@ls_exec_user = exec_user,@ls_mod_type = mod_type,@ls_mod_name = mod_name,@li_cur_qdlevel = qdlevel,
			@ls_top_no = top_no,@ls_qno = qno,@lt_vss_time = vss_time
	FROM aver007 WHERE doc_type = @as_doc_type AND doc_no = @as_doc_no
	--@as_type, @as_no兩個任一為空, 即置 @as_type="U", as_no=curr_aver007.user
	IF @as_type = '' OR @as_no = ''
		SELECT @as_type = 'U' , @as_no = @ls_exec_user
		
	--Step 1.		依工作流程設定, 產生下階任務
	DECLARE next_aver009_cursor CURSOR FOR 
	SELECT task_no,user_set,user_settype,user_setno,status_out,sub_set,qset,qstatus_out,track_id,seq_id FROM aver009 
	WHERE [type] = @ls_type AND status_in = @as_status_in AND trans=@as_trans_code AND seq_id <> -1
	OPEN next_aver009_cursor
	FETCH NEXT FROM next_aver009_cursor INTO @ls_task_no,@ls_user_set,@ls_user_settype,@ls_user_setno,@ls_status_out,@ls_sub_set,
			@ls_qset,@ls_qstatus_out,@li_track_id,@li_seq_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @ls_type_2 NVARCHAR(10),
				@ld_score FLOAT,
				@ls_title NVARCHAR(256),
				@ls_assign_type NVARCHAR(2),
				@ls_assign_no NVARCHAR(10),
				@li_priority INT,
				@ls_newNo NVARCHAR(10),
				@li_qdlevel INT
		--next_aver007 
		SELECT 	@ls_type_2 = [type],@ld_score = score ,@ls_title = title,@ls_content = [content],@li_priority = priority
		FROM aver007 WHERE doc_type = 'T0' AND doc_no = @ls_task_no
		--assign_type,assign_no
		IF @ls_user_set = '0'
			SELECT @ls_assign_type = 'U',@ls_assign_no = @ls_exec_user
		IF @ls_user_set = '1'
			SELECT @ls_assign_type = @as_type,@ls_assign_no = @as_no
		IF @ls_user_set = '2' OR @ls_user_set = '4' OR @ls_user_set = '5'
			SELECT @ls_assign_type = @ls_user_settype,@ls_assign_no = @ls_user_setno
		IF @ls_user_set = '3'
		BEGIN
			DECLARE @ls_averm04 NVARCHAR(10)
			SELECT @ls_averm04 = ISNULL(averm04,'') FROM aver013 
			WHERE averm01=@ls_mod_name AND averm02=@ls_user_setno AND auto_seq=0 
			IF @@ROWCOUNT >0
				SELECT @ls_assign_type = 'U',@ls_assign_no = @ls_averm04
			ELSE
				SELECT @ls_assign_type = 'U',@ls_assign_no = @ls_exec_user				
		END
		
		SELECT @ls_newNo = dbo.fn_AutoKey(@as_company,'T1','','',GETDATE(),'','yymdd9999');

		INSERT INTO aver007
		(recid,doc_type,doc_no,
		title,[content],close_desc,
		[type],score,assign_type,assign_no,
		exec_user,
		status,status_date,priority,src_type,src_no,
		parent_no,
		top_no,etsd,etd,start_date,
		due_date,
		qno,
		vss_time,mod_type,mod_name,
		track_no,
		wake_no,
		last_user,last_date,create_user,create_date,doc_status,modify_user,modify_date
		)
		VALUES
		(NEWID(),'T1',@ls_newNo,
		@ls_title,(CASE WHEN @as_content= '' AND @as_qcontent = '' THEN @ls_content ELSE @as_content + @as_qcontent END),'',
		@ls_type_2,@ld_score,@ls_assign_type,@ls_assign_no,
		CASE WHEN @ls_status_out > '1' AND  @ls_assign_type='U' THEN @ls_assign_no ELSE '' END,
		@ls_status_out,GETDATE(),@li_priority,@as_doc_type,@as_doc_no,
		CASE WHEN @ls_sub_set = '1' THEN @as_doc_no ELSE '' END,
		@ls_top_no,GETDATE(),GETDATE(),CASE WHEN @ls_status_out = '0' OR @ls_status_out > '1' THEN GETDATE() ELSE '1900-01-01 00:00:00.000' END,
		CASE WHEN @ls_status_out = '0' THEN GETDATE() ELSE '1900-01-01 00:00:00.000' END,
		CASE WHEN @ls_qset ='1' THEN @ls_qno ELSE '' END,
		@lt_vss_time,@ls_mod_type,@ls_mod_name,
		'',
		'',
		'','',@as_LoginUser,GETDATE(),'N','',''
		) 
		--@@@@@@@@@@@@@@@@@@@@@ qdlevel	問題處理層級
		DECLARE @ls_qno_T NVARCHAR(10),
				@ls_exec_user_T NVARCHAR(10),
				@ls_type_T NVARCHAR(10),
				@li_TT INT,
				@ls_assign_type_T NVARCHAR(2),
				@ls_assign_no_T NVARCHAR(10)
				
		SELECT @li_TT = 0
		SELECT @ls_qno_T = qno,@ls_exec_user_T = exec_user,@ls_type_T = type,@ls_assign_type_T = assign_type,@ls_assign_no_T = assign_no
		FROM aver007 WHERE doc_type = 'T1' AND doc_no = @ls_newNo
		--1. 如果this.qno="", this.qdlevel=0;
		IF @ls_qno_T = ''
		BEGIN
			SET @li_qdlevel = 0
			SET @li_TT = 1
		END
		--2. 如果this.exec_user="", this.qdlevel=curr_aver007.qdlevel;	
		
		IF @ls_exec_user_T = '' AND @li_TT = 0
		BEGIN
			IF @ls_assign_type_T = 'U'
				SET @ls_exec_user_T = @ls_assign_no_T
			IF @ls_exec_user_T = ''
			BEGIN
				SET @li_qdlevel = @li_cur_qdlevel
				SET @li_TT = 1	
			END		
		END
		--3. 同一問題單，此人有正在追蹤該問題的任務，由qdlevel=追蹤該問題的任務的qdlevel
		--PS. 存在aver007((exec_user=tmp_user or (exec_user="" && assign_type="U" && assign_no=tmp_user)),qno=this.qno,type="t_track",status!=0).qdlevel, 有多筆取最小的qdlevel
		IF @li_TT = 0
		BEGIN
			SELECT * FROM aver007 
			WHERE (exec_user = @ls_exec_user_T OR (exec_user='' AND assign_type='U' AND assign_no=@ls_exec_user_T)) 
				AND qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
			IF @@ROWCOUNT > 0
			BEGIN
				SELECT @li_qdlevel = MIN(qdlevel) FROM aver007 
				WHERE (exec_user = @ls_exec_user_T OR (exec_user='' AND assign_type='U' AND assign_no=@ls_exec_user_T)) 
				AND qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
				SET @li_TT = 1
			END	
			ELSE
			BEGIN
				--4.1 上面4.未取到qd_level,再取同一問題單, 別人正在追蹤該問題的任務,則qdlevel=追蹤該問題的任務的qdlevel
				SELECT * FROM aver007 
				WHERE qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
				IF @@ROWCOUNT > 0
				BEGIN
					SELECT @li_qdlevel = MAX(qdlevel) FROM aver007 
					WHERE qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
					SET @li_TT = 1
				END
			END			
		END

		--5. 追蹤任務，層級取其他人最大層級加1
		--PS. 若存在aver007(((exec_user!="" && exec_user!=tmp_user) or (exec_user="" && assign_type="U" && assign_no!=tmp_user)),qno=this.qno,type="t_track",status!=0).qdlevel+1, 有多筆取最大的qdlevel+1
		IF @ls_type_T = 't_track'
		BEGIN	
			SELECT * FROM aver007 
			WHERE ((exec_user <> '' AND exec_user <> @ls_exec_user_T) OR (exec_user='' AND assign_type='U' AND assign_no<>@ls_exec_user_T)) 
				AND qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
			IF @@ROWCOUNT > 0
			BEGIN		
				SET @li_TT = 1		
				SELECT @li_qdlevel = MAX(qdlevel)+1 FROM aver007 
				WHERE ((exec_user <> '' AND exec_user <> @ls_exec_user_T) OR (exec_user='' AND assign_type='U' AND assign_no<>@ls_exec_user_T)) 
					AND qno = @ls_qno_T AND type='t_track' AND status<>'0' AND doc_no <> @ls_newNo
			END
			ELSE
				SET @li_qdlevel = 0			
		END

		--5.
		IF @li_TT = 0
		BEGIN
			SET @li_qdlevel = @li_cur_qdlevel
			SET @li_TT = 1	
		END
		UPDATE aver007 SET qdlevel = @li_qdlevel WHERE doc_type = 'T1' AND doc_no = @ls_newNo
		--@@@@@@@@@@@@@@@@@@@@@
		
		INSERT INTO @lt_task_id(seq_id,doc_no) VALUES(@li_seq_id,@ls_newNo);

		FETCH NEXT FROM next_aver009_cursor INTO @ls_task_no,@ls_user_set,@ls_user_settype,@ls_user_setno,@ls_status_out,@ls_sub_set,
			@ls_qset,@ls_qstatus_out,@li_track_id,@li_seq_id
	END
	CLOSE next_aver009_cursor
	DEALLOCATE next_aver009_cursor

	--Step 2.		寫入追蹤任務序號
	DECLARE aver009_cursor_new CURSOR FOR 
	SELECT track_id,seq_id FROM aver009 
	WHERE [type] = @ls_type AND status_in = @as_status_in AND trans=@as_trans_code AND seq_id <> -1
	OPEN aver009_cursor_new
	FETCH NEXT FROM aver009_cursor_new INTO @li_track_id,@li_seq_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF 	@li_track_id >0
		BEGIN
			DECLARE @ls_no_1 NVARCHAR(10),
					@ls_no_2 NVARCHAR(10),
					@li_qdlevel_1 INT
			SELECT @ls_no_1=doc_no FROM @lt_task_id WHERE seq_id = @li_seq_id
			SELECT @ls_no_2=doc_no FROM @lt_task_id WHERE seq_id = @li_track_id
			UPDATE aver007 SET track_no = @ls_no_2
			WHERE doc_type = 'T1' AND doc_no= @ls_no_1
			
			SELECT @li_qdlevel_1 = qdlevel FROM aver007 WHERE doc_type = 'T1' AND doc_no= @ls_no_1
			UPDATE aver007 SET qdlevel = @li_qdlevel_1
			WHERE doc_type = 'T1' AND doc_no= @ls_no_2
		END
		FETCH NEXT FROM aver009_cursor_new INTO @li_track_id,@li_seq_id
	END
	CLOSE aver009_cursor_new
	DEALLOCATE aver009_cursor_new

	--Step 3.		Update相關問題單
	SELECT @li_seq_id = seq_id,@ls_qstatus_out = qstatus_out
	FROM aver009 WHERE  [type] = @ls_type AND status_in = @as_status_in AND trans=@as_trans_code AND seq_id = -1;
	IF @@ROWCOUNT = 0
	BEGIN
		SELECT @li_seq_id = seq_id,@ls_qstatus_out = qstatus_out
		FROM aver009 WHERE  [type] = @ls_type AND status_in = '*' AND trans=@as_trans_code AND seq_id = -1;
			--deal_aver009.status_out!="*" 才做
		IF @@ROWCOUNT = 0
			RETURN;
	END
	DECLARE @ls_no NVARCHAR(10)
	DECLARE task_cursor CURSOR FOR 
	SELECT doc_no FROM @lt_task_id 
	OPEN task_cursor
	FETCH NEXT FROM task_cursor INTO @ls_no
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @ls_dstatus NVARCHAR(20),
				@ls_averh06_old NVARCHAR(2),
				@ls_averh06_new NVARCHAR(2),
				@lt_averh07_old DATETIME,
				@lt_averh07_new DATETIME,
				@ls_close_desc_old NVARCHAR(256),
				@ls_close_desc_new NVARCHAR(256),
				@li_auto_seq INT,
				@ls_dstatus_old NVARCHAR(20),
				@ls_qno_A NVARCHAR(10),
				@li_qdlevel_now INT
		SELECT @ls_qno_A = qno,@li_qdlevel_now = qdlevel FROM aver007 WHERE doc_type = 'T1' AND doc_no = @ls_no

		SELECT @ls_averh06_old = averh06,@lt_averh07_old = averh07,@ls_close_desc_old = close_desc ,@ls_dstatus = dstatus
		FROM aver008 WHERE averh01='Q1' AND averh02= @ls_qno_A

		SET @ls_dstatus_old = @ls_dstatus

		IF @ls_qno_A <> '' AND @ls_qstatus_out > '0' AND @ls_qstatus_out <> '*'
		BEGIN
			SELECT @ls_dstatus = dstatus FROM aver008 WHERE averh01='Q1' AND averh02= @ls_qno_A
			--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			--多層級處理狀況	dstatus[curr_aver007.qdlevel]=deal_aver009.qstatus_out
			--1. curr_aver007.qdlevel 不在0~20間, curr_aver007.qdlevel=0
			IF @li_qdlevel_now> 20 OR @li_qdlevel_now < 0
				SET  @li_qdlevel_now = 0
			--dstatus[curr_aver007.qdlevel]=deal_aver009.qstatus_out
			IF LEN(@ls_dstatus) >= @li_qdlevel+1
				SET @ls_dstatus = STUFF(@ls_dstatus,@li_qdlevel_now+1,1,@ls_qstatus_out)
			ELSE			
				SET @ls_dstatus = @ls_dstatus + @ls_qstatus_out
				
			--2. 如果deal_aver009.qstatus_out = "0"-結案 且 存在dstatus[x>curr_aver007.qdlevel]!="0"
			DECLARE @li INT,
					@li_LEN INT
			SELECT @li=0,@li_LEN = LEN(@ls_dstatus)
			IF @ls_qstatus_out = '0' --dstatus[x>curr_aver007.qdlevel]!="0"
			BEGIN
				WHILE(@li < (@li_LEN))
				BEGIN
					IF @li>@li_qdlevel_now+1
					BEGIN
						SET @ls_dstatus = STUFF(@ls_dstatus,@li,1,'0')
						--UPDATE x_aver007=aver007("T1",q_no=aver007.qno,qdlevel=x,status!=0)
						UPDATE aver007 
						SET status = '0',
							exec_user = @as_LoginUser,
							status_date = GETDATE(),
							start_date = (CASE WHEN start_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE start_date END),
							due_date = (CASE WHEN due_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE due_date END),
							close_desc = '系統結案 by '+@as_doc_no
						WHERE doc_type = 'T1' AND doc_no = @ls_qno_A AND qdlevel = @li AND status <> '0'
					END
					SET @li = @li+1;
				END
			END
			--從dstatus最後向前判斷 /如果出現dstatus[x]!=('0'), averh06=dstatus[x]/如果出現dstatus[x]!=('0'), averh06=dstatus[x]
			SELECT @ls_averh06_new = '0' --如果各級狀態都已結案，dstatus[x]=('0'), averh06=0
			SELECT @li_LEN = LEN(@ls_dstatus)
			WHILE(@li_LEN > 0)
			BEGIN
				IF SUBSTRING(@ls_dstatus,@li_LEN,1) <> '0'
				BEGIN
					SET @ls_averh06_new = SUBSTRING(@ls_dstatus,@li_LEN,1)	
					BREAK;
				END
				SET @li_LEN = @li_LEN -1
				IF @li_LEN < 0
					BREAK;
			END	
			--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			UPDATE aver008 
			SET averh06 = @ls_averh06_new,
				averh07 = (CASE WHEN (averh06 <> @ls_averh06_new AND averh07 = '1900-01-01 00:00:00.000') THEN GETDATE() ELSE averh07 END),
				dstatus = @ls_dstatus
			WHERE averh01='Q1' AND averh02= @ls_qno_A

			SELECT @li_auto_seq = ISNULL(MAX(auto_seq),0) 
			FROM aver012 WHERE averl01='Q1' AND averl02= @ls_qno
			SELECT @ls_averh06_new = averh06,@lt_averh07_new = averh07,@ls_close_desc_new = close_desc FROM aver008 WHERE averh01='Q1' AND averh02= @ls_qno_A
			--如果aver008有被Update, 要再Update aver012-問題異動明細
			IF 	@ls_averh06_old <> @ls_averh06_new OR  @lt_averh07_old <> @lt_averh07_new OR @ls_close_desc_old <> @ls_close_desc_new
			BEGIN
				INSERT INTO aver012(recid,averl01,averl02,auto_seq,status_in,status_out,[time],task_no,task_type,[user],remark,dstatus_in,dstatus_out)
				VALUES
				(NEWID(),'Q1',@ls_qno_A,@li_auto_seq+1,@ls_averh06_old,@ls_averh06_new,GETDATE(),@as_doc_no,@ls_type,@as_LoginUser,'',@ls_dstatus_old,@ls_dstatus)
			END
		END
		FETCH NEXT FROM task_cursor INTO @ls_no
	END
	CLOSE task_cursor
	DEALLOCATE task_cursor

	--Step 4.		問題單相關的任務
	--4.1 如果@qcontent不為空,curr_aver008.content 需增加這一段
	--IF @as_qcontent <> ''
	--	UPDATE aver008 SET [content] = [content] + ' ' + @as_qcontent  WHERE averh01='Q1' AND averh02=@ls_qno
	--4.2 如果curr_aver008.averh06="0" -問題單已結案
	DECLARE @ls_h06 NVARCHAR(1),
			@ls_h02 NVARCHAR(10),
			@ls_exec_user_x NVARCHAR(10),
			@ls_exec_user_y NVARCHAR(10),
			@ls_assign_type_y  NVARCHAR(2),
			@ls_assign_no_y  NVARCHAR(10),
			@ls_assign_no_x  NVARCHAR(10)
	SELECT @ls_h02 = averh02,@ls_h06 = averh06 FROM aver008 WHERE averh01='Q1' AND averh02=@ls_qno
	IF @ls_h06 = '0'
	BEGIN
		UPDATE aver007 
		SET status = '0',
		exec_user = @as_LoginUser,
		status_date = GETDATE(),
		start_date = (CASE WHEN start_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE start_date END),
		due_date = (CASE WHEN due_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE due_date END),
		close_desc = '系統結案 by '+@as_doc_no
		WHERE doc_type = 'T1' AND qno = @ls_h02 AND status <> '0'
	END
	ELSE
	BEGIN
		--4.3 否則, 同一個exec_user, 對此問題單,如果有非追蹤的任務,而追蹤任務未結案的,將追蹤任務結案
		WITH C1 AS
		(
			SELECT recid,(CASE WHEN exec_user ='' THEN assign_no END) AS exec_user_x FROM aver007 
			WHERE doc_type = 'T1' AND qno = @ls_h02 AND [type] = 't_track' AND status <> '0'	
		),C2 AS
		(
			SELECT exec_user AS exec_user_y,assign_type AS assign_type_y,assign_no AS assign_no_y FROM aver007 
		WHERE doc_type = 'T1' AND qno = @ls_h02 AND [type] <> 't_track' AND status <> '0'
		),C3 AS
		(
		SELECT * FROM C1 WHERE EXISTS(SELECT * FROM C2 WHERE exec_user_x <> '' AND exec_user_x =exec_user_y OR 
		(exec_user_y = '' AND assign_type_y = 'U' AND assign_no_y = exec_user_x))
		)
		UPDATE aver007 
		SET status = '0',
		--exec_user = @as_LoginUser,
		status_date = GETDATE(),
		start_date = (CASE WHEN start_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE start_date END),
		due_date = (CASE WHEN due_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE due_date END),
		close_desc = '系統結案 by '+@as_doc_no
		WHERE EXISTS(SELECT * FROM C3 WHERE aver007.recid = C3.recid)
	END
END
GO

