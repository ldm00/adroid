﻿
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].usp_TaskUpdate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
   DROP PROCEDURE dbo.usp_TaskUpdate
GO
CREATE PROCEDURE [dbo].[usp_TaskUpdate]
	@as_doc_type NVARCHAR(2),		  
	@as_doc_no NVARCHAR(10),
	@as_close_desc NVARCHAR(256),
	@as_LoginUser NVARCHAR(10),			  
	@as_trans_code NVARCHAR(20),
	@as_GUID NVARCHAR(100),
	@as_q_desc NVARCHAR(MAX)
AS
BEGIN
	DECLARE @ls_type NVARCHAR(10),
			@ls_status  NVARCHAR(2),
			@ls_status_out NVARCHAR(2),
			@ls_qno NVARCHAR(10),
			@ls_qstatus_out NVARCHAR(2),
			@li_qdlevel INT,
			@ls_dstatus NVARCHAR(20),
			@ls_dstatus_old NVARCHAR(20)

	SELECT @ls_type = [type],@ls_status = status,@ls_qno = qno,@li_qdlevel = qdlevel
	FROM aver007 WHERE doc_type = @as_doc_type AND doc_no = @as_doc_no

	--Step 1.當前任務賦值
    --取deal_aver009=aver009(type,status_in = curr_aver007.type,status; trans="vss_get",seq_id=-1)
	IF @as_GUID <> '' 
	BEGIN
		SELECT @ls_status_out = status_out ,@ls_qstatus_out = qstatus_out
		FROM aver009 WHERE recid = @as_GUID
	END
	ELSE
	BEGIN
		SELECT @ls_status_out = status_out ,@ls_qstatus_out = qstatus_out
		FROM aver009 WHERE  [type] = @ls_type AND status_in = @ls_status AND trans=@as_trans_code AND seq_id = -1;
		IF @@ROWCOUNT = 0
		BEGIN
			SELECT @ls_status_out = status_out ,@ls_qstatus_out = qstatus_out
			FROM aver009 WHERE  [type] = @ls_type AND status_in = '*' AND trans=@as_trans_code AND seq_id = -1;
				--deal_aver009.status_out!="*" 才做
			IF @@ROWCOUNT = 0
				RETURN;
		END
	END
	IF @ls_status_out = '*'
	RETURN;
	
	--UPDATE aver007	任務單主檔
	UPDATE aver007 
	SET status = @ls_status_out,
		status_date = (CASE WHEN status <> @ls_status_out THEN GETDATE() ELSE (CASE WHEN status_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE status_date END) END),
		start_date = (CASE WHEN (status <> @ls_status_out AND @ls_status_out <> '1' AND start_date ='1900-01-01 00:00:00.000') THEN GETDATE() ELSE start_date END),
		due_date = (CASE WHEN (status <> @ls_status_out AND @ls_status_out = '0') THEN GETDATE() ELSE due_date END),
		close_desc = (CASE WHEN @ls_status_out = 0 THEN close_desc+@as_close_desc ELSE close_desc END),
		exec_user = (CASE WHEN (status <> @ls_status_out AND @ls_status_out >= '0' AND exec_user = '') THEN @as_LoginUser ELSE exec_user END),
		[content] = [content]+@as_q_desc
		WHERE doc_type = @as_doc_type AND doc_no = @as_doc_no
	--重读更新过的aver007:status
	SELECT @ls_status = status
	FROM aver007 WHERE doc_type = @as_doc_type AND doc_no = @as_doc_no

	--如果有問題單號 curr_aver007.qno!="" & deal_aver009.qstatus_out>=0 & !="*"
	IF @ls_qno <> '' AND @ls_qstatus_out >='0' AND @ls_qstatus_out <> '*'
	BEGIN
		DECLARE @ls_averh06_old NVARCHAR(2),
				@ls_averh06_new NVARCHAR(2),
				@lt_averh07_old DATETIME,
				@lt_averh07_new DATETIME,
				@ls_close_desc_old NVARCHAR(256),
				@ls_close_desc_new NVARCHAR(256),
				@li_auto_seq INT
		
		SELECT @ls_averh06_old = averh06,@lt_averh07_old = averh07,@ls_close_desc_old = close_desc ,@ls_dstatus = dstatus
		FROM aver008 WHERE averh01='Q1' AND averh02= @ls_qno
		SET @ls_dstatus_old = @ls_dstatus
		
		--多層級處理狀況	dstatus[curr_aver007.qdlevel]=deal_aver009.qstatus_out
		--1. curr_aver007.qdlevel 不在0~20間, curr_aver007.qdlevel=0
		IF @li_qdlevel> 20 OR @li_qdlevel < 0
			SET  @li_qdlevel = 0
		--dstatus[curr_aver007.qdlevel]=deal_aver009.qstatus_out
		IF LEN(@ls_dstatus) >= @li_qdlevel+1
			SET @ls_dstatus = STUFF(@ls_dstatus,@li_qdlevel+1,1,@ls_qstatus_out)
		ELSE			
			SET @ls_dstatus = @ls_dstatus + @ls_qstatus_out

		--2. 如果deal_aver009.qstatus_out = "0"-結案 且 存在dstatus[x>curr_aver007.qdlevel]!="0"
		DECLARE @li INT,
				@li_LEN INT
		SELECT @li=0,@li_LEN = LEN(@ls_dstatus)
		IF @ls_qstatus_out = '0' --dstatus[x>curr_aver007.qdlevel]!="0"
		BEGIN
			WHILE(@li < (@li_LEN))
			BEGIN
				IF @li>@li_qdlevel+1
				BEGIN
					SET @ls_dstatus = STUFF(@ls_dstatus,@li,1,'0')
					--UPDATE x_aver007=aver007("T1",q_no=aver007.qno,qdlevel=x,status!=0)
					UPDATE aver007 
					SET status = '0',
						exec_user = @as_LoginUser,
						status_date = GETDATE(),
						start_date = (CASE WHEN start_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE start_date END),
						due_date = (CASE WHEN due_date = '1900-01-01 00:00:00.000' THEN GETDATE() ELSE due_date END),
						close_desc = '系統結案 by '+@as_doc_no
					WHERE doc_type = 'T1' AND doc_no = @as_doc_no AND qdlevel = @li AND status <> '0'
				END
				SET @li = @li+1;
			END
		END
		--從dstatus最後向前判斷 /如果出現dstatus[x]!=('0'), averh06=dstatus[x]/如果出現dstatus[x]!=('0'), averh06=dstatus[x]
		SELECT @ls_averh06_new = '0' --如果各級狀態都已結案，dstatus[x]=('0'), averh06=0
		SELECT @li=LEN(@ls_dstatus), @li_LEN = LEN(@ls_dstatus)
		WHILE(@li_LEN > 0)
		BEGIN
			IF SUBSTRING(@ls_dstatus,@li_LEN,1) <> '0'
			BEGIN
				SET @ls_averh06_new = SUBSTRING(@ls_dstatus,@li_LEN,1)	
				BREAK;
			END
			SET @li_LEN = @li_LEN -1
			IF @li_LEN < 0
				BREAK;
		END		

		UPDATE aver008 
		SET averh06 = @ls_averh06_new,
			averh07 = (CASE WHEN (averh06 <> @ls_averh06_new AND averh07 = '1900-01-01 00:00:00.000') THEN GETDATE() ELSE averh07 END),
			close_desc = close_desc+@as_close_desc,
			[content] = [content]+@as_q_desc,
			dstatus = @ls_dstatus
		WHERE averh01='Q1' AND averh02= @ls_qno

		SELECT @li_auto_seq = ISNULL(MAX(auto_seq),0) 
		FROM aver012 WHERE averl01='Q1' AND averl02= @ls_qno
		
		SELECT @ls_averh06_new = averh06,@lt_averh07_new = averh07,@ls_close_desc_new = close_desc FROM aver008 WHERE averh01='Q1' AND averh02= @ls_qno
		--如果aver008有被Update, 要再Update aver012-問題異動明細
		IF 	@ls_averh06_old <> @ls_averh06_new OR  @lt_averh07_old <> @lt_averh07_new OR @ls_close_desc_old <> @ls_close_desc_new
		BEGIN
			INSERT INTO aver012(recid,averl01,averl02,auto_seq,status_in,status_out,[time],task_no,task_type,[user],remark,dstatus_in,dstatus_out)
			VALUES
			(NEWID(),'Q1',@ls_qno,@li_auto_seq+1,@ls_averh06_old,@ls_averh06_new,GETDATE(),@as_doc_no,@ls_type,@as_LoginUser,'',@ls_dstatus_old,@ls_dstatus)
		END
	END
END
GO



