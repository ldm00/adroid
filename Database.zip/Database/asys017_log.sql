if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.asys017_log'))
drop table dbo.asys017_log
go
/*==============================================================*/
/* Table: asys017                                               */
/*==============================================================*/
create table dbo.asys017_log (
   recid                uniqueidentifier     not null,
   asys017_id			uniqueidentifier	 not null,
   operate			    nvarchar(1)          not null,
   table_name           nvarchar(10)         not null,
   field_name           nvarchar(20)         not null,
   desc_id              nvarchar(20)         not null,
   desc_ct_s            nvarchar(80)         not null default '',
   desc_ct_l            nvarchar(160)        not null default '',
   desc_cs_s            nvarchar(80)         not null default '',
   desc_cs_l            nvarchar(160)        not null default '',
   desc_en_s            nvarchar(80)         not null default '',
   desc_en_l            nvarchar(160)        not null default '',
   modify_date			datetime			 not null,
   hostname			    nvarchar(100)		 not null
)
go

--修改时
IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.tu_asys017_1'))
   DROP TRIGGER dbo.tu_asys017_1
GO
CREATE TRIGGER dbo.tu_asys017_1 ON dbo.asys017
INSTEAD OF UPDATE
AS
BEGIN			
	--记录旧值
	IF EXISTS (SELECT * FROM sys.tables WHERE object_id = object_id(N'dbo.asys017_log'))
	BEGIN
		DECLARE @host_name nvarchar(100)
		SELECT @host_name=hostname FROM sys.sysprocesses WHERE spid=@@spid
		INSERT INTO asys017_log 
			SELECT newid(),recid,'M',table_name,field_name,desc_id,desc_ct_s,desc_ct_l,desc_cs_s,desc_cs_l,desc_en_s,desc_en_l,getdate(),@host_name FROM deleted
	END
	
	--修改资料到asys017
	UPDATE dbo.asys017
		SET asys017.table_name = inserted.table_name,
			asys017.field_name = inserted.field_name,
			asys017.desc_id = inserted.desc_id,
			asys017.desc_ct_s = inserted.desc_ct_s,
			asys017.desc_ct_l = inserted.desc_ct_l,
			asys017.desc_cs_s = inserted.desc_cs_s,
			asys017.desc_cs_l = inserted.desc_cs_l,
			asys017.desc_en_s = inserted.desc_en_s,
			asys017.desc_en_l = inserted.desc_en_l
	FROM inserted 
		WHERE asys017.recid = inserted.recid
END
GO

--新增时
IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.ti_asys017_1'))
   DROP TRIGGER dbo.ti_asys017_1
GO
CREATE TRIGGER dbo.ti_asys017_1 ON dbo.asys017
FOR INSERT
AS
BEGIN			
	--记录旧值
	IF EXISTS (SELECT * FROM sys.tables WHERE object_id = object_id(N'dbo.asys017_log'))
	BEGIN
		DECLARE @host_name nvarchar(100)
		SELECT @host_name=hostname FROM sys.sysprocesses WHERE spid=@@spid
		INSERT INTO asys017_log 
			SELECT newid(),recid,'A',table_name,field_name,desc_id,desc_ct_s,desc_ct_l,desc_cs_s,desc_cs_l,desc_en_s,desc_en_l,getdate(),@host_name FROM inserted
	END
END
GO


--删除时
IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.td_asys017_1'))
   DROP TRIGGER dbo.td_asys017_1
GO
CREATE TRIGGER dbo.td_asys017_1 ON dbo.asys017
FOR DELETE
AS
BEGIN			
	--记录旧值
	IF EXISTS (SELECT * FROM sys.tables WHERE object_id = object_id(N'dbo.asys017_log'))
	BEGIN
		DECLARE @host_name nvarchar(100)
		SELECT @host_name=hostname FROM sys.sysprocesses WHERE spid=@@spid
		INSERT INTO asys017_log 
			SELECT newid(),recid,'D',table_name,field_name,desc_id,desc_ct_s,desc_ct_l,desc_cs_s,desc_cs_l,desc_en_s,desc_en_l,getdate(),@host_name FROM deleted
	END
END
GO
