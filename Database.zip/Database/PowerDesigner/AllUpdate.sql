﻿--This is AutoCreate sql
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.dord013'))
drop table dbo.dord013
go

/*==============================================================*/
/* Table: dord013                                               */
/*==============================================================*/
create table dbo.dord013 (
   recid                uniqueidentifier     not null,
   dordmid              uniqueidentifier     not null,
   dordm01a             nvarchar(2)          not null default '',
   dordm01b             nvarchar(16)         not null default '',
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   dordm04              nvarchar(10)         not null default '',
   num                  float                not null default 0,
   dordm05              nvarchar(1)          not null default '',
   dordm06a             nvarchar(1)          not null default '',
   dordm06b             nvarchar(1)          not null default '',
   dordm07              numeric(19,5)        not null default 0,
   dordm08              nvarchar(6)          not null default '',
   dordm08a             numeric(19,5)        not null default 0,
   dordm08b             numeric(19,5)        not null default 0,
   dordm09              numeric(19,5)        not null default 0,
   dordm10              numeric(19,5)        not null default 0,
   dordm11              numeric(19,5)        not null default 0,
   dordm12              numeric(19,5)        not null default 0,
   dordm13              numeric(19,5)        not null default 0,
   dordm14              numeric(19,5)        not null default 0,
   dordm15              numeric(19,5)        not null default 0,
   dordm16              numeric(19,5)        not null default 0,
   dordm17              numeric(19,5)        not null default 0,
   dordm18              numeric(19,5)        not null default 0,
   dordm19              numeric(19,5)        not null default 0,
   dordm30              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dord013', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordmid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'dord013', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'dord013', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dord013', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm05'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單變更標記;轉單變更標記',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm07'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm08'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm08a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm08b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單價;首階單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm09'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x單價;轉對象1x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm10'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x單價;轉對象2x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm11'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x單價;轉對象3x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm12'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x單價;轉對象4x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm13'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x單價;轉對象5x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm14'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x單價;轉對象6x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm15'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x單價;轉對象7x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm16'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x單價;轉對象8x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm17'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x單價;轉對象9x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm18'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x單價;轉對象10x單價',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm19'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差;總價差',
   'schema', 'dbo', 'table', 'dord013', 'column', 'dordm30'
go

alter table dbo.dord013
   add constraint PK_DORD013 primary key nonclustered (dordmid)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dord013_1                                         */
/*==============================================================*/
create clustered index idx_dord013_1 on dbo.dord013 (
dordm01a ASC,
dordm01b ASC,
item_no ASC,
item_sub ASC,
dordm04 ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.dord014'))
drop table dbo.dord014
go

/*==============================================================*/
/* Table: dord014                                               */
/*==============================================================*/
create table dbo.dord014 (
   recid                uniqueidentifier     not null,
   dordn01a             nvarchar(2)          not null,
   dordn01b             nvarchar(16)         not null,
   dordn02              uniqueidentifier     not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   dordn03a             nvarchar(1)          not null default '',
   dordn03b             nvarchar(1)          not null default '',
   dordn04              nvarchar(40)         not null default '',
   dordn05a             numeric(19,5)        not null default 0,
   dordn05b             numeric(19,5)        not null default 0,
   dordn10a             numeric(19,5)        not null default 0,
   dordn10b             numeric(19,5)        not null default 0,
   dordn11a             numeric(19,5)        not null default 0,
   dordn11b             numeric(19,5)        not null default 0,
   dordn12a             numeric(19,5)        not null default 0,
   dordn12b             numeric(19,5)        not null default 0,
   dordn13a             numeric(19,5)        not null default 0,
   dordn13b             numeric(19,5)        not null default 0,
   dordn14a             numeric(19,5)        not null default 0,
   dordn14b             numeric(19,5)        not null default 0,
   dordn15a             numeric(19,5)        not null default 0,
   dordn15b             numeric(19,5)        not null default 0,
   dordn16a             numeric(19,5)        not null default 0,
   dordn16b             numeric(19,5)        not null default 0,
   dordn17a             numeric(19,5)        not null default 0,
   dordn17b             numeric(19,5)        not null default 0,
   dordn18a             numeric(19,5)        not null default 0,
   dordn18b             numeric(19,5)        not null default 0,
   dordn19a             numeric(19,5)        not null default 0,
   dordn19b             numeric(19,5)        not null default 0,
   dordn30a             numeric(19,5)        not null default 0,
   dordn30b             numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dord014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn02'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dord014', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dord014', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單變更標記;轉單變更標記',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '項目描述;項目描述',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款未稅金額;首階訂單加扣款未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款含稅金額;首階訂單加扣款含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x未稅金額;轉對象1x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x含稅金額;轉對象1x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x未稅金額;轉對象2x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x含稅金額;轉對象2x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn11b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x未稅金額;轉對象3x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn12a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x含稅金額;轉對象3x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn12b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x未稅金額;轉對象4x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x含稅金額;轉對象4x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x未稅金額;轉對象5x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x含稅金額;轉對象5x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x未稅金額;轉對象6x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x含稅金額;轉對象6x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x未稅金額;轉對象7x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x含稅金額;轉對象7x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x未稅金額;轉對象8x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn17a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x含稅金額;轉對象8x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x未稅金額;轉對象9x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn18a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x含稅金額;轉對象9x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x未稅金額;轉對象10x未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x含稅金額;轉對象10x含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差未稅金額;總價差未稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差含稅金額;總價差含稅金額',
   'schema', 'dbo', 'table', 'dord014', 'column', 'dordn30b'
go

alter table dbo.dord014
   add constraint PK_DORD014 primary key (dordn01a, dordn01b, dordn02)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.dinv014'))
drop table dbo.dinv014
go

/*==============================================================*/
/* Table: dinv014                                               */
/*==============================================================*/
create table dbo.dinv014 (
   recid                uniqueidentifier     not null,
   dinvn01a             nvarchar(2)          not null,
   dinvn01b             nvarchar(16)         not null,
   dinvn02a             nvarchar(2)          not null,
   dinvn02b             nvarchar(16)         not null,
   dinvn03              uniqueidentifier     not null,
   dinvn04              uniqueidentifier     not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   dinvn05a             nvarchar(2)          not null default '',
   dinvn05b             nvarchar(16)         not null default '',
   dinvn06              nvarchar(1)          not null default '',
   dinvn07              nvarchar(40)         not null default '',
   dinvn08              nvarchar(5)          not null default '',
   dinvn09a             numeric(19,5)        not null default 0,
   dinvn09b             numeric(19,5)        not null default 0,
   dinvn10a             numeric(19,5)        not null default 0,
   dinvn10b             numeric(19,5)        not null default 0,
   dinvn11a             numeric(19,5)        not null default 0,
   dinvn11b             numeric(19,5)        not null default 0,
   dinvn12a             numeric(19,5)        not null default 0,
   dinvn12b             numeric(19,5)        not null default 0,
   dinvn13a             numeric(19,5)        not null default 0,
   dinvn13b             numeric(19,5)        not null default 0,
   dinvn14a             numeric(19,5)        not null default 0,
   dinvn14b             numeric(19,5)        not null default 0,
   dinvn15a             numeric(19,5)        not null default 0,
   dinvn15b             numeric(19,5)        not null default 0,
   dinvn16a             numeric(19,5)        not null default 0,
   dinvn16b             numeric(19,5)        not null default 0,
   dinvn17a             numeric(19,5)        not null default 0,
   dinvn17b             numeric(19,5)        not null default 0,
   dinvn18a             numeric(19,5)        not null default 0,
   dinvn18b             numeric(19,5)        not null default 0,
   dinvn19a             numeric(19,5)        not null default 0,
   dinvn19b             numeric(19,5)        not null default 0,
   dinvn30a             numeric(19,5)        not null default 0,
   dinvn30b             numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別一;單別一',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號一;單號一',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn03'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階加扣款ID;首階加扣款ID',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單別;首階訂單單別',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單號;首階訂單單號',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn06'
go

execute sp_addextendedproperty 'MS_Description', 
   '項目描述;項目描述',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn07'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單幣別;首階訂單幣別',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn08'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款未稅金額;首階訂單加扣款未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn09a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款含稅金額;首階訂單加扣款含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn09b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x未稅金額;轉對象1x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x含稅金額;轉對象1x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x未稅金額;轉對象2x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x含稅金額;轉對象2x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn11b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x未稅金額;轉對象3x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn12a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x含稅金額;轉對象3x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn12b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x未稅金額;轉對象4x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x含稅金額;轉對象4x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x未稅金額;轉對象5x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x含稅金額;轉對象5x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x未稅金額;轉對象6x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x含稅金額;轉對象6x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x未稅金額;轉對象7x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x含稅金額;轉對象7x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x未稅金額;轉對象8x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn17a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x含稅金額;轉對象8x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x未稅金額;轉對象9x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn18a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x含稅金額;轉對象9x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x未稅金額;轉對象10x未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x含稅金額;轉對象10x含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差未稅金額;總價差未稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差含稅金額;總價差含稅金額',
   'schema', 'dbo', 'table', 'dinv014', 'column', 'dinvn30b'
go

alter table dbo.dinv014
   add constraint PK_DINV014 primary key (dinvn01a, dinvn01b, dinvn02a, dinvn02b, dinvn03)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv014_1                                         */
/*==============================================================*/
create index idx_dinv014_1 on dbo.dinv014 (
dinvn03 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv014_2                                         */
/*==============================================================*/
create index idx_dinv014_2 on dbo.dinv014 (
dinvn04 ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.dinv013'))
drop table dbo.dinv013
go

/*==============================================================*/
/* Table: dinv013                                               */
/*==============================================================*/
create table dbo.dinv013 (
   recid                uniqueidentifier     not null,
   dinvmid              uniqueidentifier     not null,
   dinvm01a             nvarchar(2)          not null default '',
   dinvm01b             nvarchar(16)         not null default '',
   dinvm02a             nvarchar(2)          not null default '',
   dinvm02b             nvarchar(16)         not null default '',
   dinvm03a             nvarchar(2)          not null default '',
   dinvm03b             nvarchar(16)         not null default '',
   num                  float                not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   dinvm04              nvarchar(10)         not null default '',
   dinvm05              numeric(19,5)        not null default 0,
   dinvm06              nvarchar(1)          not null default '',
   dinvm08              nvarchar(5)          not null default '',
   dinvm09              numeric(19,5)        not null default 0,
   dinvm10              numeric(19,5)        not null default 0,
   dinvm11              numeric(19,5)        not null default 0,
   dinvm12              numeric(19,5)        not null default 0,
   dinvm13              numeric(19,5)        not null default 0,
   dinvm14              numeric(19,5)        not null default 0,
   dinvm15              numeric(19,5)        not null default 0,
   dinvm16              numeric(19,5)        not null default 0,
   dinvm17              numeric(19,5)        not null default 0,
   dinvm18              numeric(19,5)        not null default 0,
   dinvm19              numeric(19,5)        not null default 0,
   dinvm30              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvmid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別一;單別一',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號一;單號一',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單別;首階訂單單別',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單號;首階訂單單號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm04'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量(計價單位);數量(計價單位)',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm05'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨變更標記;銷貨變更標記',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm06'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階幣別;首階幣別',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm08'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單價;首階單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm09'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x單價;轉對象1x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm10'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x單價;轉對象2x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm11'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x單價;轉對象3x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm12'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x單價;轉對象4x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm13'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x單價;轉對象5x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm14'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x單價;轉對象6x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm15'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x單價;轉對象7x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm16'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x單價;轉對象8x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm17'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x單價;轉對象9x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm18'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x單價;轉對象10x單價',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm19'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差;總價差',
   'schema', 'dbo', 'table', 'dinv013', 'column', 'dinvm30'
go

alter table dbo.dinv013
   add constraint PK_DINV013 primary key nonclustered (dinvmid)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv013_1                                         */
/*==============================================================*/
create unique clustered index idx_dinv013_1 on dbo.dinv013 (
dinvm01a ASC,
dinvm01b ASC,
dinvm02a ASC,
dinvm02b ASC,
item_no ASC,
item_sub ASC,
dinvm04 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/12 上午 10:42:34                       */
/*==============================================================*/


if exists (select 1
            from  sysindexes
           where  id    = object_id('dbo.ldoc011')
            and   name  = 'idx_ldoc011_2'
            and   indid > 0
            and   indid < 255)
   drop index dbo.ldoc011.idx_ldoc011_2
go
/*==============================================================*/
/* Index: idx_ldoc011_2                                         */
/*==============================================================*/
create unique index idx_ldoc011_2 on dbo.ldoc011 (
ldock01 ASC,
ldock02a ASC,
ldock02b ASC
)
on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/14 上午 11:12:52                       */
/*==============================================================*/
if exists (select 1
            from  sysindexes
           where  id    = object_id('dbo.ldoc011')
            and   name  = 'idx_ldoc011_1'
            and   indid > 0
            and   indid < 255)
   drop index dbo.ldoc011.idx_ldoc011_1
go
/*==============================================================*/
/* Index: idx_ldoc011_1                                         */
/*==============================================================*/
create unique clustered index idx_ldoc011_1 on dbo.ldoc011 (
ldock02a ASC,
ldock02b ASC,
ldock02c ASC,
ldock02d ASC,
ldock02e ASC,
ldock02f ASC,
item_no ASC,
item_sub ASC,
ldock03 ASC
)
on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/17 上午 10:14:05                       */
/*==============================================================*/


alter table dbo.iarp004
   alter column iarpd04 nvarchar(20) not null
go

alter table dbo.iarp005
   alter column iarpe04 nvarchar(20) not null
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/17 下午 05:33:05                       */
/*==============================================================*/
/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/17 下午 05:33:05                       */
/*==============================================================*/
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_ARIG005')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_ARIG005
go


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig003') and o.name = 'FK_ARIG003_REFERENCE_ARIG002')
alter table dbo.arig003
   drop constraint FK_ARIG003_REFERENCE_ARIG002
go


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_ARIG002')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_ARIG002
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig008') and o.name = 'FK_ARIG008_REFERENCE_ARIG002')
alter table dbo.arig008
   drop constraint FK_ARIG008_REFERENCE_ARIG002
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig009') and o.name = 'FK_ARIG009_REFERENCE_ARIG002')
alter table dbo.arig009
   drop constraint FK_ARIG009_REFERENCE_ARIG002
go

alter table dbo.arig002
   drop constraint PK_ARIG002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arig002'))
drop table dbo.tmp_arig002
go

execute sp_rename arig002, tmp_arig002
go

/*==============================================================*/
/* Table: arig002                                               */
/*==============================================================*/
create table dbo.arig002 (
   recid                uniqueidentifier     not null,
   arigb01              nvarchar(10)         not null,
   arigb02              nvarchar(30)         not null default '',
   arigb03              nvarchar(10)         not null default '',
   arigb04              uniqueidentifier     null,
   arigb05              nvarchar(40)         not null default '',
   arigb06              nvarchar(20)         not null default '',
   arigb07              nvarchar(20)         not null default '',
   arigb08              nvarchar(20)         not null default '',
   arigb09              nvarchar(1)          not null default '',
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   arigb10              nvarchar(6)          not null default '',
   arigb11              nvarchar(1)          not null default '',
   arigb12              nvarchar(1)          not null default '',
   arigb13              nvarchar(1)          not null default '',
   arigb14              datetime             not null default CONVERT(DATETIME,0),
   arigb15              int                  not null default 0,
   arigb16              datetime             not null default CONVERT(DATETIME,0),
   arigb17              nvarchar(20)         not null default '',
   arigb18              nvarchar(1)          not null default '',
   arigb19              nvarchar(20)         not null default '',
   arigb20              nvarchar(50)         not null default '',
   arigb21              int                  not null default 0,
   user_text1           nvarchar(30)         not null default '',
   user_text2           nvarchar(30)         not null default '',
   user_text3           nvarchar(30)         not null default '',
   user_text4           nvarchar(30)         not null default '',
   user_text5           nvarchar(30)         not null default '',
   user_num1            numeric(19,8)        not null default 0,
   user_num2            numeric(19,8)        not null default 0,
   user_num3            numeric(19,8)        not null default 0,
   user_num4            numeric(19,8)        not null default 0,
   user_num5            numeric(19,8)        not null default 0,
   arigb31              nvarchar(1)          not null default '',
   arigb32              nvarchar(160)        not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'RecID;RecID',
   'schema', 'dbo', 'table', 'arig002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '用戶編號;用戶編號',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb01'
go

execute sp_addextendedproperty 'MS_Description', 
   '姓名;姓名',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb02'
go

execute sp_addextendedproperty 'MS_Description', 
   '簡稱;簡稱',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb03'
go

execute sp_addextendedproperty 'MS_Description', 
   '對應連絡人檔流水號;對應連絡人檔流水號',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb04'
go

execute sp_addextendedproperty 'MS_Description', 
   'e-mail;e-mail',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb05'
go

execute sp_addextendedproperty 'MS_Description', 
   'FAX  NO;FAX  NO',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb06'
go

execute sp_addextendedproperty 'MS_Description', 
   'TEL  NO;TEL  NO',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb07'
go

execute sp_addextendedproperty 'MS_Description', 
   '行動電話;行動電話',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb08'
go

execute sp_addextendedproperty 'MS_Description', 
   '用戶身份;用戶身份',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb09'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'arig002', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'arig002', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '連絡人代碼;連絡人代碼',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb10'
go

execute sp_addextendedproperty 'MS_Description', 
   '性質 : 登錄用戶否;性質 : 登錄用戶否',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb11'
go

execute sp_addextendedproperty 'MS_Description', 
   '性質 : 業務人員否;性質 : 業務人員否',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb12'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟用標記,開始啟用否',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb13'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟用/停用的異動日期;啟用/停用的異動日期',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb14'
go

execute sp_addextendedproperty 'MS_Description', 
   '首頁通知回溯幾天內;首頁通知回溯幾天內',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb15'
go

execute sp_addextendedproperty 'MS_Description', 
   '首頁通知最早自何時開始;首頁通知最早自何時開始',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb16'
go

execute sp_addextendedproperty 'MS_Description', 
   'Login Name;Login Name',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb17'
go

execute sp_addextendedproperty 'MS_Description', 
   '身份認證方式;身份認證方式',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb18'
go

execute sp_addextendedproperty 'MS_Description', 
   '密碼;登錄密碼',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb19'
go

execute sp_addextendedproperty 'MS_Description', 
   '網域名稱;網域名稱',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb20'
go

execute sp_addextendedproperty 'MS_Description', 
   '首頁顯示行程天數;首頁顯示行程天數',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb21'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄1;文字自定欄1',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄2;文字自定欄2',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄3;文字自定欄3',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄4;文字自定欄4',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄5;文字自定欄5',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄1;數字自定欄1',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄2;數字自定欄2',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄3;數字自定欄3',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄4;數字自定欄4',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄5;數字自定欄5',
   'schema', 'dbo', 'table', 'arig002', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '日期格式;常用日期格式',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb31'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表機;常用預設印表機',
   'schema', 'dbo', 'table', 'arig002', 'column', 'arigb32'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'arig002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'arig002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'arig002', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'arig002', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '狀態;狀態(覆核、作廢否)',
   'schema', 'dbo', 'table', 'arig002', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'arig002', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'arig002', 'column', 'last_date'
go

insert into dbo.arig002 (recid, arigb01, arigb02, arigb03, arigb04, arigb05, arigb06, arigb07, arigb08, arigb09, biz_type, biz_no, arigb10, arigb11, arigb12, arigb13, arigb14, arigb15, arigb16, arigb17, arigb18, arigb19, arigb20, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, arigb31, arigb32, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date)
select recid, arigb01, arigb02, arigb03, arigb04, arigb05, arigb06, arigb07, arigb08, arigb09, biz_type, biz_no, arigb10, arigb11, arigb12, arigb13, arigb14, arigb15, arigb16, arigb17, arigb18, arigb19, arigb20, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, arigb31, arigb32, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date
from dbo.tmp_arig002
go

alter table dbo.arig002
   add constraint PK_ARIG002 primary key (arigb01)
      on "PRIMARY"
go

alter table dbo.arig003
   add constraint FK_ARIG003_REFERENCE_ARIG002 foreign key (arigc01)
      references dbo.arig002 (arigb01)
         on delete cascade
go

alter table dbo.arig004
   add constraint FK_ARIG004_REFERENCE_ARIG002 foreign key (arigd01)
      references dbo.arig002 (arigb01)
         on delete cascade
go

alter table dbo.arig008
   add constraint FK_ARIG008_REFERENCE_ARIG002 foreign key (arigh01)
      references dbo.arig002 (arigb01)
         on delete cascade
go

alter table dbo.arig009
   add constraint FK_ARIG009_REFERENCE_ARIG002 foreign key (arigi01)
      references dbo.arig002 (arigb01)
         on delete cascade
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arig002'))
drop table dbo.tmp_arig002
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/11/26 下午 03:11:05                       */
/*==============================================================*/
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_ARIG001_2')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_ARIG001_2
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_ARIG001_1')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_ARIG001_1
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_BCOM006_1')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_BCOM006_1
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_BCOM006_2')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_BCOM006_2
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bacr003'))
drop table dbo.bacr003
go

/*==============================================================*/
/* Table: bacr003                                               */
/*==============================================================*/
create table dbo.bacr003 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   mst_recid            uniqueidentifier     not null,
   mst_func             nvarchar(2)          not null default '',
   mst_no               nvarchar(16)         not null default '',
   mst_pkid             int                  not null default 0,
   file_type            nvarchar(1)          not null default '',
   num                  int                  not null default 0,
   file_name            nvarchar(256)        not null default '',
   file_ext             nvarchar(20)         not null default '',
   file_size            float                not null default 0,
   file_summary         nvarchar(256)        not null default '',
   save_mode            nvarchar(1)          not null default '',
   file_path            nvarchar(400)        not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '多媒體資料ID;多媒體資料ID',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '多媒體對應主檔資料的[recid];多媒體對應主檔資料的[recid]',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'mst_recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔單別;主檔單別',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'mst_func'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔資料單號;主檔資料單號',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'mst_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔資料ID;主檔資料ID',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'mst_pkid'
go

execute sp_addextendedproperty 'MS_Description', 
   '多媒體資料類型;多媒體資料類型',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '附件檔案名稱;附件檔案名稱',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_name'
go

execute sp_addextendedproperty 'MS_Description', 
   '附件檔案擴展名;附件檔案擴展名',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_ext'
go

execute sp_addextendedproperty 'MS_Description', 
   '附件檔案大小;附件檔案大小',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_size'
go

execute sp_addextendedproperty 'MS_Description', 
   '附件檔案摘要說明;附件檔案摘要說明',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_summary'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料存儲方式;資料存儲方式',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'save_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '檔案本地全路徑名;檔案本地全路徑名',
   'schema', 'dbo', 'table', 'bacr003', 'column', 'file_path'
go

alter table dbo.bacr003
   add constraint PK_BACR003 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_bacr003_1                                         */
/*==============================================================*/
create unique index idx_bacr003_1 on dbo.bacr003 (
mst_recid ASC,
num ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_bacr003_2                                         */
/*==============================================================*/
create unique index idx_bacr003_2 on dbo.bacr003 (
mst_func ASC,
mst_no ASC,
mst_pkid ASC,
pk_id ASC
)
on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bacr004'))
drop table dbo.bacr004
go

/*==============================================================*/
/* Table: bacr004                                               */
/*==============================================================*/
create table dbo.bacr004 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   create_date          datetime             not null default CONVERT(DATETIME,0),
   file_data            varbinary(max)       not null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bacr004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '附件資料ID;附件資料ID',
   'schema', 'dbo', 'table', 'bacr004', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'bacr004', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '檔案數據;檔案數據',
   'schema', 'dbo', 'table', 'bacr004', 'column', 'file_data'
go

alter table dbo.bacr004
   add constraint PK_BACR004 primary key (pk_id)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bacr005'))
drop table dbo.bacr005
go

/*==============================================================*/
/* Table: bacr005                                               */
/*==============================================================*/
create table dbo.bacr005 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   bacre01              nvarchar(1)          not null,
   bacre02              nvarchar(30)         not null,
   item_no              nvarchar(20)         not null,
   item_sub             nvarchar(10)         not null,
   auto_seq             float                not null,
   bacre03              datetime             not null default CONVERT(DATETIME,0),
   bacre04              nvarchar(10)         not null default '',
   bacre05              int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '分類;分類',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'bacre01'
go

execute sp_addextendedproperty 'MS_Description', 
   '分類編號;分類編號',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'bacre02'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '參考日期;參考日期',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'bacre03'
go

execute sp_addextendedproperty 'MS_Description', 
   '屬性 ;屬性 ',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'bacre04'
go

execute sp_addextendedproperty 'MS_Description', 
   '多媒體資料ID;多媒體資料ID',
   'schema', 'dbo', 'table', 'bacr005', 'column', 'bacre05'
go

alter table dbo.bacr005
   add constraint PK_BACR005 primary key (doc_comp, bacre01, bacre02, item_no, item_sub, auto_seq)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/12/1 上午 10:37:57                        */
/*==============================================================*/


alter table dbo.dinv006
   drop constraint PK_DINV006
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv006'))
drop table dbo.tmp_dinv006
go

execute sp_rename dinv006, tmp_dinv006
go

/*==============================================================*/
/* Table: dinv006                                               */
/*==============================================================*/
create table dbo.dinv006 (
   recid                uniqueidentifier     not null,
   dinvf01a             nvarchar(2)          not null,
   dinvf01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   dinvf02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   dinvf03a             nvarchar(2)          not null default '',
   dinvf03b             nvarchar(16)         not null default '',
   dinvf03c             int                  not null default 0,
   dinvf03d             nvarchar(20)         not null default '',
   dinvf04a             nvarchar(2)          not null default '',
   dinvf04b             nvarchar(16)         not null default '',
   dinvf04c             int                  not null default 0,
   dinvf04d             nvarchar(20)         not null default '',
   dinvf05              nvarchar(1)          not null default '',
   dinvf06              nvarchar(10)         not null default '',
   dinvf07              nvarchar(80)         not null default '',
   dinvf08              nvarchar(1)          not null default '',
   dinvf09              nvarchar(10)         not null default '',
   dinvf10              nvarchar(80)         not null default '',
   dinvf11              datetime             not null default CONVERT(DATETIME,0),
   dinvf12              nvarchar(10)         not null default '',
   dinvf13              nvarchar(10)         not null default '',
   dinvf14              nvarchar(20)         not null default '',
   dinvf15              nvarchar(20)         not null default '',
   dinvf16              nvarchar(20)         not null default '',
   dinvf17              nvarchar(6)          not null default '',
   dinvf18              nvarchar(6)          not null default '',
   dinvf20              numeric(19,5)        not null default 0,
   dinvf21              numeric(19,5)        not null default 0,
   dinvf22              numeric(19,5)        not null default 0,
   dinvf23              numeric(19,5)        not null default 0,
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf03c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf03d'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf04b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf04c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf04d'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象別;接櫃人對象別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf05'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象編號;接櫃人對象編號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf06'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人描述;接櫃人描述',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf07'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象別;放櫃處對象別',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf08'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象編號;放櫃處對象編號',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf09'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處描述;放櫃處描述',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf10'
go

execute sp_addextendedproperty 'MS_Description', 
   '離廠日;離廠日',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf11'
go

execute sp_addextendedproperty 'MS_Description', 
   '驗貨人;驗貨人',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf12'
go

execute sp_addextendedproperty 'MS_Description', 
   '船務;船務',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf13'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf14'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf15'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf16'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf17'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf18'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf20'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf21'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total G.W.;Total G.W.',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf22'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total Measm''t;Total Measm''t',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'dinvf23'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv006', 'column', 'modify_date'
go

insert into dbo.dinv006 (recid, dinvf01a, dinvf01b, doc_comp, dinvf02, doc_date, biz_type, biz_no, doc_staff, staff_group, dinvf03a, dinvf03b, dinvf04a, dinvf04b, dinvf05, dinvf06, dinvf07, dinvf08, dinvf09, dinvf10, dinvf11, dinvf12, dinvf13, dinvf14, dinvf15, dinvf16, dinvf17, dinvf18, dinvf20, dinvf21, dinvf22, dinvf23, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, dinvf01a, dinvf01b, doc_comp, dinvf02, doc_date, biz_type, biz_no, doc_staff, staff_group, dinvf03a, dinvf03b, dinvf04a, dinvf04b, dinvf05, dinvf06, dinvf07, dinvf08, dinvf09, dinvf10, dinvf11, dinvf12, dinvf13, dinvf14, dinvf15, dinvf16, dinvf17, dinvf18, dinvf20, dinvf21, dinvf22, dinvf23, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_dinv006
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv006'))
drop table dbo.tmp_dinv006
go

alter table dbo.dinv006
   add constraint PK_DINV006 primary key (dinvf01a, dinvf01b)
      on "PRIMARY"
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nfav001'))
drop table dbo.nfav001
go

/*==============================================================*/
/* Table: nfav001                                               */
/*==============================================================*/
create table dbo.nfav001 (
   recid                uniqueidentifier     not null,
   user_no              nvarchar(10)         not null,
   folder_id            int                  not null,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   root_id              int                  not null default 0,
   parent_id            int                  not null default 0,
   view_order           float                not null default 0,
   title                nvarchar(100)        not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '用戶編號;用戶編號',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾節點ID;資料夾節點ID',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'folder_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾根節點ID;資料夾根節點ID',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'root_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾父節點ID;資料夾父節點ID',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'parent_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '顯示排序;顯示排序',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'view_order'
go

execute sp_addextendedproperty 'MS_Description', 
   '名稱;名稱',
   'schema', 'dbo', 'table', 'nfav001', 'column', 'title'
go

alter table dbo.nfav001
   add constraint PK_NFAV001 primary key (user_no, folder_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nfav001_1                                         */
/*==============================================================*/
create unique index idx_nfav001_1 on dbo.nfav001 (
user_no ASC,
root_id ASC,
parent_id ASC,
view_order ASC,
folder_id ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nfav002'))
drop table dbo.nfav002
go

/*==============================================================*/
/* Table: nfav002                                               */
/*==============================================================*/
create table dbo.nfav002 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   user_no              nvarchar(10)         not null default '',
   folder_id            int                  not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   title                nvarchar(256)        not null default '',
   hp_keep              int                  not null default 0,
   hp_date              datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '我的資料ID;我的資料ID',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '用戶編號;用戶編號',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾節點ID;資料夾節點ID',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'folder_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否首頁保留;是否首頁保留',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'hp_keep'
go

execute sp_addextendedproperty 'MS_Description', 
   '首頁保留設置日期;首頁保留設置日期',
   'schema', 'dbo', 'table', 'nfav002', 'column', 'hp_date'
go

alter table dbo.nfav002
   add constraint PK_NFAV002 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nfav002_1                                         */
/*==============================================================*/
create unique index idx_nfav002_1 on dbo.nfav002 (
user_no ASC,
folder_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nfav002_2                                         */
/*==============================================================*/
create unique index idx_nfav002_2 on dbo.nfav002 (
user_no ASC,
hp_keep ASC,
hp_date ASC,
pk_id ASC
)
on "PRIMARY"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom009') and o.name = 'FK_BCOM009_REFERENCE_BCOM001')
alter table dbo.bcom009
   drop constraint FK_BCOM009_REFERENCE_BCOM001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bcom009'))
drop table dbo.bcom009
go

/*==============================================================*/
/* Table: bcom009                                               */
/*==============================================================*/
create table dbo.bcom009 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   bcomi01              nvarchar(10)         not null,
   bcomi02              nvarchar(40)         not null default '',
   bcomi03              int                  not null default 0,
   bcomi03a             nvarchar(1)          not null default '',
   bcomi04              int                  not null default 0,
   bcomi04a             nvarchar(1)          not null default '',
   bcomi05              int                  not null default 0,
   bcomi06              int                  not null default 0,
   bcomi07              nvarchar(1)          not null default '',
   num                  float                not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司;公司',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '檔名;檔名',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi01'
go

execute sp_addextendedproperty 'MS_Description', 
   '說明;說明',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi02'
go

execute sp_addextendedproperty 'MS_Description', 
   '高度;高度',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi03'
go

execute sp_addextendedproperty 'MS_Description', 
   '高度單位;高度單位',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '寬度;寬度',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi04'
go

execute sp_addextendedproperty 'MS_Description', 
   '寬度單位;寬度單位',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料ID;資料ID',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi05'
go

execute sp_addextendedproperty 'MS_Description', 
   '語言別;語言別',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi06'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'bcomi07'
go

execute sp_addextendedproperty 'MS_Description', 
   '畫面顯示順序;畫面顯示順序',
   'schema', 'dbo', 'table', 'bcom009', 'column', 'num'
go

alter table dbo.bcom009
   add constraint PK_BCOM009 primary key (doc_comp, bcomi01)
      on "PRIMARY"
go

alter table dbo.bcom009
   add constraint FK_BCOM009_REFERENCE_BCOM001 foreign key (doc_comp)
      references dbo.bcom001 (bcoma01)
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/12/15 AM 10:14:43                       */
/*==============================================================*/


alter table dbo.arpt003
   drop constraint PK_ARPT003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

execute sp_rename arpt003, tmp_arpt003
go
declare @sql varchar(200)
set @sql = 'alter table bcom010  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('bcom010') and c.name = 'bcomj24'  and c.cdefault = o.id)
exec(@sql)
GO

alter table dbo.bcom010
   drop column bcomj24
go

/*==============================================================*/
/* Table: arpt003                                               */
/*==============================================================*/
create table dbo.arpt003 (
   recid                uniqueidentifier     not null,
   arptc01              nvarchar(10)         not null,
   arptc02              nvarchar(10)         not null,
   arptc03              nvarchar(1)          not null,
   arptc04              nvarchar(10)         not null,
   arptc05              nvarchar(40)         not null default '',
   arptc06              image                not null,
   arptc07              nvarchar(20)         not null default '',
   arptc08              nvarchar(2)          not null default '',
   arptc09              nvarchar(1)          not null default '',
   arptc10              nvarchar(256)        not null default '',
   arptc11              nvarchar(1)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '多語言別;多語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '版本代號;版本代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式名稱;格式名稱',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc05'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式設定檔;格式設定檔',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔用戶;建檔用戶',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '應用狀態;應用狀態',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc08'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入標誌;載入標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '數據來源方案;數據來源方案',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統標誌;系統標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc11'
go

--WARNING: The following insert order will not restore columns: arptc02
insert into dbo.arpt003 (recid, arptc01, arptc02, arptc03, arptc04, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10)
select recid, arptc01, left(arptc02,10), arptc03, arptc04, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10
from dbo.tmp_arpt003
go

alter table dbo.arpt003
   add constraint PK_ARPT003 primary key (arptc01, arptc02, arptc03, arptc04)
      on "PRIMARY"
go

execute sp_dropextendedproperty 'MS_Description','schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj02'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj02'
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/12/18 AM 10:48:19                       */
/*==============================================================*/

declare @sql varchar(200)
set @sql = 'alter table arpt001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('arpt001') and c.name = 'arpta09'  and c.cdefault = o.id)
exec(@sql)
GO
alter table dbo.arpt001
   drop column arpta09
go

alter table dbo.arpt002
   drop constraint PK_ARPT002
go

alter table dbo.arpt003
   drop constraint PK_ARPT003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

execute sp_rename arpt003, tmp_arpt003
go

alter table dbo.arpt002
   add constraint PK_ARPT002 primary key (arptb01, arptb02, arptb04)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: arpt003                                               */
/*==============================================================*/
create table dbo.arpt003 (
   recid                uniqueidentifier     not null,
   arptc01              nvarchar(10)         not null,
   arptc02              nvarchar(10)         not null,
   arptc03              nvarchar(1)          not null default '',
   arptc04              nvarchar(10)         not null,
   num                   float                not null default 0,
   arptc05              nvarchar(40)         not null default '',
   arptc06              image                not null,
   arptc07              nvarchar(20)         not null default '',
   arptc08              nvarchar(2)          not null default '',
   arptc09              nvarchar(1)          not null default '',
   arptc10              nvarchar(256)        not null default '',
   arptc11              nvarchar(1)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '多語言別;多語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '版本代號;版本代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式名稱;格式名稱',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc05'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式設定檔;格式設定檔',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔用戶;建檔用戶',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '應用狀態;應用狀態',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc08'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入標誌;載入標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '數據來源方案;數據來源方案',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統標誌;系統標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc11'
go

insert into dbo.arpt003 (recid, arptc01, arptc02, arptc03, arptc04, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11)
select recid, arptc01, arptc02, arptc03, arptc04, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11
from dbo.tmp_arpt003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

alter table dbo.arpt003
   add constraint PK_ARPT003 primary key (arptc01, arptc02, arptc04)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: arpt004                                               */
/*==============================================================*/
create table dbo.arpt004 (
   recid                uniqueidentifier     not null,
   arptd01              nvarchar(10)         not null,
   arptd02              int                  not null,
   auto_seq             int                  not null,
   arptd03              nvarchar(1)          not null default '',
   arptd04              nvarchar(10)         not null default '',
   arptd05              int                  not null default 0,
   arptd06              datetime             not null default CONVERT(DATETIME,0),
   arptd07              datetime             not null default CONVERT(DATETIME,0),
   arptd08              uniqueidentifier     null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd01'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表序號;印表序號',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd02'
go

execute sp_addextendedproperty 'MS_Description', 
   '通知流水號;通知流水號',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd03'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd04'
go

execute sp_addextendedproperty 'MS_Description', 
   '展開來源流水號;展開來源流水號',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd05'
go

execute sp_addextendedproperty 'MS_Description', 
   '通知設定時間;通知設定時間',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd06'
go

execute sp_addextendedproperty 'MS_Description', 
   '通知到達時間;通知到達時間',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd07'
go

execute sp_addextendedproperty 'MS_Description', 
   '通知ID;通知ID',
   'schema', 'dbo', 'table', 'arpt004', 'column', 'arptd08'
go

alter table dbo.arpt004
   add constraint PK_ARPT004 primary key (arptd01, arptd02, auto_seq)
      on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/12/18 PM 04:59:12                       */
/*==============================================================*/
alter table dbo.dinv001
   drop constraint PK_DINV001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv001'))
drop table dbo.tmp_dinv001
go

execute sp_rename dinv001, tmp_dinv001
go

/*==============================================================*/
/* Table: dinv001                                               */
/*==============================================================*/
create table dbo.dinv001 (
   recid                uniqueidentifier     not null,
   dinva01a             nvarchar(2)          not null,
   dinva01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   dinva02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   dinva03              nvarchar(60)         not null default '',
   dinva04              nvarchar(20)         not null default '',
   dinva05a             nvarchar(20)         not null default '',
   dinva05b             nvarchar(20)         not null default '',
   dinva05c             nvarchar(20)         not null default '',
   dinva06a             nvarchar(80)         not null default '',
   dinva06b             nvarchar(200)        not null default '',
   dinva07              nvarchar(1)          not null default '',
   dinva07a             nvarchar(1)          not null default '',
   dinva07b             nvarchar(10)         not null default '',
   dinva07c             nvarchar(5)          not null default '',
   dinva07d             numeric(9,5)         not null default 0,
   dinva07e             numeric(9,5)         not null default 0,
   dinva08              numeric(9,5)         not null default 0,
   dinva09              nvarchar(1)          not null default '',
   dinva10a             datetime             not null default CONVERT(DATETIME,0),
   dinva10b             datetime             not null default CONVERT(DATETIME,0),
   dinva10c             datetime             not null default CONVERT(DATETIME,0),
   dinva10d             datetime             not null default CONVERT(DATETIME,0),
   dinva11              nvarchar(20)         not null default '',
   dinva12              nvarchar(20)         not null default '',
   dinva13a             nvarchar(1)          not null default '',
   dinva13b             nvarchar(10)         not null default '',
   dinva14a             nvarchar(1)          not null default '',
   dinva14b             nvarchar(10)         not null default '',
   dinva15a             nvarchar(1)          not null default '',
   dinva15b             nvarchar(10)         not null default '',
   dinva15c             nvarchar(1)          null default '',
   dinva15d             nvarchar(10)         null default '',
   dinva15e             nvarchar(6)          null default '',
   dinva15f             nvarchar(80)         null default '',
   dinva16a             nvarchar(1)          not null default '',
   dinva16b             nvarchar(10)         not null default '',
   dinva17a             nvarchar(1)          not null default '',
   dinva17b             nvarchar(10)         not null default '',
   dinva18a             nvarchar(1)          not null default '',
   dinva18b             nvarchar(10)         not null default '',
   dinva19              nvarchar(10)         not null default '',
   dinva19a             nvarchar(1)          not null default '',
   dinva19b             nvarchar(2)          not null default '',
   dinva20              nvarchar(20)         not null default '',
   dinva21a             nvarchar(1)          not null default '',
   dinva21b             nvarchar(10)         not null default '',
   dinva21c             nvarchar(80)         not null default '',
   dinva22a             nvarchar(1)          not null default '',
   dinva22b             nvarchar(10)         not null default '',
   dinva22c             nvarchar(80)         not null default '',
   dinva23              datetime             not null default CONVERT(DATETIME,0),
   dinva26              nvarchar(6)          not null default '',
   dinva26a             nvarchar(30)         not null default '',
   dinva26b             nvarchar(20)         not null default '',
   dinva26c             nvarchar(20)         not null default '',
   dinva26d             nvarchar(20)         not null default '',
   dinva26e             nvarchar(40)         not null default '',
   dinva27              nvarchar(2)          not null default '',
   dinva24              nvarchar(10)         not null default '',
   dinva25              nvarchar(10)         not null default '',
   dinva28              nvarchar(1)          not null default '',
   dinva29a             nvarchar(40)         not null default '',
   dinva29b             nvarchar(40)         not null default '',
   dinva29c             nvarchar(40)         not null default '',
   dinva30a             nvarchar(2)          not null default '',
   dinva30b             nvarchar(16)         not null default '',
   dinva31a             nvarchar(2)          not null default '',
   dinva31b             nvarchar(16)         not null default '',
   dinva31c             int                  not null default 0,
   dinva31d             nvarchar(20)         not null default '',
   dinva31e             nvarchar(2)          not null default '',
   dinva32a             nvarchar(2)          not null default '',
   dinva32b             nvarchar(16)         not null default '',
   dinva32c             int                  not null default 0,
   dinva32d             nvarchar(20)         not null default '',
   dinva33              nvarchar(6)          not null default '',
   dinva34              nvarchar(6)          not null default '',
   doc_dig1             int                  not null default 0,
   doc_dig2             int                  not null default 0,
   doc_dig3             int                  not null default 0,
   comp_dig1            int                  not null default 0,
   comp_dig2            int                  not null default 0,
   comp_dig3            int                  not null default 0,
   dinva35a             nvarchar(1)          not null default '',
   dinva35b             numeric(9,5)         not null default 0,
   dinva35c             nvarchar(1)          not null default '',
   dinva36a             nvarchar(20)         not null default '',
   dinva36b             nvarchar(20)         not null default '',
   dinva37a             nvarchar(6)          not null default '',
   dinva37b             nvarchar(80)         not null default '',
   dinva37c             int                  not null default 0,
   dinva37d             numeric(9,5)         not null default 0,
   dinva37e             int                  not null default 0,
   dinva37f             numeric(9,5)         not null default 0,
   dinva38a             nvarchar(1)          not null default '',
   dinva38b             nvarchar(1)          not null default '',
   dinva38c             nvarchar(1)          not null default '',
   dinva38d             nvarchar(1)          not null default '',
   dinva38e             nvarchar(1)          not null default '',
   dinva38f             nvarchar(1)          not null default '',
   dinva38g             nvarchar(1)          not null default '',
   dinva38h             nvarchar(1)          not null default '',
   dinva40              numeric(19,5)        not null default 0,
   dinva41              numeric(19,5)        not null default 0,
   dinva42              numeric(19,5)        not null default 0,
   dinva43              numeric(19,5)        not null default 0,
   dinva44              numeric(19,5)        not null default 0,
   dinva45              numeric(19,5)        not null default 0,
   dinva46              numeric(19,5)        not null default 0,
   dinva47              numeric(19,5)        not null default 0,
   dinva50              numeric(19,5)        not null default 0,
   dinva51              numeric(19,5)        not null default 0,
   dinva52              numeric(19,5)        not null default 0,
   dinva53              numeric(19,5)        not null default 0,
   dinva54              numeric(19,5)        not null default 0,
   dinva55              numeric(19,5)        not null default 0,
   dinva56              numeric(19,5)        not null default 0,
   dinva57              numeric(19,5)        not null default 0,
   dinva58              numeric(19,5)        not null default 0,
   dinva59              numeric(19,5)        not null default 0,
   user_text1           nvarchar(20)         not null default '',
   user_text2           nvarchar(20)         not null default '',
   user_text3           nvarchar(20)         not null default '',
   user_text4           nvarchar(20)         not null default '',
   user_text5           nvarchar(20)         not null default '',
   user_num1            numeric(19,5)        not null default 0,
   user_num2            numeric(19,5)        not null default 0,
   user_num3            numeric(19,5)        not null default 0,
   user_num4            numeric(19,5)        not null default 0,
   user_num5            numeric(19,5)        not null default 0,
   dinva60b             int                  not null default 0,
   dinva60c             int                  not null default 0,
   dinva61b             int                  not null default 0,
   dinva61c             int                  not null default 0,
   dinva62b             int                  not null default 0,
   dinva62c             int                  not null default 0,
   dinva63b             int                  not null default 0,
   dinva63c             int                  not null default 0,
   dinva64b             int                  not null default 0,
   dinva64c             int                  not null default 0,
   dinva65b             int                  not null default 0,
   dinva65c             int                  not null default 0,
   dinva66b             int                  not null default 0,
   dinva66c             int                  not null default 0,
   dinva67a             nvarchar(20)         not null default '',
   dinva67b             int                  not null default 0,
   dinva67c             int                  not null default 0,
   dinva68a             nvarchar(20)         not null default '',
   dinva68b             int                  not null default 0,
   dinva68c             int                  not null default 0,
   dinva69a             nvarchar(20)         not null default '',
   dinva69b             int                  not null default 0,
   dinva69c             int                  not null default 0,
   dinva70a             nvarchar(20)         not null default '',
   dinva70b             int                  not null default 0,
   dinva70c             int                  not null default 0,
   dinva71a             nvarchar(20)         not null default '',
   dinva71b             int                  not null default 0,
   dinva71c             int                  not null default 0,
   dinva73a             nvarchar(1)          not null default '',
   dinva73b             nvarchar(10)         not null default '',
   dinva74              nvarchar(1)          not null default '',
   dinva75              datetime             not null default CONVERT(DATETIME,0),
   dinva76a             numeric(19,5)        not null default 0,
   dinva76b             numeric(19,5)        not null default 0,
   dinva77a             numeric(9,5)         not null default 0,
   dinva77b             numeric(9,5)         not null default 0,
   dinva78a             numeric(9,5)         not null default 0,
   dinva78b             numeric(9,5)         not null default 0,
   dinva79              nvarchar(1)          not null default '',
   dinva81              int                  not null default 0,
   dinva82a             nvarchar(1)          not null default '',
   dinva82b             datetime             not null default CONVERT(DATETIME,0),
   dinva83a             nvarchar(1)          not null default '',
   dinva83b             datetime             not null default CONVERT(DATETIME,0),
   dinva84a             nvarchar(1)          not null default '',
   dinva84b             datetime             not null default CONVERT(DATETIME,0),
   dinva85a             nvarchar(1)          not null default '',
   dinva85b             datetime             not null default CONVERT(DATETIME,0),
   dinva86              nvarchar(4)          not null default '',
   dinva87              int                  not null default 0,
   dinva88              datetime             not null default CONVERT(DATETIME,0),
   dinva89              datetime             not null default CONVERT(DATETIME,0),
   dinva90a             datetime             not null default CONVERT(DATETIME,0),
   dinva90b             datetime             not null default CONVERT(DATETIME,0),
   dinva91a             nvarchar(1)          not null default '',
   dinva91b             nvarchar(1)          not null default '',
   dinva91c             nvarchar(10)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status1          nvarchar(1)          not null default '',
   last_user1           nvarchar(10)         not null default '',
   last_date1           datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   'vessel;vessel',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva03'
go

execute sp_addextendedproperty 'MS_Description', 
   '專案代號;專案代號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva04'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象名稱(用於印表);對象名稱(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象地址(用於印表);對象地址(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金交易;佣金交易',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單對象別;轉單對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單對象編號;轉單對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單幣別;轉單幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07c'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單公司匯率;轉單公司匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07d'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單系統匯率;轉單系統匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07e'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValue%;UnderValue%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva08'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱數計算依;箱數計算依',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva09'
go

execute sp_addextendedproperty 'MS_Description', 
   'On Board Date;On Board Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Close Date;Close Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計出貨日;預計出貨日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10c'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計到達日;預計到達日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10d'
go

execute sp_addextendedproperty 'MS_Description', 
   '原產地;原產地',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva11'
go

execute sp_addextendedproperty 'MS_Description', 
   'S/O No.;S/O No.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva12'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象別;報關行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象編號;報關行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象別;收款對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象編號;收款對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象別;交貨對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象編號;交貨對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象別;交貨地點對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15c'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象編號;交貨地點對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15d'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點序號;交貨地點序號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15e'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點描述;交貨地點描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15f'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象別;Agent對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象編號;Agent對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象別;Consignee對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象編號;Consignee對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17b'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象別;A/Notify對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18a'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象編號;A/Notify對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU出貨轉單方案;OBU出貨轉單方案',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉產生標記;OBU拋轉產生標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19a'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉狀態標記;OBU拋轉狀態標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排櫃單號;排櫃單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva20'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象別;接櫃人對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21a'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象編號;接櫃人對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21b'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人描述;接櫃人描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21c'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象別;放櫃處對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象編號;放櫃處對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22b'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處描述;放櫃處描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22c'
go

execute sp_addextendedproperty 'MS_Description', 
   '離廠日;離廠日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva23'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡人代碼;聯絡人代碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一;聯絡電話一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二;聯絡電話二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真;聯絡傳真',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email;聯絡email',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26e'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭編號;嘜頭編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva27'
go

execute sp_addextendedproperty 'MS_Description', 
   '驗貨人;驗貨人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva24'
go

execute sp_addextendedproperty 'MS_Description', 
   '船務;船務',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva25'
go

execute sp_addextendedproperty 'MS_Description', 
   '本單Packing和Invoice聯動;本單Packing和Invoice聯動',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva28'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 1;Invoice of …… 1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 2;Invoice of …… 2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 3;Invoice of …… 3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29c'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單別;合約單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單號;合約單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31d'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單類別;來源單類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31e'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva33'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva34'
go

execute sp_addextendedproperty 'MS_Description', 
   '單價小數位;單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '小計小數位;小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '總計小數位;總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣單價小數位;換算公司幣單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣小計小數位;換算公司幣小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣總計小數位;換算公司幣總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動取位設定;啟動取位設定',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35a'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位設定基數;取位設定基數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35b'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位不整除;取位不整除',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35c'
go

execute sp_addextendedproperty 'MS_Description', 
   '經海關証明文件編號;經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36a'
go

execute sp_addextendedproperty 'MS_Description', 
   '非經海關証明文件編號;非經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment code;payment code',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37a'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment desc.;payment desc.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37b'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)幾天內;現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37c'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)扣幾%;現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37d'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)幾天內;現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37e'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)扣幾%;現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況1-產生Packing;更檔狀況1-產生Packing',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38a'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況2-產生Invoice;更檔狀況2-產生Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38b'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況3-產生產品來源;更檔狀況3-產生產品來源',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38c'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況4-確認訂單出貨;更檔狀況4-確認訂單出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38d'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況5-確認採購出貨;更檔狀況5-確認採購出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38e'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況6-產生應收帳款;更檔狀況6-產生應收帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況7-產生應付帳款;更檔狀況7-產生應付帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38g'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況8-應收L/C押匯;更檔狀況8-應收L/C押匯',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38h'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva40'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva41'
go

execute sp_addextendedproperty 'MS_Description', 
   '總箱數;總箱數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva42'
go

execute sp_addextendedproperty 'MS_Description', 
   '總棧板數;總棧板數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva43'
go

execute sp_addextendedproperty 'MS_Description', 
   '總淨重;總淨重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva44'
go

execute sp_addextendedproperty 'MS_Description', 
   '總毛重;總毛重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva45'
go

execute sp_addextendedproperty 'MS_Description', 
   '總體積;總體積',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva46'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量(含分開包裝);總數量(含分開包裝)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva47'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice未稅總額;Invoice未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva50'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice含稅總額;Invoice含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva51'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice UnderValude 總額;Invoice UnderValude 總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva52'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款未稅總額;加扣款未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva53'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款含稅總額;加扣款含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva54'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金總額;稅金總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva55'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款總額;代收款總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva56'
go

execute sp_addextendedproperty 'MS_Description', 
   '商品採購成本未稅總額(公司幣別);商品採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva57'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配採購成本未稅總額(公司幣別);贈配採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva58'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估費用總額(公司幣別);預估費用總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva59'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值一;自定義文字欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值二;自定義文字欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值三;自定義文字欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值四;自定義文字欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值五;自定義文字欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值一;自定義數值欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值二;自定義數值欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值三;自定義數值欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值四;自定義數值欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值五;自定義數值欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Commerical Invoice;原稿份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Commerical Invoice;拷貝份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Customs Invoice;原稿份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Customs Invoice;拷貝份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Bill of Lading;原稿份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Bill of Lading;拷貝份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Packing List;原稿份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Packing List;拷貝份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Insur. Certificate;原稿份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Insur. Certificate;拷貝份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Certificate Origin;原稿份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Certificate Origin;拷貝份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Consular Invoice;原稿份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Consular Invoice;拷貝份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other1 Desc;Other1 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other1;原稿份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other1;拷貝份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other2 Desc;Other2 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other2;原稿份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other2;拷貝份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other3 Desc;Other3 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other3;原稿份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other3;拷貝份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other4 Desc;Other4 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other4;原稿份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other4;拷貝份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other5 Desc;Other5 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other5;原稿份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other5;拷貝份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71c'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象別;押匯銀行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象編號;押匯銀行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出口L/C帳款金額選擇;出口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva74'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯日期;押匯日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva75'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(單據幣別);押匯總金額(單據幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(公司幣別);押匯總金額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76b'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-公司幣別;押匯匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-系統幣別;押匯匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77b'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-公司幣別;結關匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78a'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-系統幣別;結關匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78b'
go

execute sp_addextendedproperty 'MS_Description', 
   '進口L/C帳款金額選擇;進口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva79'
go

execute sp_addextendedproperty 'MS_Description', 
   'Revised 修改次數;Revised 修改次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva81'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日選中;實際出口日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82a'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日;實際出口日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日選中;交件安裝日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日;交件安裝日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1選中;追蹤項目1選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1;追蹤項目1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2選中;追蹤項目2選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2;追蹤項目2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨倉庫;出貨倉庫',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva86'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據列印次數;單據列印次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva87'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據到期日;票據到期日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva88'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計收款日;預計收款日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva89'
go

execute sp_addextendedproperty 'MS_Description', 
   '立帳日期;立帳日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90a'
go

execute sp_addextendedproperty 'MS_Description', 
   '帳款月份;帳款月份',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90b'
go

execute sp_addextendedproperty 'MS_Description', 
   '隨貨開立發票否？;隨貨開立發票否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91a'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票全部開立否？;發票全部開立否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91b'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票號碼;發票號碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91c'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯覆核/作廢;押匯覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態人;押匯最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態日;押匯最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date1'
go

insert into dbo.dinv001 (recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva07a, dinva07b, dinva07c, dinva07d, dinva07e, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1)
select recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva07a, dinva07b, dinva07c, dinva07d, dinva07e, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1
from dbo.tmp_dinv001
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2008/12/19 PM 03:50:51                       */
/*==============================================================*/


execute sp_rename "arpt003.序號", num
go
alter table dbo.arpt003 alter column arptc06 varbinary(max) null
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bbus011'))
drop table dbo.bbus011
go

/*==============================================================*/
/* Table: bbus011                                               */
/*==============================================================*/
create table dbo.bbus011 (
   recid                uniqueidentifier     not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   bbusk01              nvarchar(2)          not null,
   bbusk02              nvarchar(20)         not null default '',
   bbusk03              int                  not null default 0,
   bbusk04              int                  not null default 0,
   bbusk05a             int                  not null default 0,
   bbusk05b             int                  not null default 0,
   bbusk05c             nvarchar(1)          not null default '',
   bbusk06              int                  not null default 0,
   bbusk07a             int                  not null default 0,
   bbusk07b             int                  not null default 0,
   bbusk07c             nvarchar(1)          not null default '',
   bbusk08              int                  not null default 0,
   bbusk09a             int                  not null default 0,
   bbusk09b             int                  not null default 0,
   bbusk09c             nvarchar(1)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '區分碼;區分碼',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭代碼;嘜頭代碼',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk01'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭說明;嘜頭說明',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk02'
go

execute sp_addextendedproperty 'MS_Description', 
   '語言別;語言別',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk03'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜;正嘜',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk04'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜高度;正嘜高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜寬度;正嘜寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜尺寸單位;正嘜尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜;側嘜',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk06'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜高度;側嘜高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜寬度;側嘜寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜尺寸單位;側嘜尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒;內盒',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk08'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒高度;內盒高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09a'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒寬度;內盒寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09b'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒尺寸單位;內盒尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09c'
go

alter table dbo.bbus011
   add constraint PK_BBUS011 primary key (biz_type, biz_no, bbusk01)
      on "PRIMARY"
go

ALTER TABLE bacr003 ALTER COLUMN mst_func nvarchar(3) NOT NULL
GO

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bbus011'))
drop table dbo.bbus011
go

/*==============================================================*/
/* Table: bbus011                                               */
/*==============================================================*/
create table dbo.bbus011 (
   recid                uniqueidentifier     not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   bbusk01              nvarchar(2)          not null,
   bbusk02              nvarchar(20)         not null default '',
   bbusk03              int                  not null default 0,
   bbusk04              int                  not null default 0,
   bbusk05a             int                  not null default 0,
   bbusk05b             int                  not null default 0,
   bbusk05c             nvarchar(1)          not null default '',
   bbusk05d             int                  not null default 0,
   bbusk06              int                  not null default 0,
   bbusk07a             int                  not null default 0,
   bbusk07b             int                  not null default 0,
   bbusk07c             nvarchar(1)          not null default '',
   bbusk07d             int                  not null default 0,
   bbusk08              int                  not null default 0,
   bbusk09a             int                  not null default 0,
   bbusk09b             int                  not null default 0,
   bbusk09c             nvarchar(1)          not null default '',
   bbusk09d             int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '區分碼;區分碼',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭代碼;嘜頭代碼',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk01'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭說明;嘜頭說明',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk02'
go

execute sp_addextendedproperty 'MS_Description', 
   '語言別;語言別',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk03'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜;正嘜',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk04'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜高度;正嘜高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜寬度;正嘜寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜尺寸單位;正嘜尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '正嘜縮圖ID;正嘜縮圖ID',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk05d'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜;側嘜',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk06'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜高度;側嘜高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜寬度;側嘜寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜尺寸單位;側嘜尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07c'
go

execute sp_addextendedproperty 'MS_Description', 
   '側嘜縮圖ID;側嘜縮圖ID',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk07d'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒;內盒',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk08'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒高度;內盒高度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09a'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒寬度;內盒寬度',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09b'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒尺寸單位;內盒尺寸單位',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內盒縮圖ID;內盒縮圖ID',
   'schema', 'dbo', 'table', 'bbus011', 'column', 'bbusk09d'
go

alter table dbo.bbus011
   add constraint PK_BBUS011 primary key (biz_type, biz_no, bbusk01)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/1/5 AM 09:51:47                         */
/*==============================================================*/


alter table dbo.dord001
   drop constraint PK_DORD001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord001'))
drop table dbo.tmp_dord001
go

execute sp_rename dord001, tmp_dord001
go

/*==============================================================*/
/* Table: dord001                                               */
/*==============================================================*/
create table dbo.dord001 (
   recid                uniqueidentifier     not null,
   dorda01a             nvarchar(2)          not null,
   dorda01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   dorda02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   dorda03a             nvarchar(2)          not null default '',
   dorda03b             nvarchar(16)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   dorda04a             nvarchar(2)          not null default '',
   dorda04b             nvarchar(16)         not null default '',
   dorda04c             int                  not null default 0,
   dorda04d             nvarchar(20)         not null default '',
   dorda05a             nvarchar(2)          not null default '',
   dorda05b             nvarchar(16)         not null default '',
   dorda05c             int                  not null default 0,
   dorda05d             nvarchar(20)         not null default '',
   dorda06              nvarchar(6)          not null default '',
   dorda06a             nvarchar(30)         not null default '',
   dorda06b             nvarchar(20)         not null default '',
   dorda06c             nvarchar(20)         not null default '',
   dorda06d             nvarchar(20)         not null default '',
   dorda06e             nvarchar(40)         not null default '',
   dorda07              nvarchar(20)         not null default '',
   dorda08a             nvarchar(20)         not null default '',
   dorda08b             nvarchar(20)         not null default '',
   dorda08c             nvarchar(20)         not null default '',
   dorda09              nvarchar(20)         not null default '',
   dorda10a             nvarchar(20)         not null default '',
   dorda10b             nvarchar(5)          not null default '',
   dorda10c             numeric(9,5)         not null default 0,
   dorda10d             numeric(9,5)         not null default 0,
   dorda10e             numeric(9,5)         not null default 0,
   dorda11a             datetime             not null default CONVERT(DATETIME,0),
   dorda11b             nvarchar(80)         not null default '',
   dorda13a             nvarchar(6)          not null default '',
   dorda13b             nvarchar(80)         not null default '',
   dorda13c             int                  not null default 0,
   dorda13d             numeric(9,5)         not null default 0,
   dorda13e             int                  not null default 0,
   dorda13f             numeric(9,5)         not null default 0,
   dorda14              nvarchar(80)         not null default '',
   dorda15              nvarchar(2)          not null default '',
   dorda16a             nvarchar(1)          not null default '',
   dorda16b             nvarchar(10)         not null default '',
   dorda17a             nvarchar(1)          not null default '',
   dorda17b             nvarchar(10)         not null default '',
   dorda18a             nvarchar(1)          not null default '',
   dorda18b             nvarchar(10)         not null default '',
   dorda19a             nvarchar(1)          not null default '',
   dorda19b             nvarchar(10)         not null default '',
   dorda20a             nvarchar(1)          not null default '',
   dorda20b             nvarchar(10)         not null default '',
   dorda21              nvarchar(10)         not null default '',
   dorda21a             nvarchar(1)          not null default '',
   dorda21b             nvarchar(10)         not null default '',
   dorda21c             nvarchar(1)          not null default '',
   dorda21d             nvarchar(2)          not null default '',
   dorda22a             nvarchar(5)          not null default '',
   dorda22b             numeric(9,5)         not null default 0,
   dorda22c             numeric(9,5)         not null default 0,
   dorda22d             nvarchar(1)          not null default '',
   dorda22e             numeric(9,5)         not null default 0,
   dorda22f             nvarchar(5)          not null default '',
   dorda23a             nvarchar(1)          not null default '',
   dorda23b             nvarchar(6)          not null default '',
   dorda23c             nvarchar(6)          not null default '',
   dorda23d             nvarchar(1)          not null default '',
   dorda23e             nvarchar(1)          not null default '',
   dorda23f             nvarchar(1)          not null default '',
   dorda23g             nvarchar(1)          not null default '',
   doc_dig1             int                  not null default 0,
   doc_dig2             int                  not null default 0,
   doc_dig3             int                  not null default 0,
   comp_dig1            int                  not null default 0,
   comp_dig2            int                  not null default 0,
   comp_dig3            int                  not null default 0,
   dorda24a             nvarchar(1)          not null default '',
   dorda24b             numeric(9,5)         not null default 0,
   dorda24c             nvarchar(1)          not null default '',
   dorda25a             nvarchar(7)          not null default '',
   dorda25b             nvarchar(27)         not null default '',
   dorda26a             numeric(9,5)         not null default 0,
   dorda26b             numeric(9,5)         not null default 0,
   dorda26c             numeric(9,5)         not null default 0,
   dorda26d             numeric(9,5)         not null default 0,
   dorda26e             nvarchar(1)          not null default '',
   dorda26f             numeric(9,5)         not null default 0,
   dorda26g             numeric(9,5)         not null default 0,
   dorda26h             numeric(9,5)         not null default 0,
   dorda27              numeric(9,5)         not null default 0,
   dorda28a             nvarchar(10)         not null default '',
   dorda28b             nvarchar(10)         not null default '',
   dorda29a             nvarchar(10)         not null default '',
   dorda29b             numeric(19,5)        not null default 0,
   dorda29c             numeric(19,5)        not null default 0,
   dorda29d             numeric(19,5)        not null default 0,
   dorda29e             nvarchar(1)          not null default '',
   dorda30              nvarchar(2)          not null default '',
   dorda32              numeric(19,5)        not null default 0,
   dorda33              numeric(19,5)        not null default 0,
   dorda34              numeric(19,5)        not null default 0,
   dorda35              numeric(19,5)        not null default 0,
   dorda37              numeric(19,5)        not null default 0,
   dorda38              numeric(19,5)        not null default 0,
   dorda39              numeric(19,5)        not null default 0,
   dorda40              numeric(19,5)        not null default 0,
   dorda41              numeric(19,5)        not null default 0,
   dorda42              numeric(19,5)        not null default 0,
   dorda43a             numeric(19,5)        not null default 0,
   dorda43b             numeric(19,5)        not null default 0,
   dorda44              numeric(19,5)        not null default 0,
   dorda45a             nvarchar(1)          not null default '',
   dorda45b             datetime             not null default CONVERT(DATETIME,0),
   dorda46a             nvarchar(1)          not null default '',
   dorda46b             datetime             not null default CONVERT(DATETIME,0),
   dorda47              int                  not null default 0,
   dorda47a             nvarchar(2)          not null,
   dorda47b             nvarchar(16)         not null,
   dorda48              numeric(19,5)        not null default 0,
   user_text1           nvarchar(20)         not null default '',
   user_text2           nvarchar(20)         not null default '',
   user_text3           nvarchar(20)         not null default '',
   user_text4           nvarchar(20)         not null default '',
   user_text5           nvarchar(20)         not null default '',
   user_num1            numeric(19,5)        not null default 0,
   user_num2            numeric(19,5)        not null default 0,
   user_num3            numeric(19,5)        not null default 0,
   user_num4            numeric(19,5)        not null default 0,
   user_num5            numeric(19,5)        not null default 0,
   dorda51              numeric(19,5)        not null default 0,
   dorda52              numeric(19,5)        not null default 0,
   dorda53              numeric(19,5)        not null default 0,
   dorda54              numeric(19,5)        not null default 0,
   dorda55              int                  not null default 0,
   dorda56a             nvarchar(1)          not null default '',
   dorda56b             datetime             not null default CONVERT(DATETIME,0),
   dorda57a             nvarchar(1)          not null default '',
   dorda57b             datetime             not null default CONVERT(DATETIME,0),
   dorda58a             nvarchar(1)          not null default '',
   dorda58b             datetime             not null default CONVERT(DATETIME,0),
   dorda59a             nvarchar(1)          not null default '',
   dorda59b             datetime             not null default CONVERT(DATETIME,0),
   dorda60              nvarchar(1)          not null default '',
   wh_no                nvarchar(4)          not null default '',
   dorda61              datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status1          nvarchar(1)          not null default '',
   last_user1           nvarchar(10)         not null default '',
   last_date1           datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dord001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單別;合約單別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單號;合約單號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'dord001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'dord001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dord001', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda04b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda04c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda04d'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda05d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡人代碼;聯絡人代碼',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一;聯絡電話一',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二;聯絡電話二',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真;聯絡傳真',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email;聯絡email',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda06e'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶訂單;客戶訂單',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda07'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda08a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda08b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda08c'
go

execute sp_addextendedproperty 'MS_Description', 
   '專案代號;專案代號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda09'
go

execute sp_addextendedproperty 'MS_Description', 
   '目的地國別;目的地國別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '目的地國別關稅幣別;目的地國別關稅幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '匯率 - 公司幣;匯率 - 公司幣',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda10c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Duty%;Duty%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda10d'
go

execute sp_addextendedproperty 'MS_Description', 
   'Tax%;Tax%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda10e'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計出貨日;預計出貨日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計出貨日描述;預計出貨日描述',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda11b'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment code;payment code',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13a'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment desc.;payment desc.',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)幾天內;現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13c'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)扣幾%;現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13d'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)幾天內;現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13e'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)扣幾%;現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda13f'
go

execute sp_addextendedproperty 'MS_Description', 
   'shipment 描述;shipment 描述',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda14'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭編號;嘜頭編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda15'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象別;Agent對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda16a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象編號;Agent對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda16b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象別;Consignee對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda17a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象編號;Consignee對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda17b'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象別;A/Notify對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda18a'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象編號;A/Notify對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象別;收款對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象編號;收款對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象別;交貨對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda20a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象編號;交貨對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda20b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU轉單方案;OBU轉單方案',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda21'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單對象別;轉單對象別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda21a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單對象編號;轉單對象編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda21b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉產生標記;OBU拋轉產生標記',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda21c'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉狀態標記;OBU拋轉狀態標記',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda21d'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單幣別;轉單幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單匯率-公司幣別;轉單匯率-公司幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單匯率-系統幣別;轉單匯率-系統幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22c'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單稅別;轉單稅別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22d'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單稅率;轉單稅率',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22e'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款幣別;收款幣別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda22f'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金交易;佣金交易',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23a'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23b'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23c'
go

execute sp_addextendedproperty 'MS_Description', 
   '成本預設;成本預設',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23d'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格預設;價格預設',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23e'
go

execute sp_addextendedproperty 'MS_Description', 
   '供應商價格序預設 1;供應商價格序預設 1',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23f'
go

execute sp_addextendedproperty 'MS_Description', 
   '供應商價格序預設 2;供應商價格序預設 2',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda23g'
go

execute sp_addextendedproperty 'MS_Description', 
   '單價小數位;單價小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '小計小數位;小計小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '總計小數位;總計小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣單價小數位;換算公司幣單價小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'comp_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣小計小數位;換算公司幣小計小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'comp_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣總計小數位;換算公司幣總計小數位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'comp_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動取位設定;啟動取位設定',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda24a'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位設定基數;取位設定基數',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda24b'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位不整除;取位不整除',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda24c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Code;Price Term Code',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda25a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Desc;Price Term Desc',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda25b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Profit1% -製造利潤;Profit1% -製造利潤',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Profit2%-銷售利潤;Profit2%-銷售利潤',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Insurance%;Insurance%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Commision%;Commision%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動分段Commission;啟動分段Commission',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26e'
go

execute sp_addextendedproperty 'MS_Description', 
   'Commision1%;Commision1%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26f'
go

execute sp_addextendedproperty 'MS_Description', 
   'DA%(雜費);DA%(雜費)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26g'
go

execute sp_addextendedproperty 'MS_Description', 
   'Misc. Charge%;Misc. Charge%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda26h'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValue%;UnderValue%',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda27'
go

execute sp_addextendedproperty 'MS_Description', 
   '運費區別碼;運費區別碼',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda28a'
go

execute sp_addextendedproperty 'MS_Description', 
   '運送方式;運送方式',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda28b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Freight Code;Freight Code',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda29a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Freight $/重量單位;Freight $/重量單位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda29b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Freight $/體積單位;Freight $/體積單位',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda29c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Freight $/貨櫃;Freight $/貨櫃',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda29d'
go

execute sp_addextendedproperty 'MS_Description', 
   '運費貨櫃樣式;運費貨櫃樣式',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda29e'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票聯式/种類;發票聯式/种類',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda30'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda32'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda33'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total G.W.(KG);Total G.W.(KG)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda34'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total Measm''t(Cu''ft);Total Measm''t(Cu''ft)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda35'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品未稅總額;產品未稅總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda37'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品含稅總額;產品含稅總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda38'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款未稅總額;加扣款未稅總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda39'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款含稅總額;加扣款含稅總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda40'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金總額;稅金總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda41'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品Undervalue總額;產品Undervalue總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda42'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單總額(轉單幣別);轉單總額(轉單幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda43a'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估佣金總額(訂單幣別);預估佣金總額(訂單幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda43b'
go

execute sp_addextendedproperty 'MS_Description', 
   '應收訂金總額(訂單幣別);應收訂金總額(訂單幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda44'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1選中;追蹤項目1選中',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda45a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1;追蹤項目1',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda45b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2選中;追蹤項目2選中',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda46a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2;追蹤項目2',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda46b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Revised 修改次數;Revised 修改次數',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda47'
go

execute sp_addextendedproperty 'MS_Description', 
   '當前變更單別;當前變更單別',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda47a'
go

execute sp_addextendedproperty 'MS_Description', 
   '當前變更單號;當前變更單號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda47b'
go

execute sp_addextendedproperty 'MS_Description', 
   '可超交率;可超交率',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda48'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值一;自定義文字欄值一',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值二;自定義文字欄值二',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值三;自定義文字欄值三',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值四;自定義文字欄值四',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值五;自定義文字欄值五',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值一;自定義數值欄值一',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值二;自定義數值欄值二',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值三;自定義數值欄值三',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值四;自定義數值欄值四',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值五;自定義數值欄值五',
   'schema', 'dbo', 'table', 'dord001', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '商品採購成本未稅總額(公司幣別);商品採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda51'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配採購成本未稅總額(公司幣別);贈配採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda52'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估費用總額(公司幣別);預估費用總額(公司幣別)',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda53'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款總額;代收款總額',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda54'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據已列印次數;單據已列印次數',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda55'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤跟催日否;追蹤跟催日否',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda56a'
go

execute sp_addextendedproperty 'MS_Description', 
   '跟催日;跟催日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda56b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤客戶簽回日否;追蹤客戶簽回日否',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda57a'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶簽回日;客戶簽回日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda57b'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後出貨日選中;最後出貨日選中',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda58a'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後出貨日;最後出貨日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda58b'
go

execute sp_addextendedproperty 'MS_Description', 
   '收到L/C日選中;收到L/C日選中',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda59a'
go

execute sp_addextendedproperty 'MS_Description', 
   '收到L/C日;收到L/C日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda59b'
go

execute sp_addextendedproperty 'MS_Description', 
   '未付訂金不處理後續作業;未付訂金不處理後續作業',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda60'
go

execute sp_addextendedproperty 'MS_Description', 
   '倉庫編號;倉庫編號',
   'schema', 'dbo', 'table', 'dord001', 'column', 'wh_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '立帳日期;立帳日期',
   'schema', 'dbo', 'table', 'dord001', 'column', 'dorda61'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dord001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dord001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dord001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉覆核/作廢;拋轉覆核/作廢',
   'schema', 'dbo', 'table', 'dord001', 'column', 'doc_status1'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態人;拋轉最後更改狀態人',
   'schema', 'dbo', 'table', 'dord001', 'column', 'last_user1'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態日;拋轉最後更改狀態日',
   'schema', 'dbo', 'table', 'dord001', 'column', 'last_date1'
go

insert into dbo.dord001 (recid, dorda01a, dorda01b, doc_comp, dorda02, doc_date, biz_type, biz_no, dorda03a, dorda03b, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dorda04a, dorda04b, dorda04c, dorda04d, dorda05a, dorda05b, dorda05c, dorda05d, dorda06, dorda06a, dorda06b, dorda06c, dorda06d, dorda06e, dorda07, dorda08a, dorda08b, dorda08c, dorda09, dorda10a, dorda10b, dorda10c, dorda10d, dorda10e, dorda11a, dorda11b, dorda13a, dorda13b, dorda13c, dorda13d, dorda13e, dorda13f, dorda14, dorda15, dorda16a, dorda16b, dorda17a, dorda17b, dorda18a, dorda18b, dorda19a, dorda19b, dorda20a, dorda20b, dorda21, dorda21a, dorda21b, dorda21c, dorda21d, dorda22a, dorda22b, dorda22c, dorda22d, dorda22e, dorda22f, dorda23a, dorda23b, dorda23c, dorda23d, dorda23e, dorda23f, dorda23g, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dorda24a, dorda24b, dorda24c, dorda25a, dorda25b, dorda26a, dorda26b, dorda26c, dorda26d, dorda26e, dorda26f, dorda26g, dorda26h, dorda27, dorda28a, dorda28b, dorda29a, dorda29b, dorda29c, dorda29d, dorda29e, dorda30, dorda32, dorda33, dorda34, dorda35, dorda37, dorda38, dorda39, dorda40, dorda41, dorda42, dorda43a, dorda43b, dorda44, dorda45a, dorda45b, dorda46a, dorda46b, dorda47, dorda47a, dorda47b, dorda48, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dorda51, dorda52, dorda53, dorda54, dorda55, dorda56a, dorda56b, dorda57a, dorda57b, dorda58a, dorda58b, dorda59a, dorda59b, dorda60, wh_no, dorda61, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1)
select recid, dorda01a, dorda01b, doc_comp, dorda02, doc_date, biz_type, biz_no, dorda03a, dorda03b, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dorda04a, dorda04b, dorda04c, dorda04d, dorda05a, dorda05b, dorda05c, dorda05d, dorda06, dorda06a, dorda06b, dorda06c, dorda06d, dorda06e, dorda07, dorda08a, dorda08b, dorda08c, dorda09, dorda10a, dorda10b, dorda10c, dorda10d, dorda10e, dorda11a, dorda11b, dorda13a, dorda13b, dorda13c, dorda13d, dorda13e, dorda13f, dorda14, dorda15, dorda16a, dorda16b, dorda17a, dorda17b, dorda18a, dorda18b, dorda19a, dorda19b, dorda20a, dorda20b, dorda21, dorda21a, dorda21b, dorda21c, dorda21d, dorda22a, dorda22b, dorda22c, dorda22d, dorda22e, dorda22f, dorda23a, dorda23b, dorda23c, dorda23d, dorda23e, dorda23f, dorda23g, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dorda24a, dorda24b, dorda24c, dorda25a, dorda25b, dorda26a, dorda26b, dorda26c, dorda26d, dorda26e, dorda26f, dorda26g, dorda26h, dorda27, dorda28a, dorda28b, dorda29a, dorda29b, dorda29c, dorda29d, dorda29e, dorda30, dorda32, dorda33, dorda34, dorda35, dorda37, dorda38, dorda39, dorda40, dorda41, dorda42, dorda43a, dorda43b, dorda44, dorda45a, dorda45b, dorda46a, dorda46b, dorda47, '', '', dorda48, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dorda51, dorda52, dorda53, dorda54, dorda55, dorda56a, dorda56b, dorda57a, dorda57b, dorda58a, dorda58b, dorda59a, dorda59b, dorda60, wh_no, dorda61, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1
from dbo.tmp_dord001
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord001'))
drop table dbo.tmp_dord001
go
alter table dbo.dord001
   add constraint PK_DORD001 primary key (dorda01a, dorda01b)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.ldoc014'))
drop table dbo.ldoc014
go

/*==============================================================*/
/* Table: ldoc014                                               */
/*==============================================================*/
create table dbo.ldoc014 (
   recid                uniqueidentifier     not null,
   ldocn01a             nvarchar(2)          not null,
   ldocn01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   doc_staff            nvarchar(10)         not null default '',
   ldocn02a             nvarchar(2)          not null default '',
   ldocn02b             nvarchar(16)         not null default '',
   ldocn03              nvarchar(80)         not null default '',
   ldocn04              varbinary(max)       null,
   ldocn05              varbinary(max)       null,
   ldocn06              varbinary(max)       null,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更單別;變更單別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更單號;變更單號',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更日期;變更日期',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更業務員;變更業務員',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '原始單別;原始單別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原始單號;原始單號',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更原因;變更原因',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn03'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更前內容;變更前內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更後內容;變更後內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn05'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更內容;變更內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_date'
go

alter table dbo.ldoc014
   add constraint PK_LDOC014 primary key (ldocn01a, ldocn01b)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bacr006'))
drop table dbo.bacr006
go

/*==============================================================*/
/* Table: bacr006                                               */
/*==============================================================*/
create table dbo.bacr006 (
   recid                uniqueidentifier     not null,
   mst_func             nvarchar(3)          not null,
   mst_no               nvarchar(16)         not null,
   num                  int                  not null,
   make_type            int                  not null,
   doc_type             nvarchar(2)          not null default '',
   doc_no               nvarchar(16)         not null default '',
   order_no             nvarchar(20)         not null default '',
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   item_seq             nvarchar(10)         not null default '',
   pk_id                int                  not null default 0,
   image_h              int                  not null default 0,
   image_w              int                  not null default 0,
   file_sub             nvarchar(2)          not null default '',
   mark_desc            nvarchar(20)         not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default ''
)
on "PRIMARY"
go
execute sp_addextendedproperty 'MS_Description', 
   '嘜頭說明;嘜頭說明',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'mark_desc'
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔單別;主檔單別',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'mst_func'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔資料單號;主檔資料單號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'mst_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產生方式;產生方式',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'make_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單別;訂單單別',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'doc_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單號;訂單單號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'doc_no'
go

execute sp_addextendedproperty 'MS_Description', 
   'ORDER#;ORDER#',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'order_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品項次;產品項次',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'item_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭ID;嘜頭ID',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '畫象高度(像素);畫象高度(像素)',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'image_h'
go

execute sp_addextendedproperty 'MS_Description', 
   '畫象寬度(像素);畫象寬度(像素)',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'image_w'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料子類型;資料子類型',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'file_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'bacr006', 'column', 'doc_status'
go

alter table dbo.bacr006
   add constraint PK_BACR006 primary key (mst_func, mst_no, num)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_bacr006_1                                         */
/*==============================================================*/
create unique index idx_bacr006_1 on dbo.bacr006 (
pk_id ASC,
mst_func ASC,
mst_no ASC
)
on "PRIMARY"
go

alter table arpt003 add arptc12 nvarchar(5) not null default ''
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/2/16 AM 11:37:35                        */
/*==============================================================*/


alter table dbo.dinv001
   add doc_status2 nvarchar(1) not null default ''
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉覆核/作廢;拋轉覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status2'
go

alter table dbo.dinv001
   add last_user2 nvarchar(10) not null default ''
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態人;拋轉最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user2'
go

alter table dbo.dinv001
   add last_date2 datetime not null default CONVERT(DATETIME,0)
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態日;拋轉最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date2'
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/2/12 PM 05:17:04                        */
/*==============================================================*/


alter table dbo.dinv001
   drop constraint PK_DINV001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv001'))
drop table dbo.tmp_dinv001
go

execute sp_rename dinv001, tmp_dinv001
go

/*==============================================================*/
/* Table: dinv001                                               */
/*==============================================================*/
create table dbo.dinv001 (
   recid                uniqueidentifier     not null,
   dinva01a             nvarchar(2)          not null,
   dinva01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   dinva02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   dinva03              nvarchar(60)         not null default '',
   dinva04              nvarchar(20)         not null default '',
   dinva04a             nvarchar(20)         not null default '',
   dinva05a             nvarchar(20)         not null default '',
   dinva05b             nvarchar(20)         not null default '',
   dinva05c             nvarchar(20)         not null default '',
   dinva06a             nvarchar(80)         not null default '',
   dinva06b             nvarchar(200)        not null default '',
   dinva07              nvarchar(1)          not null default '',
   dinva08              numeric(9,5)         not null default 0,
   dinva09              nvarchar(1)          not null default '',
   dinva10a             datetime             not null default CONVERT(DATETIME,0),
   dinva10b             datetime             not null default CONVERT(DATETIME,0),
   dinva10c             datetime             not null default CONVERT(DATETIME,0),
   dinva10d             datetime             not null default CONVERT(DATETIME,0),
   dinva11              nvarchar(20)         not null default '',
   dinva12              nvarchar(20)         not null default '',
   dinva13a             nvarchar(1)          not null default '',
   dinva13b             nvarchar(10)         not null default '',
   dinva14a             nvarchar(1)          not null default '',
   dinva14b             nvarchar(10)         not null default '',
   dinva15a             nvarchar(1)          not null default '',
   dinva15b             nvarchar(10)         not null default '',
   dinva15c             nvarchar(1)          null default '',
   dinva15d             nvarchar(10)         null default '',
   dinva15e             nvarchar(6)          null default '',
   dinva15f             nvarchar(80)         null default '',
   dinva16a             nvarchar(1)          not null default '',
   dinva16b             nvarchar(10)         not null default '',
   dinva17a             nvarchar(1)          not null default '',
   dinva17b             nvarchar(10)         not null default '',
   dinva18a             nvarchar(1)          not null default '',
   dinva18b             nvarchar(10)         not null default '',
   dinva19              nvarchar(10)         not null default '',
   dinva19a             nvarchar(1)          not null default '',
   dinva19b             nvarchar(2)          not null default '',
   dinva20              nvarchar(20)         not null default '',
   dinva21a             nvarchar(1)          not null default '',
   dinva21b             nvarchar(10)         not null default '',
   dinva21c             nvarchar(80)         not null default '',
   dinva22a             nvarchar(1)          not null default '',
   dinva22b             nvarchar(10)         not null default '',
   dinva22c             nvarchar(80)         not null default '',
   dinva23              datetime             not null default CONVERT(DATETIME,0),
   dinva26              nvarchar(6)          not null default '',
   dinva26a             nvarchar(30)         not null default '',
   dinva26b             nvarchar(20)         not null default '',
   dinva26c             nvarchar(20)         not null default '',
   dinva26d             nvarchar(20)         not null default '',
   dinva26e             nvarchar(40)         not null default '',
   dinva27              nvarchar(2)          not null default '',
   dinva24              nvarchar(10)         not null default '',
   dinva25              nvarchar(10)         not null default '',
   dinva28              nvarchar(1)          not null default '',
   dinva29a             nvarchar(40)         not null default '',
   dinva29b             nvarchar(40)         not null default '',
   dinva29c             nvarchar(40)         not null default '',
   dinva30a             nvarchar(2)          not null default '',
   dinva30b             nvarchar(16)         not null default '',
   dinva31a             nvarchar(2)          not null default '',
   dinva31b             nvarchar(16)         not null default '',
   dinva31c             int                  not null default 0,
   dinva31d             nvarchar(20)         not null default '',
   dinva31e             nvarchar(2)          not null default '',
   dinva32a             nvarchar(2)          not null default '',
   dinva32b             nvarchar(16)         not null default '',
   dinva32c             int                  not null default 0,
   dinva32d             nvarchar(20)         not null default '',
   dinva33              nvarchar(6)          not null default '',
   dinva34              nvarchar(6)          not null default '',
   doc_dig1             int                  not null default 0,
   doc_dig2             int                  not null default 0,
   doc_dig3             int                  not null default 0,
   comp_dig1            int                  not null default 0,
   comp_dig2            int                  not null default 0,
   comp_dig3            int                  not null default 0,
   dinva35a             nvarchar(1)          not null default '',
   dinva35b             numeric(9,5)         not null default 0,
   dinva35c             nvarchar(1)          not null default '',
   dinva36a             nvarchar(20)         not null default '',
   dinva36b             nvarchar(20)         not null default '',
   dinva37a             nvarchar(6)          not null default '',
   dinva37b             nvarchar(80)         not null default '',
   dinva37c             int                  not null default 0,
   dinva37d             numeric(9,5)         not null default 0,
   dinva37e             int                  not null default 0,
   dinva37f             numeric(9,5)         not null default 0,
   dinva38a             nvarchar(1)          not null default '',
   dinva38b             nvarchar(1)          not null default '',
   dinva38c             nvarchar(1)          not null default '',
   dinva38d             nvarchar(1)          not null default '',
   dinva38e             nvarchar(1)          not null default '',
   dinva38f             nvarchar(1)          not null default '',
   dinva38g             nvarchar(1)          not null default '',
   dinva38h             nvarchar(1)          not null default '',
   dinva40              numeric(19,5)        not null default 0,
   dinva41              numeric(19,5)        not null default 0,
   dinva42              numeric(19,5)        not null default 0,
   dinva43              numeric(19,5)        not null default 0,
   dinva44              numeric(19,5)        not null default 0,
   dinva45              numeric(19,5)        not null default 0,
   dinva46              numeric(19,5)        not null default 0,
   dinva47              numeric(19,5)        not null default 0,
   dinva50              numeric(19,5)        not null default 0,
   dinva51              numeric(19,5)        not null default 0,
   dinva52              numeric(19,5)        not null default 0,
   dinva53              numeric(19,5)        not null default 0,
   dinva54              numeric(19,5)        not null default 0,
   dinva55              numeric(19,5)        not null default 0,
   dinva56              numeric(19,5)        not null default 0,
   dinva57              numeric(19,5)        not null default 0,
   dinva58              numeric(19,5)        not null default 0,
   dinva59              numeric(19,5)        not null default 0,
   user_text1           nvarchar(20)         not null default '',
   user_text2           nvarchar(20)         not null default '',
   user_text3           nvarchar(20)         not null default '',
   user_text4           nvarchar(20)         not null default '',
   user_text5           nvarchar(20)         not null default '',
   user_num1            numeric(19,5)        not null default 0,
   user_num2            numeric(19,5)        not null default 0,
   user_num3            numeric(19,5)        not null default 0,
   user_num4            numeric(19,5)        not null default 0,
   user_num5            numeric(19,5)        not null default 0,
   dinva60b             int                  not null default 0,
   dinva60c             int                  not null default 0,
   dinva61b             int                  not null default 0,
   dinva61c             int                  not null default 0,
   dinva62b             int                  not null default 0,
   dinva62c             int                  not null default 0,
   dinva63b             int                  not null default 0,
   dinva63c             int                  not null default 0,
   dinva64b             int                  not null default 0,
   dinva64c             int                  not null default 0,
   dinva65b             int                  not null default 0,
   dinva65c             int                  not null default 0,
   dinva66b             int                  not null default 0,
   dinva66c             int                  not null default 0,
   dinva67a             nvarchar(20)         not null default '',
   dinva67b             int                  not null default 0,
   dinva67c             int                  not null default 0,
   dinva68a             nvarchar(20)         not null default '',
   dinva68b             int                  not null default 0,
   dinva68c             int                  not null default 0,
   dinva69a             nvarchar(20)         not null default '',
   dinva69b             int                  not null default 0,
   dinva69c             int                  not null default 0,
   dinva70a             nvarchar(20)         not null default '',
   dinva70b             int                  not null default 0,
   dinva70c             int                  not null default 0,
   dinva71a             nvarchar(20)         not null default '',
   dinva71b             int                  not null default 0,
   dinva71c             int                  not null default 0,
   dinva73a             nvarchar(1)          not null default '',
   dinva73b             nvarchar(10)         not null default '',
   dinva74              nvarchar(1)          not null default '',
   dinva75              datetime             not null default CONVERT(DATETIME,0),
   dinva76a             numeric(19,5)        not null default 0,
   dinva76b             numeric(19,5)        not null default 0,
   dinva77a             numeric(9,5)         not null default 0,
   dinva77b             numeric(9,5)         not null default 0,
   dinva78a             numeric(9,5)         not null default 0,
   dinva78b             numeric(9,5)         not null default 0,
   dinva79              nvarchar(1)          not null default '',
   dinva81              int                  not null default 0,
   dinva82a             nvarchar(1)          not null default '',
   dinva82b             datetime             not null default CONVERT(DATETIME,0),
   dinva83a             nvarchar(1)          not null default '',
   dinva83b             datetime             not null default CONVERT(DATETIME,0),
   dinva84a             nvarchar(1)          not null default '',
   dinva84b             datetime             not null default CONVERT(DATETIME,0),
   dinva85a             nvarchar(1)          not null default '',
   dinva85b             datetime             not null default CONVERT(DATETIME,0),
   dinva86              nvarchar(4)          not null default '',
   dinva87              int                  not null default 0,
   dinva88              datetime             not null default CONVERT(DATETIME,0),
   dinva89              datetime             not null default CONVERT(DATETIME,0),
   dinva90a             datetime             not null default CONVERT(DATETIME,0),
   dinva90b             datetime             not null default CONVERT(DATETIME,0),
   dinva91a             nvarchar(1)          not null default '',
   dinva91b             nvarchar(1)          not null default '',
   dinva91c             nvarchar(10)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status1          nvarchar(1)          not null default '',
   last_user1           nvarchar(10)         not null default '',
   last_date1           datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   'vessel;vessel',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva03'
go

execute sp_addextendedproperty 'MS_Description', 
   '專案代號;專案代號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva04'
go

execute sp_addextendedproperty 'MS_Description', 
   '對方單號;對方單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva04a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象名稱(用於印表);對象名稱(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象地址(用於印表);對象地址(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金交易;佣金交易',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValue%;UnderValue%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva08'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱數計算依;箱數計算依',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva09'
go

execute sp_addextendedproperty 'MS_Description', 
   'On Board Date;On Board Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Close Date;Close Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計出貨日;預計出貨日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10c'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計到達日;預計到達日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10d'
go

execute sp_addextendedproperty 'MS_Description', 
   '原產地;原產地',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva11'
go

execute sp_addextendedproperty 'MS_Description', 
   'S/O No.;S/O No.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva12'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象別;報關行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象編號;報關行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象別;收款對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象編號;收款對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象別;交貨對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象編號;交貨對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象別;交貨地點對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15c'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象編號;交貨地點對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15d'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點序號;交貨地點序號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15e'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點描述;交貨地點描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15f'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象別;Agent對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象編號;Agent對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象別;Consignee對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象編號;Consignee對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17b'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象別;A/Notify對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18a'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象編號;A/Notify對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU出貨轉單方案;OBU出貨轉單方案',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉產生標記;OBU拋轉產生標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19a'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉狀態標記;OBU拋轉狀態標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排櫃單號;排櫃單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva20'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象別;接櫃人對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21a'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象編號;接櫃人對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21b'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人描述;接櫃人描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21c'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象別;放櫃處對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象編號;放櫃處對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22b'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處描述;放櫃處描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22c'
go

execute sp_addextendedproperty 'MS_Description', 
   '離廠日;離廠日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva23'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡人代碼;聯絡人代碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一;聯絡電話一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二;聯絡電話二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真;聯絡傳真',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email;聯絡email',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26e'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭編號;嘜頭編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva27'
go

execute sp_addextendedproperty 'MS_Description', 
   '驗貨人;驗貨人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva24'
go

execute sp_addextendedproperty 'MS_Description', 
   '船務;船務',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva25'
go

execute sp_addextendedproperty 'MS_Description', 
   '本單Packing和Invoice聯動;本單Packing和Invoice聯動',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva28'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 1;Invoice of …… 1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 2;Invoice of …… 2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 3;Invoice of …… 3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29c'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單別;合約單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單號;合約單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31d'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單類別;來源單類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31e'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva33'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva34'
go

execute sp_addextendedproperty 'MS_Description', 
   '單價小數位;單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '小計小數位;小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '總計小數位;總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣單價小數位;換算公司幣單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣小計小數位;換算公司幣小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣總計小數位;換算公司幣總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動取位設定;啟動取位設定',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35a'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位設定基數;取位設定基數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35b'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位不整除;取位不整除',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35c'
go

execute sp_addextendedproperty 'MS_Description', 
   '經海關証明文件編號;經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36a'
go

execute sp_addextendedproperty 'MS_Description', 
   '非經海關証明文件編號;非經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment code;payment code',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37a'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment desc.;payment desc.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37b'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)幾天內;現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37c'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)扣幾%;現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37d'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)幾天內;現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37e'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)扣幾%;現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況1-產生Packing;更檔狀況1-產生Packing',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38a'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況2-產生Invoice;更檔狀況2-產生Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38b'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況3-產生產品來源;更檔狀況3-產生產品來源',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38c'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況4-確認訂單出貨;更檔狀況4-確認訂單出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38d'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況5-確認採購出貨;更檔狀況5-確認採購出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38e'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況6-產生應收帳款;更檔狀況6-產生應收帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況7-產生應付帳款;更檔狀況7-產生應付帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38g'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況8-應收L/C押匯;更檔狀況8-應收L/C押匯',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38h'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva40'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva41'
go

execute sp_addextendedproperty 'MS_Description', 
   '總箱數;總箱數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva42'
go

execute sp_addextendedproperty 'MS_Description', 
   '總棧板數;總棧板數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva43'
go

execute sp_addextendedproperty 'MS_Description', 
   '總淨重;總淨重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva44'
go

execute sp_addextendedproperty 'MS_Description', 
   '總毛重;總毛重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva45'
go

execute sp_addextendedproperty 'MS_Description', 
   '總體積;總體積',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva46'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量(含分開包裝);總數量(含分開包裝)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva47'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice未稅總額;Invoice未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva50'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice含稅總額;Invoice含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva51'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice UnderValude 總額;Invoice UnderValude 總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva52'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款未稅總額;加扣款未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva53'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款含稅總額;加扣款含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva54'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金總額;稅金總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva55'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款總額;代收款總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva56'
go

execute sp_addextendedproperty 'MS_Description', 
   '商品採購成本未稅總額(公司幣別);商品採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva57'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配採購成本未稅總額(公司幣別);贈配採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva58'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估費用總額(公司幣別);預估費用總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva59'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值一;自定義文字欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值二;自定義文字欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值三;自定義文字欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值四;自定義文字欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值五;自定義文字欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值一;自定義數值欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值二;自定義數值欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值三;自定義數值欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值四;自定義數值欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值五;自定義數值欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Commerical Invoice;原稿份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Commerical Invoice;拷貝份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Customs Invoice;原稿份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Customs Invoice;拷貝份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Bill of Lading;原稿份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Bill of Lading;拷貝份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Packing List;原稿份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Packing List;拷貝份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Insur. Certificate;原稿份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Insur. Certificate;拷貝份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Certificate Origin;原稿份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Certificate Origin;拷貝份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Consular Invoice;原稿份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Consular Invoice;拷貝份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other1 Desc;Other1 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other1;原稿份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other1;拷貝份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other2 Desc;Other2 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other2;原稿份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other2;拷貝份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other3 Desc;Other3 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other3;原稿份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other3;拷貝份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other4 Desc;Other4 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other4;原稿份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other4;拷貝份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other5 Desc;Other5 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other5;原稿份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other5;拷貝份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71c'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象別;押匯銀行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象編號;押匯銀行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出口L/C帳款金額選擇;出口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva74'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯日期;押匯日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva75'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(單據幣別);押匯總金額(單據幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(公司幣別);押匯總金額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76b'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-公司幣別;押匯匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-系統幣別;押匯匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77b'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-公司幣別;結關匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78a'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-系統幣別;結關匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78b'
go

execute sp_addextendedproperty 'MS_Description', 
   '進口L/C帳款金額選擇;進口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva79'
go

execute sp_addextendedproperty 'MS_Description', 
   'Revised 修改次數;Revised 修改次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva81'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日選中;實際出口日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82a'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日;實際出口日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日選中;交件安裝日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日;交件安裝日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1選中;追蹤項目1選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1;追蹤項目1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2選中;追蹤項目2選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2;追蹤項目2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨倉庫;出貨倉庫',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva86'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據列印次數;單據列印次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva87'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據到期日;票據到期日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva88'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計收款日;預計收款日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva89'
go

execute sp_addextendedproperty 'MS_Description', 
   '立帳日期;立帳日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90a'
go

execute sp_addextendedproperty 'MS_Description', 
   '帳款月份;帳款月份',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90b'
go

execute sp_addextendedproperty 'MS_Description', 
   '隨貨開立發票否？;隨貨開立發票否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91a'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票全部開立否？;發票全部開立否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91b'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票號碼;發票號碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91c'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯覆核/作廢;押匯覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態人;押匯最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態日;押匯最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date1'
go

insert into dbo.dinv001 (recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva15c, dinva15d, dinva15e, dinva15f, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1)
select recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva15c, dinva15d, dinva15e, dinva15f, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1
from dbo.tmp_dinv001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv001'))
drop table dbo.tmp_dinv001
go

alter table dbo.dinv001
   add constraint PK_DINV001 primary key (dinva01a, dinva01b)
      on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/2/20 AM 11:30:28                        */
/*==============================================================*/

declare @sql varchar(200)
set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22f'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22f


set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22e'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22e

set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22d'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22d

set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22c'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22c

set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22b'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22b


set @sql = 'alter table chgdord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('chgdord001') and c.name = 'dorda22a'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.chgdord001
   drop column dorda22a

set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22f'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22f


set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22e'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22e

set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22d'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22d

set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22c'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22c

set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22b'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22b


set @sql = 'alter table dord001  drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dord001') and c.name = 'dorda22a'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dord001
   drop column dorda22a

GO

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.ncom003'))
drop table dbo.ncom003
go

/*==============================================================*/
/* Table: ncom003                                               */
/*==============================================================*/
create table dbo.ncom003 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   mst_recid            uniqueidentifier     not null,
   mst_func             nvarchar(2)          not null default '',
   mst_no               nvarchar(16)         not null default '',
   mst_pkid             int                  not null default 0,
   title                nvarchar(256)        not null default '',
   content              nvarchar(max)        not null default '',
   cont_format          int                  not null default 0,
   report_date          datetime             not null default CONVERT(DATETIME,0),
   work_start           datetime             not null default CONVERT(DATETIME,0),
   work_end             datetime             not null default CONVERT(DATETIME,0),
   work_hours           float                not null default 0,
   comp_degree          float                not null default 0,
   priority             int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作日報資料ID;工作日報資料ID',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作日報對應主檔資料的[recid];工作日報對應主檔資料的[recid]',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'mst_recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔單別;主檔單別',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'mst_func'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔資料單號;主檔資料單號',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'mst_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '主檔資料ID;主檔資料ID',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'mst_pkid'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容;內容',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'content'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容格式;內容格式',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'cont_format'
go

execute sp_addextendedproperty 'MS_Description', 
   '日報日期;日報日期',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'report_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作開始日期時間;工作開始日期時間',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'work_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作結束日期時間;工作結束日期時間',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'work_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作時數;工作時數',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'work_hours'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成度;完成度',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'comp_degree'
go

execute sp_addextendedproperty 'MS_Description', 
   '重要性;重要性',
   'schema', 'dbo', 'table', 'ncom003', 'column', 'priority'
go

alter table dbo.ncom003
   add constraint PK_NCOM003 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ncom003_1                                         */
/*==============================================================*/
create unique index idx_ncom003_1 on dbo.ncom003 (
mst_recid ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ncom003_2                                         */
/*==============================================================*/
create unique index idx_ncom003_2 on dbo.ncom003 (
mst_func ASC,
mst_no ASC,
mst_pkid ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ncom003_3                                         */
/*==============================================================*/
create index idx_ncom003_3 on dbo.ncom003 (
priority ASC
)
on "PRIMARY"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_BCOM006_1')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_BCOM006_1
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig004') and o.name = 'FK_ARIG004_REFERENCE_BCOM006_2')
alter table dbo.arig004
   drop constraint FK_ARIG004_REFERENCE_BCOM006_2
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.arpt001'))
drop table dbo.arpt001
go

/*==============================================================*/
/* Table: arpt001                                               */
/*==============================================================*/
create table dbo.arpt001 (
   recid                uniqueidentifier     not null,
   arpta01              nvarchar(10)         not null,
   arpta02              int                  not null,
   arpta03              nvarchar(3)          not null default '',
   arpta04              nvarchar(10)         not null default '',
   arpta05              nvarchar(3)          not null default '',
   arpta06              nvarchar(256)        not null default '',
   arpta07              datetime             not null default CONVERT(DATETIME,0),
   arpta08              nvarchar(40)         not null default '',
   arpta10              nvarchar(10)         not null default '',
   arpta11              nvarchar(1)          not null default '',
   arpta12              datetime             not null default CONVERT(DATETIME,0),
   arpta13              datetime             not null default CONVERT(DATETIME,0),
   arpta14a             nvarchar(3)          not null default '',
   arpta14b             nvarchar(256)        not null default '',
   arpta15              datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta01'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta02'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄公司;印表登錄公司',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta03'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄用戶;印表登錄用戶',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta04'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表軟體Portal;印表軟體Portal',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta05'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表Client ID;印表Client ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta06'
go

execute sp_addextendedproperty 'MS_Description', 
   '執行時間;執行時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta07'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式代號;印表格式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta08'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式版本號;印表格式版本號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta10'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表方式;印表方式',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta11'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始產生報表時間;開始產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta12'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成產生報表時間;完成產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta13'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態代碼;完成狀態代碼',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態描述;完成狀態描述',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排程創建時間;排程創建時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta15'
go

alter table dbo.arpt001
   add constraint PK_ARPT001 primary key (arpta01, arpta02)
      on "PRIMARY"
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.arig006') and o.name = 'FK_ARIG006_REFERENCE_ARIG001')
alter table dbo.arig006
   drop constraint FK_ARIG006_REFERENCE_ARIG001
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/3/16 AM 11:24:14                        */
/*==============================================================*/


alter table dbo.bbnk001
   drop constraint PK_BBNK001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bbnk001'))
drop table dbo.tmp_bbnk001
go

execute sp_rename bbnk001, tmp_bbnk001
go

/*==============================================================*/
/* Table: bbnk001                                               */
/*==============================================================*/
create table dbo.bbnk001 (
   recid                uniqueidentifier     not null,
   bbnka01              nvarchar(10)         not null,
   bbnka02              nvarchar(10)         not null default '',
   bbnka03              nvarchar(60)         not null default '',
   bbnka04              nvarchar(1)          not null default '',
   bbnka05              int                  not null default 0,
   bbnka06             nvarchar(10)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '銀行代號;銀行代號',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka01'
go

execute sp_addextendedproperty 'MS_Description', 
   '地區;地區',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka02'
go

execute sp_addextendedproperty 'MS_Description', 
   '銀行名稱;銀行名稱',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka03'
go

execute sp_addextendedproperty 'MS_Description', 
   '本埠否;本埠否',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka04'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據交換天數;票據交換天數',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka05'
go

execute sp_addextendedproperty 'MS_Description', 
   '行政區代碼;行政區代碼',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'bbnka06'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'bbnk001', 'column', 'modify_date'
go

insert into dbo.bbnk001 (recid, bbnka01, bbnka02, bbnka03, bbnka04, bbnka05, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, bbnka01, bbnka02, bbnka03, bbnka04, bbnka05, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_bbnk001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bbnk001'))
drop table dbo.tmp_bbnk001
go

alter table dbo.bbnk001
   add constraint PK_BBNK001 primary key (bbnka01)
      on "PRIMARY"
go


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom010') and o.name = 'FK_BCOM010_REFERENCE_BCOM001')
alter table dbo.bcom010
   drop constraint FK_BCOM010_REFERENCE_BCOM001
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.asys005') and o.name = 'FK_ASYS005_REFERENCE_BCOM001')
alter table dbo.asys005
   drop constraint FK_ASYS005_REFERENCE_BCOM001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.ntsk001'))
drop table dbo.ntsk001
go

/*==============================================================*/
/* Table: ntsk001                                               */
/*==============================================================*/
create table dbo.ntsk001 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   function_id          nvarchar(2)          not null default '',
   folder_id            int                  not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   ref_browse           int                  not null default 0,
   title                nvarchar(256)        not null default '',
   content              nvarchar(max)        not null default '',
   cont_format          int                  not null default 0,
   task_code            nvarchar(20)         not null default '',
   task_type            nvarchar(20)         not null default '',
   task_score           float                not null default 0,
   priority             int                  not null default 0,
   start_date           datetime             not null default CONVERT(DATETIME,0),
   due_date             datetime             not null default CONVERT(DATETIME,0),
   is_closed            int                  not null default 0,
   close_user           nvarchar(10)         not null default '',
   close_date           datetime             not null default CONVERT(DATETIME,0),
   can_pass             int                  not null default 0,
   visit_type           nvarchar(1)          not null default '',
   visit_no             nvarchar(10)         not null default '',
   attn_name            nvarchar(30)         not null default '',
   attn_title           nvarchar(20)         not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦工作資料ID;交辦工作資料ID',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'function_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾節點ID;資料夾節點ID',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'folder_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否允許關聯訪問擴充瀏覽者範圍;是否允許關聯訪問擴充瀏覽者範圍',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'ref_browse'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容;內容',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'content'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容格式;內容格式',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'cont_format'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作代號;工作代號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'task_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作類別;工作類別',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'task_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作點數;工作點數',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'task_score'
go

execute sp_addextendedproperty 'MS_Description', 
   '重要性;重要性',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'priority'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始日期;開始日期',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'start_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計完成日期;預計完成日期',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'due_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否結案;是否結案',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'is_closed'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案人用戶編號;結案人用戶編號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'close_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案日期;結案日期',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'close_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否允許交辦工作人員新增其他收件人;是否允許交辦工作人員新增其他收件人',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'can_pass'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象類別;拜訪對象類別',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'visit_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象編號;拜訪對象編號',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'visit_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象聯絡人名稱;拜訪對象聯絡人名稱',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'attn_name'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象聯絡人職稱;拜訪對象聯絡人職稱',
   'schema', 'dbo', 'table', 'ntsk001', 'column', 'attn_title'
go

alter table dbo.ntsk001
   add constraint PK_NTSK001 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk001_1                                         */
/*==============================================================*/
create unique index idx_ntsk001_1 on dbo.ntsk001 (
is_closed ASC,
doc_status ASC,
function_id ASC,
folder_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk001_2                                         */
/*==============================================================*/
create unique index idx_ntsk001_2 on dbo.ntsk001 (
function_id ASC,
folder_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk001_3                                         */
/*==============================================================*/
create unique index idx_ntsk001_3 on dbo.ntsk001 (
task_type ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk001_4                                         */
/*==============================================================*/
create unique index idx_ntsk001_4 on dbo.ntsk001 (
priority ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk001_5                                         */
/*==============================================================*/
create unique index idx_ntsk001_5 on dbo.ntsk001 (
visit_type ASC,
visit_no ASC,
pk_id ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.ntsk002'))
drop table dbo.ntsk002
go

/*==============================================================*/
/* Table: ntsk002                                               */
/*==============================================================*/
create table dbo.ntsk002 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   user_no              nvarchar(10)         not null,
   user_type            nvarchar(1)          not null default '',
   is_closed            int                  not null default 0,
   close_date           datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦工作資料ID;交辦工作資料ID',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦工作人員用戶編號;交辦工作人員用戶編號',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦工作人員類別;交辦工作人員類別',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'user_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '收件者是否結案;收件者是否結案',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'is_closed'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案日期;結案日期',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'close_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦人用戶編號;交辦人用戶編號',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦日期;交辦日期',
   'schema', 'dbo', 'table', 'ntsk002', 'column', 'create_date'
go

alter table dbo.ntsk002
   add constraint PK_NTSK002 primary key (pk_id, user_no)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_ntsk002_1                                         */
/*==============================================================*/
create unique index idx_ntsk002_1 on dbo.ntsk002 (
pk_id ASC,
user_type ASC,
user_no ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nmsg001'))
drop table dbo.nmsg001
go

/*==============================================================*/
/* Table: nmsg001                                               */
/*==============================================================*/
create table dbo.nmsg001 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   function_id          nvarchar(2)          not null default '',
   folder_id            int                  not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   ref_browse           int                  not null default 0,
   root_id              int                  not null default 0,
   parent_id            int                  not null default 0,
   title                nvarchar(256)        not null default '',
   content              nvarchar(max)        not null default '',
   cont_format          int                  not null default 0,
   link_url             nvarchar(256)        not null default '',
   msg_type             int                  not null default 0,
   send_type            int                  not null default 0,
   send_date            datetime             not null default CONVERT(DATETIME,0),
   send_to              nvarchar(10)         not null default '',
   is_clicked           int                  not null default 0,
   recip_del            int                  not null default 0,
   sender_del           int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '即時訊息ID;即時訊息ID',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'function_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾節點ID;資料夾節點ID',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'folder_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否允許關聯訪問擴充瀏覽者範圍;是否允許關聯訪問擴充瀏覽者範圍',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'ref_browse'
go

execute sp_addextendedproperty 'MS_Description', 
   '首發訊息ID;首發訊息ID',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'root_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '父階訊息ID;父階訊息ID',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'parent_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容;內容',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'content'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容格式;內容格式',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'cont_format'
go

execute sp_addextendedproperty 'MS_Description', 
   '網路連結網址;網路連結網址',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'link_url'
go

execute sp_addextendedproperty 'MS_Description', 
   '訊息類別;訊息類別',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'msg_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '發送類別;發送類別',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'send_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '發送時間;發送時間',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'send_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '收件者用戶編號;收件者用戶編號',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'send_to'
go

execute sp_addextendedproperty 'MS_Description', 
   '收件者是否已點閱;收件者是否已點閱',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'is_clicked'
go

execute sp_addextendedproperty 'MS_Description', 
   '收件者是否刪除;收件者是否刪除',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'recip_del'
go

execute sp_addextendedproperty 'MS_Description', 
   '寄件者是否刪除;寄件者是否刪除',
   'schema', 'dbo', 'table', 'nmsg001', 'column', 'sender_del'
go

alter table dbo.nmsg001
   add constraint PK_NMSG001 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_1                                         */
/*==============================================================*/
create unique index idx_nmsg001_1 on dbo.nmsg001 (
send_to ASC,
is_clicked ASC,
recip_del ASC,
send_date ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_2                                         */
/*==============================================================*/
create unique index idx_nmsg001_2 on dbo.nmsg001 (
parent_id ASC,
create_user ASC,
sender_del ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_3                                         */
/*==============================================================*/
create unique index idx_nmsg001_3 on dbo.nmsg001 (
parent_id ASC,
send_to ASC,
recip_del ASC,
send_date ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_4                                         */
/*==============================================================*/
create unique index idx_nmsg001_4 on dbo.nmsg001 (
root_id ASC,
parent_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_5                                         */
/*==============================================================*/
create unique index idx_nmsg001_5 on dbo.nmsg001 (
create_date ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nmsg001_6                                         */
/*==============================================================*/
create unique index idx_nmsg001_6 on dbo.nmsg001 (
is_clicked ASC,
pk_id ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nevt001'))
drop table dbo.nevt001
go

/*==============================================================*/
/* Table: nevt001                                               */
/*==============================================================*/
create table dbo.nevt001 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   function_id          nvarchar(2)          not null default '',
   folder_id            int                  not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   ref_browse           int                  not null default 0,
   root_id              int                  not null default 0,
   parent_id            int                  not null default 0,
   evt_type             nvarchar(20)         not null default '',
   evt_type2            nvarchar(20)         not null default '',
   title                nvarchar(256)        not null default '',
   content              nvarchar(max)        not null default '',
   cont_format          int                  not null default 0,
   priority             int                  not null default 0,
   is_closed            int                  not null default 0,
   close_user           nvarchar(10)         not null default '',
   close_date           datetime             not null default CONVERT(DATETIME,0),
   close_by_id          int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件資料ID;事件資料ID',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'function_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料夾節點ID;資料夾節點ID',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'folder_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否允許關聯訪問擴充瀏覽者範圍;是否允許關聯訪問擴充瀏覽者範圍',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'ref_browse'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件根節點ID;事件根節點ID',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'root_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件父節點ID;事件父節點ID',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'parent_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件類別;事件類別',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'evt_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件類別二;事件類別二',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'evt_type2'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容;內容',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'content'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容格式;內容格式',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'cont_format'
go

execute sp_addextendedproperty 'MS_Description', 
   '重要性;重要性',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'priority'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否結案;是否結案',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'is_closed'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案人用戶編號;結案人用戶編號',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'close_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案日期;結案日期',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'close_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '上層結案事件ID;上層結案事件ID',
   'schema', 'dbo', 'table', 'nevt001', 'column', 'close_by_id'
go

alter table dbo.nevt001
   add constraint PK_NEVT001 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt001_1                                         */
/*==============================================================*/
create unique index idx_nevt001_1 on dbo.nevt001 (
modify_date ASC,
function_id ASC,
folder_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt001_2                                         */
/*==============================================================*/
create unique index idx_nevt001_2 on dbo.nevt001 (
function_id ASC,
folder_id ASC,
parent_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt001_3                                         */
/*==============================================================*/
create unique index idx_nevt001_3 on dbo.nevt001 (
root_id ASC,
parent_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt001_4                                         */
/*==============================================================*/
create unique index idx_nevt001_4 on dbo.nevt001 (
is_closed ASC,
close_date ASC,
pk_id ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nevt002'))
drop table dbo.nevt002
go

/*==============================================================*/
/* Table: nevt002                                               */
/*==============================================================*/
create table dbo.nevt002 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   upper_id             int                  not null,
   path_order           int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nevt002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件資料ID;事件資料ID',
   'schema', 'dbo', 'table', 'nevt002', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件上層節點ID;事件上層節點ID',
   'schema', 'dbo', 'table', 'nevt002', 'column', 'upper_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '節點路徑順序;節點路徑順序',
   'schema', 'dbo', 'table', 'nevt002', 'column', 'path_order'
go

alter table dbo.nevt002
   add constraint PK_NEVT002 primary key (pk_id, upper_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt002_1                                         */
/*==============================================================*/
create unique index idx_nevt002_1 on dbo.nevt002 (
pk_id ASC,
path_order ASC,
upper_id ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nevt003'))
drop table dbo.nevt003
go

/*==============================================================*/
/* Table: nevt003                                               */
/*==============================================================*/
create table dbo.nevt003 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   user_no              nvarchar(10)         not null,
   user_type            nvarchar(1)          not null default '',
   is_closed            int                  not null default 0,
   close_date           datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件資料ID;事件資料ID',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件人員用戶編號;事件人員用戶編號',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件人員類別;事件人員類別',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'user_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '收件者是否結案;收件者是否結案',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'is_closed'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案日期;結案日期',
   'schema', 'dbo', 'table', 'nevt003', 'column', 'close_date'
go

alter table dbo.nevt003
   add constraint PK_NEVT003 primary key (pk_id, user_no)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nevt003_1                                         */
/*==============================================================*/
create unique index idx_nevt003_1 on dbo.nevt003 (
pk_id ASC,
user_type ASC,
user_no ASC
)
on "PRIMARY"
go

declare @sql varchar(200)
set @sql = 'alter table dquo001 drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dquo001') and c.name = 'dquoa22a'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dquo001
   drop column dquoa22a
go
declare @sql varchar(200)
set @sql = 'alter table dquo001 drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dquo001') and c.name = 'dquoa22b'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dquo001
   drop column dquoa22b
go
declare @sql varchar(200)
set @sql = 'alter table dquo001 drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('dquo001') and c.name = 'dquoa22c'  and c.cdefault = o.id)
exec(@sql)

alter table dbo.dquo001
   drop column dquoa22c
go

SELECT * INTO tmp_bite009 FROM dbo.bite009
GO
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.bite009'))
drop table dbo.bite009
go

/*==============================================================*/
/* Table: bite009                                               */
/*==============================================================*/
create table dbo.bite009 (
   recid                uniqueidentifier     not null,
   bitei01              nvarchar(20)         not null,
   bitei02              nvarchar(6)          not null,
   bitei03              numeric(10,3)        not null default 0,
   bitei04              numeric(10,3)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'bite009', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換組別;單位轉換組別',
   'schema', 'dbo', 'table', 'bite009', 'column', 'bitei01'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位;單位',
   'schema', 'dbo', 'table', 'bite009', 'column', 'bitei02'
go

execute sp_addextendedproperty 'MS_Description', 
   '對應基本單位的轉換率-分子;對應基本單位的轉換率-分子',
   'schema', 'dbo', 'table', 'bite009', 'column', 'bitei03'
go

execute sp_addextendedproperty 'MS_Description', 
   '對應基本單位的轉換率-分母;對應基本單位的轉換率-分母',
   'schema', 'dbo', 'table', 'bite009', 'column', 'bitei04'
go

alter table dbo.bite009
   add constraint PK_BITE009 primary key (bitei01, bitei02)
      on "PRIMARY"
go

INSERT dbo.bite009
SELECT * FROM tmp_bite009
GO
DROP TABLE tmp_bite009
GO

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/4/6 PM 02:44:53                         */
/*==============================================================*/
alter table dbo.ldoc014
   drop constraint PK_LDOC014
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_ldoc014'))
drop table dbo.tmp_ldoc014
go

execute sp_rename ldoc014, tmp_ldoc014
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('dbo.nevt003')
            and   name  = 'idx_nevt003_1'
            and   indid > 0
            and   indid < 255)
   drop index dbo.nevt003.idx_nevt003_1
go

alter table dbo.nevt003
   drop constraint PK_NEVT003
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('dbo.ntsk002')
            and   name  = 'idx_ntsk002_1'
            and   indid > 0
            and   indid < 255)
   drop index dbo.ntsk002.idx_ntsk002_1
go

alter table dbo.ntsk002
   drop constraint PK_NTSK002
go

use NewErp
go

/*==============================================================*/
/* Table: ldoc014                                               */
/*==============================================================*/
create table dbo.ldoc014 (
   recid                uniqueidentifier     not null,
   ldocn01a             nvarchar(2)          not null,
   ldocn01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   doc_staff            nvarchar(10)         not null default '',
   ldocn02a             nvarchar(2)          not null default '',
   ldocn02b             nvarchar(16)         not null default '',
   ldocn03              nvarchar(80)         not null default '',
   ldocn04              varbinary(max)       null,
   ldocn05              varbinary(max)       null,
   ldocn06              varbinary(max)       null,
   ldocn07              datetime             not null default CONVERT(DATETIME,0),
   ldocn08              nvarchar(10)         not null default '',
   ldocn09              nvarchar(5)          not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更單別;變更單別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更單號;變更單號',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更日期;變更日期',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更業務員;變更業務員',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '原始單別;原始單別',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原始單號;原始單號',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更原因;變更原因',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn03'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更前內容;變更前內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更後內容;變更後內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn05'
go

execute sp_addextendedproperty 'MS_Description', 
   '變更內容;變更內容',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'ldocn06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_date'
go
alter table dbo.ldoc014
   add constraint PK_LDOC014 primary key (ldocn01a, ldocn01b)
      on "PRIMARY"
GO

insert into dbo.ldoc014 (recid, ldocn01a, ldocn01b, doc_comp, doc_date, doc_staff, ldocn02a, ldocn02b, ldocn03, ldocn04, ldocn05, ldocn06, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date)
select recid, ldocn01a, ldocn01b, doc_comp, doc_date, doc_staff, ldocn02a, ldocn02b, ldocn03, ldocn04, ldocn05, ldocn06, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date
from dbo.tmp_ldoc014
go

alter table dbo.nevt003
   add constraint PK_NEVT003 primary key (pk_id, user_type, user_no)
      on "PRIMARY"
go

alter table dbo.ntsk002
   add constraint PK_NTSK002 primary key (pk_id, user_type, user_no)
      on "PRIMARY"
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdinv012'))
drop table dbo.chgdinv012
go

/*==============================================================*/
/* Table: chgdinv012                                            */
/*==============================================================*/
create table dbo.chgdinv012 (
   recid                uniqueidentifier     not null,
   dinvl01a             nvarchar(2)          not null,
   dinvl01b             nvarchar(16)         not null,
   dinvl02              int                  not null,
   dinvl03              nvarchar(10)         not null default '',
   dinvl04              nvarchar(3)          not null default '',
   dinvl05              nvarchar(10)         not null default '',
   dinvl06              nvarchar(5)          not null default '',
   dinvl06a             numeric(9,5)         not null default 0,
   dinvl07              nvarchar(1)          not null default '',
   dinvl08              nvarchar(1)          not null default '',
   dinvl12a             nvarchar(2)          not null default '',
   dinvl12b             nvarchar(16)         not null default '',
   dinvl13              nvarchar(2)          not null default '',
   dinvl16a             nvarchar(2)          not null default '',
   dinvl16b             nvarchar(16)         not null default '',
   dinvl17              nvarchar(2)          not null default '',
   dinvl18              nvarchar(1)          not null default '',
   dinvl19              nvarchar(1)          not null default '',
   dinvl35              int                  not null default 0,
   inv_biz_no           nvarchar(10)         not null default '',
   inv_doc_staff        nvarchar(10)         not null default '',
   inv_staff_group      nvarchar(10)         not null default '',
   dinva04a             nvarchar(20)         not null default '',
   dinva26              nvarchar(6)          not null default '',
   dinva26a             nvarchar(30)         not null default '',
   dinva26b             nvarchar(20)         not null default '',
   dinva26c             nvarchar(20)         not null default '',
   dinva26d             nvarchar(20)         not null default '',
   dinva26e             nvarchar(40)         not null default '',
   dinva13b             nvarchar(10)         not null default '',
   dinva14b             nvarchar(10)         not null default '',
   dinva15b             nvarchar(10)         not null default '',
   dinva16b             nvarchar(10)         not null default '',
   dinva17b             nvarchar(10)         not null default '',
   dinva18b             nvarchar(10)         not null default '',
   dinva15c             nvarchar(1)          not null default '',
   dinva15d             nvarchar(10)         not null default '',
   dinva15e             nvarchar(6)          not null default '',
   dinva15f             nvarchar(80)         not null default '',
   dinva86              nvarchar(4)          not null default '',
   dinvl39              int                  not null default 0,
   pu_biz_no            nvarchar(10)         not null default '',
   pu_doc_staff         nvarchar(10)         not null default '',
   pu_staff_group       nvarchar(10)         not null default '',
   pu_dinva04a          nvarchar(20)         not null default '',
   pu_dinva26           nvarchar(6)          not null default '',
   pu_dinva26a          nvarchar(30)         not null default '',
   pu_dinva26b          nvarchar(20)         not null default '',
   pu_dinva26c          nvarchar(20)         not null default '',
   pu_dinva26d          nvarchar(20)         not null default '',
   pu_dinva26e          nvarchar(40)         not null default '',
   pu_dinva86           nvarchar(4)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉階序;拋轉階序',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl02'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單廠商編號;轉單廠商編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl03'
go

execute sp_addextendedproperty 'MS_Description', 
   '對應公司別;對應公司別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl04'
go

execute sp_addextendedproperty 'MS_Description', 
   '負責業務;負責業務',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl05'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl06'
go

execute sp_addextendedproperty 'MS_Description', 
   '匯率換算-首階訂單幣別;匯率換算-首階訂單幣別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合併佣金;合併佣金',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl07'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金訂單;佣金訂單',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl08'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨單別;銷貨單別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl12a'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨單號;銷貨單號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl12b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨類別;銷貨類別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl13'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨單別;進貨單別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨單號;進貨單號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨類別;進貨類別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl17'
go

execute sp_addextendedproperty 'MS_Description', 
   '產生庫存帳;產生庫存帳',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl18'
go

execute sp_addextendedproperty 'MS_Description', 
   '產生Packing;產生Packing',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl19'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨對方單號取法;銷貨對方單號取法',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl35'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨客戶編號;銷貨客戶編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'inv_biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨負責業務;銷貨負責業務',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'inv_doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨部門別;銷貨部門別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'inv_staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '對方單號;對方單號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨聯絡人代號;銷貨聯絡人代號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象_1;聯絡對象_1',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一_1;聯絡電話一_1',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二_2;聯絡電話二_2',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真_1;聯絡傳真_1',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email_1;聯絡email_1',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva26e'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨報關行;銷貨報關行',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨收款客戶編號;銷貨收款客戶編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨交貨對象編號;銷貨交貨對象編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨Agent;銷貨Agent',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨Consignee;銷貨Consignee',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨A/Notify;銷貨A/Notify',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨交貨地點對象別;銷貨交貨地點對象別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva15c'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨交貨地點對象編號;銷貨交貨地點對象編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva15d'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨交貨地點序號;銷貨交貨地點序號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva15e'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨交貨地點描述;銷貨交貨地點描述',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva15f'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨預設銷貨倉庫編號;銷貨預設銷貨倉庫編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinva86'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨對方單號取法;進貨對方單號取法',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'dinvl39'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨廠商編號;進貨廠商編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨負責業務;進貨負責業務',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨部門別;進貨部門別',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨對方單號;進貨對方單號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨聯絡人代號;進貨聯絡人代號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象_2;聯絡對象_2',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一_3;聯絡電話一_3',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二_4;聯絡電話二_4',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真_2;聯絡傳真_2',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email_2;聯絡email_2',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva26e'
go

execute sp_addextendedproperty 'MS_Description', 
   '進貨預設進貨倉庫編號;進貨預設進貨倉庫編號',
   'schema', 'dbo', 'table', 'chgdinv012', 'column', 'pu_dinva86'
go

alter table dbo.chgdinv012
   add constraint PK_CHGDINV012 primary key (dinvl01a, dinvl01b, dinvl02)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdinv013'))
drop table dbo.chgdinv013
go

/*==============================================================*/
/* Table: chgdinv013                                            */
/*==============================================================*/
create table dbo.chgdinv013 (
   recid                uniqueidentifier     not null,
   dinvmid              uniqueidentifier     not null,
   dinvm01a             nvarchar(2)          not null default '',
   dinvm01b             nvarchar(16)         not null default '',
   dinvm02a             nvarchar(2)          not null default '',
   dinvm02b             nvarchar(16)         not null default '',
   dinvm03a             nvarchar(2)          not null default '',
   dinvm03b             nvarchar(16)         not null default '',
   num                  float                not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   dinvm04              nvarchar(10)         not null default '',
   dinvm05              numeric(19,5)        not null default 0,
   dinvm06              nvarchar(1)          not null default '',
   dinvm08              nvarchar(5)          not null default '',
   dinvm09              numeric(19,5)        not null default 0,
   dinvm10              numeric(19,5)        not null default 0,
   dinvm11              numeric(19,5)        not null default 0,
   dinvm12              numeric(19,5)        not null default 0,
   dinvm13              numeric(19,5)        not null default 0,
   dinvm14              numeric(19,5)        not null default 0,
   dinvm15              numeric(19,5)        not null default 0,
   dinvm16              numeric(19,5)        not null default 0,
   dinvm17              numeric(19,5)        not null default 0,
   dinvm18              numeric(19,5)        not null default 0,
   dinvm19              numeric(19,5)        not null default 0,
   dinvm30              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvmid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別一;單別一',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號一;單號一',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單別;首階訂單單別',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單號;首階訂單單號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm04'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量(計價單位);數量(計價單位)',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm05'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷貨變更標記;銷貨變更標記',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm06'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階幣別;首階幣別',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm08'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單價;首階單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm09'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x單價;轉對象1x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm10'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x單價;轉對象2x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm11'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x單價;轉對象3x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm12'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x單價;轉對象4x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm13'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x單價;轉對象5x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm14'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x單價;轉對象6x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm15'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x單價;轉對象7x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm16'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x單價;轉對象8x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm17'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x單價;轉對象9x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm18'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x單價;轉對象10x單價',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm19'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差;總價差',
   'schema', 'dbo', 'table', 'chgdinv013', 'column', 'dinvm30'
go

alter table dbo.chgdinv013
   add constraint PK_CHGDINV013 primary key nonclustered (dinvmid)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv013_1                                         */
/*==============================================================*/
create unique clustered index idx_dinv013_1 on dbo.chgdinv013 (
dinvm01a ASC,
dinvm01b ASC,
dinvm02a ASC,
dinvm02b ASC,
item_no ASC,
item_sub ASC,
dinvm04 ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdinv014'))
drop table dbo.chgdinv014
go

/*==============================================================*/
/* Table: chgdinv014                                            */
/*==============================================================*/
create table dbo.chgdinv014 (
   recid                uniqueidentifier     not null,
   dinvn01a             nvarchar(2)          not null,
   dinvn01b             nvarchar(16)         not null,
   dinvn02a             nvarchar(2)          not null,
   dinvn02b             nvarchar(16)         not null,
   dinvn03              uniqueidentifier     not null,
   dinvn04              uniqueidentifier     not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   dinvn05a             nvarchar(2)          not null default '',
   dinvn05b             nvarchar(16)         not null default '',
   dinvn06              nvarchar(1)          not null default '',
   dinvn07              nvarchar(40)         not null default '',
   dinvn08              nvarchar(5)          not null default '',
   dinvn09a             numeric(19,5)        not null default 0,
   dinvn09b             numeric(19,5)        not null default 0,
   dinvn10a             numeric(19,5)        not null default 0,
   dinvn10b             numeric(19,5)        not null default 0,
   dinvn11a             numeric(19,5)        not null default 0,
   dinvn11b             numeric(19,5)        not null default 0,
   dinvn12a             numeric(19,5)        not null default 0,
   dinvn12b             numeric(19,5)        not null default 0,
   dinvn13a             numeric(19,5)        not null default 0,
   dinvn13b             numeric(19,5)        not null default 0,
   dinvn14a             numeric(19,5)        not null default 0,
   dinvn14b             numeric(19,5)        not null default 0,
   dinvn15a             numeric(19,5)        not null default 0,
   dinvn15b             numeric(19,5)        not null default 0,
   dinvn16a             numeric(19,5)        not null default 0,
   dinvn16b             numeric(19,5)        not null default 0,
   dinvn17a             numeric(19,5)        not null default 0,
   dinvn17b             numeric(19,5)        not null default 0,
   dinvn18a             numeric(19,5)        not null default 0,
   dinvn18b             numeric(19,5)        not null default 0,
   dinvn19a             numeric(19,5)        not null default 0,
   dinvn19b             numeric(19,5)        not null default 0,
   dinvn30a             numeric(19,5)        not null default 0,
   dinvn30b             numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別一;單別一',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號一;單號一',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn03'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階加扣款ID;首階加扣款ID',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單別;首階訂單單別',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單單號;首階訂單單號',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn06'
go

execute sp_addextendedproperty 'MS_Description', 
   '項目描述;項目描述',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn07'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單幣別;首階訂單幣別',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn08'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款未稅金額;首階訂單加扣款未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn09a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款含稅金額;首階訂單加扣款含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn09b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x未稅金額;轉對象1x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x含稅金額;轉對象1x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x未稅金額;轉對象2x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x含稅金額;轉對象2x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn11b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x未稅金額;轉對象3x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn12a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x含稅金額;轉對象3x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn12b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x未稅金額;轉對象4x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x含稅金額;轉對象4x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x未稅金額;轉對象5x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x含稅金額;轉對象5x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x未稅金額;轉對象6x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x含稅金額;轉對象6x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x未稅金額;轉對象7x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x含稅金額;轉對象7x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x未稅金額;轉對象8x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn17a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x含稅金額;轉對象8x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x未稅金額;轉對象9x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn18a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x含稅金額;轉對象9x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x未稅金額;轉對象10x未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x含稅金額;轉對象10x含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差未稅金額;總價差未稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差含稅金額;總價差含稅金額',
   'schema', 'dbo', 'table', 'chgdinv014', 'column', 'dinvn30b'
go

alter table dbo.chgdinv014
   add constraint PK_CHGDINV014 primary key (dinvn01a, dinvn01b, dinvn02a, dinvn02b, dinvn03)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv014_1                                         */
/*==============================================================*/
create index idx_dinv014_1 on dbo.chgdinv014 (
dinvn03 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dinv014_2                                         */
/*==============================================================*/
create index idx_dinv014_2 on dbo.chgdinv014 (
dinvn04 ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chglbas006'))
drop table dbo.chglbas006
go

/*==============================================================*/
/* Table: chglbas006                                            */
/*==============================================================*/
create table dbo.chglbas006 (
   recid                uniqueidentifier     not null,
   lbasf01a             nvarchar(2)          not null,
   lbasf01b             nvarchar(16)         not null,
   lbasf02              nvarchar(5)          not null,
   comp_curr            nvarchar(5)          not null default '',
   lbasf03              numeric(9,5)         not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'lbasf01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'lbasf01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算幣別;換算幣別',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'lbasf02'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司幣別;公司幣別',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'comp_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '匯率;匯率',
   'schema', 'dbo', 'table', 'chglbas006', 'column', 'lbasf03'
go

alter table dbo.chglbas006
   add constraint PK_CHGLBAS006 primary key (lbasf01a, lbasf01b, lbasf02)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdord012'))
drop table dbo.chgdord012
go

/*==============================================================*/
/* Table: chgdord012                                            */
/*==============================================================*/
create table dbo.chgdord012 (
   recid                uniqueidentifier     not null,
   dordl01a             nvarchar(2)          not null,
   dordl01b             nvarchar(16)         not null,
   dordl02              int                  not null,
   dordl03              nvarchar(10)         not null default '',
   dordl04              nvarchar(3)          not null default '',
   dordl05              nvarchar(10)         not null default '',
   dordl06              nvarchar(5)          not null default '',
   dordl06a             numeric(9,5)         not null default 0,
   dordl07              nvarchar(1)          not null default '',
   dordl08              nvarchar(1)          not null default '',
   dordl09a             nvarchar(2)          not null default '',
   dordl09b             nvarchar(16)         not null default '',
   dordl10              nvarchar(2)          not null default '',
   dordl11              numeric(9,5)         not null default 0,
   dordl14a             nvarchar(2)          not null default '',
   dordl14b             nvarchar(16)         not null default '',
   dordl15              nvarchar(2)          not null default '',
   dordl31              int                  not null default 0,
   dordl32              nvarchar(1)          not null default '',
   dordl33              int                  not null default 0,
   sc_biz_no            nvarchar(10)         not null default '',
   sc_doc_staff         nvarchar(10)         not null default '',
   sc_staff_group       nvarchar(10)         not null default '',
   sc_tax_type          nvarchar(1)          not null default '',
   sc_tax_rate          numeric(9,5)         not null default 0,
   dordb20b             numeric(9,5)         not null default 0,
   dorda06              nvarchar(6)          not null default '',
   dorda06a             nvarchar(30)         not null default '',
   dorda06b             nvarchar(20)         not null default '',
   dorda06c             nvarchar(20)         not null default '',
   dorda06d             nvarchar(20)         not null default '',
   dorda06e             nvarchar(40)         not null default '',
   dorda07              nvarchar(20)         not null default '',
   dorda08a             nvarchar(20)         not null default '',
   dorda08b             nvarchar(20)         not null default '',
   dorda08c             nvarchar(20)         not null default '',
   dorda13a             nvarchar(6)          not null default '',
   dorda13b             nvarchar(80)         not null default '',
   dorda13c             int                  not null default 0,
   dorda13d             numeric(9,5)         not null default 0,
   dorda13e             int                  not null default 0,
   dorda13f             numeric(9,5)         not null default 0,
   dorda14              nvarchar(80)         not null default '',
   dorda15              nvarchar(2)          not null default '',
   dorda16b             nvarchar(10)         not null default '',
   dorda17b             nvarchar(10)         not null default '',
   dorda18b             nvarchar(10)         not null default '',
   dorda20b             nvarchar(10)         not null default '',
   dorda25a             nvarchar(7)          not null default '',
   dorda25b             nvarchar(27)         not null default '',
   dorda27              numeric(9,5)         not null default 0,
   dordl37              int                  not null default 0,
   po_biz_no            nvarchar(10)         not null default '',
   po_doc_staff         nvarchar(10)         not null default '',
   po_staff_group       nvarchar(10)         not null default '',
   epura06              nvarchar(6)          not null default '',
   epura06a             nvarchar(30)         not null default '',
   epura06b             nvarchar(20)         not null default '',
   epura06c             nvarchar(20)         not null default '',
   epura06d             nvarchar(20)         not null default '',
   epura06e             nvarchar(40)         not null default '',
   epura07              nvarchar(20)         not null default '',
   epura20a             nvarchar(1)          not null default '',
   epura20b             nvarchar(10)         not null default '',
   epura20c             nvarchar(6)          not null default '',
   epura20e             nvarchar(80)         not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉階序;拋轉階序',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl02'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單廠商編號;轉單廠商編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl03'
go

execute sp_addextendedproperty 'MS_Description', 
   '對應公司別;對應公司別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl04'
go

execute sp_addextendedproperty 'MS_Description', 
   '負責業務;負責業務',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl05'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl06'
go

execute sp_addextendedproperty 'MS_Description', 
   '匯率換算-首階訂單幣別;匯率換算-首階訂單幣別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合併佣金;合併佣金',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl07'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金訂單;佣金訂單',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl08'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單別;訂單單別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl09a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單號;訂單單號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl09b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單類別;訂單類別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl10'
go

execute sp_addextendedproperty 'MS_Description', 
   '預設價格%;預設價格%',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl11'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購單別;採購單別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購單號;採購單號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購類別;採購類別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl15'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單對方單號取法;訂單對方單號取法',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl31'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單訂金付款項同首階訂單;訂單訂金付款項同首階訂單',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl32'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單產品排程較首階訂單交期提前天數;訂單產品排程較首階訂單交期提前天數',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl33'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單客戶編號;訂單客戶編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'sc_biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單負責業務;訂單負責業務',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'sc_doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單部門別;訂單部門別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'sc_staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單稅別;訂單稅別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'sc_tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單稅率;訂單稅率',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'sc_tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單出口退稅率;訂單出口退稅率',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordb20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單聯絡人代號;訂單聯絡人代號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單聯絡人姓名;訂單聯絡人姓名',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一_1;聯絡電話一_1',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二_1;聯絡電話二_1',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真_1;聯絡傳真_1',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email_1;聯絡email_1',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda06e'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶訂單;客戶訂單',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda07'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Shipment From;訂單Shipment From',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda08a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Shipment To;訂單Shipment To',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda08b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Shipment Via;訂單Shipment Via',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda08c'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Payment Code;訂單Payment Code',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Payment Desc;訂單Payment Desc',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單現金扣%: (1)幾天內;訂單現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13c'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單現金扣%: (1)扣幾%;訂單現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13d'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單現金扣%: (2)幾天內;訂單現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13e'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單現金扣%: (2)扣幾%;訂單現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda13f'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Shipment desc.;訂單Shipment desc.',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda14'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單嘜頭編號;訂單嘜頭編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda15'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Agent;訂單Agent',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Consignee;訂單Consignee',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單A/Notify;訂單A/Notify',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單交貨對象編號;訂單交貨對象編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Price Term Code;訂單Price Term Code',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda25a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Price Term Desc.;訂單Price Term Desc.',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda25b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單Undervalue%;訂單Undervalue%',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dorda27'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購對方單號取法;採購對方單號取法',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'dordl37'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購廠商編號;採購廠商編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'po_biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購負責業務;採購負責業務',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'po_doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購部門別;採購部門別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'po_staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購聯絡人代號;採購聯絡人代號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一_3;聯絡電話一_3',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二_4;聯絡電話二_4',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真_2;聯絡傳真_2',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email_2;聯絡email_2',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura06e'
go

execute sp_addextendedproperty 'MS_Description', 
   '對方單號;對方單號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura07'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購交貨地點對象別;採購交貨地點對象別',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura20a'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購交貨地點對象編號;採購交貨地點對象編號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購交貨地點序號;採購交貨地點序號',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura20c'
go

execute sp_addextendedproperty 'MS_Description', 
   '採購交貨地點描述;採購交貨地點描述',
   'schema', 'dbo', 'table', 'chgdord012', 'column', 'epura20e'
go

alter table dbo.chgdord012
   add constraint PK_CHGDORD012 primary key (dordl01a, dordl01b, dordl02)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdord013'))
drop table dbo.chgdord013
go

/*==============================================================*/
/* Table: chgdord013                                            */
/*==============================================================*/
create table dbo.chgdord013 (
   recid                uniqueidentifier     not null,
   dordmid              uniqueidentifier     not null,
   dordm01a             nvarchar(2)          not null default '',
   dordm01b             nvarchar(16)         not null default '',
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   dordm04              nvarchar(10)         not null default '',
   num                  float                not null default 0,
   dordm05              nvarchar(1)          not null default '',
   dordm06a             nvarchar(1)          not null default '',
   dordm06b             nvarchar(1)          not null default '',
   dordm07              numeric(19,5)        not null default 0,
   dordm08              nvarchar(6)          not null default '',
   dordm08a             numeric(19,5)        not null default 0,
   dordm08b             numeric(19,5)        not null default 0,
   dordm09              numeric(19,5)        not null default 0,
   dordm10              numeric(19,5)        not null default 0,
   dordm11              numeric(19,5)        not null default 0,
   dordm12              numeric(19,5)        not null default 0,
   dordm13              numeric(19,5)        not null default 0,
   dordm14              numeric(19,5)        not null default 0,
   dordm15              numeric(19,5)        not null default 0,
   dordm16              numeric(19,5)        not null default 0,
   dordm17              numeric(19,5)        not null default 0,
   dordm18              numeric(19,5)        not null default 0,
   dordm19              numeric(19,5)        not null default 0,
   dordm30              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordmid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm05'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單變更標記;轉單變更標記',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm07'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm08'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm08a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm08b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單價;首階單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm09'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x單價;轉對象1x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm10'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x單價;轉對象2x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm11'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x單價;轉對象3x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm12'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x單價;轉對象4x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm13'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x單價;轉對象5x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm14'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x單價;轉對象6x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm15'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x單價;轉對象7x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm16'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x單價;轉對象8x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm17'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x單價;轉對象9x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm18'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x單價;轉對象10x單價',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm19'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差;總價差',
   'schema', 'dbo', 'table', 'chgdord013', 'column', 'dordm30'
go

alter table dbo.chgdord013
   add constraint PK_CHGDORD013 primary key nonclustered (dordmid)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dord013_1                                         */
/*==============================================================*/
create clustered index idx_dord013_1 on dbo.chgdord013 (
dordm01a ASC,
dordm01b ASC,
item_no ASC,
item_sub ASC,
dordm04 ASC
)
on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.chgdord014'))
drop table dbo.chgdord014
go

/*==============================================================*/
/* Table: chgdord014                                            */
/*==============================================================*/
create table dbo.chgdord014 (
   recid                uniqueidentifier     not null,
   dordn01a             nvarchar(2)          not null,
   dordn01b             nvarchar(16)         not null,
   dordn02              uniqueidentifier     not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   dordn03a             nvarchar(1)          not null default '',
   dordn03b             nvarchar(1)          not null default '',
   dordn04              nvarchar(40)         not null default '',
   dordn05a             numeric(19,5)        not null default 0,
   dordn05b             numeric(19,5)        not null default 0,
   dordn10a             numeric(19,5)        not null default 0,
   dordn10b             numeric(19,5)        not null default 0,
   dordn11a             numeric(19,5)        not null default 0,
   dordn11b             numeric(19,5)        not null default 0,
   dordn12a             numeric(19,5)        not null default 0,
   dordn12b             numeric(19,5)        not null default 0,
   dordn13a             numeric(19,5)        not null default 0,
   dordn13b             numeric(19,5)        not null default 0,
   dordn14a             numeric(19,5)        not null default 0,
   dordn14b             numeric(19,5)        not null default 0,
   dordn15a             numeric(19,5)        not null default 0,
   dordn15b             numeric(19,5)        not null default 0,
   dordn16a             numeric(19,5)        not null default 0,
   dordn16b             numeric(19,5)        not null default 0,
   dordn17a             numeric(19,5)        not null default 0,
   dordn17b             numeric(19,5)        not null default 0,
   dordn18a             numeric(19,5)        not null default 0,
   dordn18b             numeric(19,5)        not null default 0,
   dordn19a             numeric(19,5)        not null default 0,
   dordn19b             numeric(19,5)        not null default 0,
   dordn30a             numeric(19,5)        not null default 0,
   dordn30b             numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn02'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單變更標記;訂單變更標記',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉單變更標記;轉單變更標記',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '項目描述;項目描述',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn04'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款未稅金額;首階訂單加扣款未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階訂單加扣款含稅金額;首階訂單加扣款含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x未稅金額;轉對象1x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象1x含稅金額;轉對象1x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x未稅金額;轉對象2x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象2x含稅金額;轉對象2x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn11b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x未稅金額;轉對象3x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn12a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象3x含稅金額;轉對象3x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn12b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x未稅金額;轉對象4x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象4x含稅金額;轉對象4x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x未稅金額;轉對象5x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象5x含稅金額;轉對象5x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x未稅金額;轉對象6x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象6x含稅金額;轉對象6x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x未稅金額;轉對象7x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象7x含稅金額;轉對象7x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x未稅金額;轉對象8x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn17a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象8x含稅金額;轉對象8x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn17b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x未稅金額;轉對象9x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn18a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象9x含稅金額;轉對象9x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn18b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x未稅金額;轉對象10x未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉對象10x含稅金額;轉對象10x含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差未稅金額;總價差未稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '總價差含稅金額;總價差含稅金額',
   'schema', 'dbo', 'table', 'chgdord014', 'column', 'dordn30b'
go

alter table dbo.chgdord014
   add constraint PK_CHGDORD014 primary key (dordn01a, dordn01b, dordn02)
      on "PRIMARY"
go

alter table dbo.arpt001
   add arpta16 varbinary(max) null
go

execute sp_addextendedproperty 'MS_Description', 
   '進階選中記錄;進階選中記錄',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta16'
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/4/16 PM 02:21:04                        */
/*==============================================================*/


alter table dbo.ldoc014
   add doc_status1 nvarchar(1) not null default ''
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'doc_status1'
go

alter table dbo.ldoc014
   add last_user1 nvarchar(10) not null default ''
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_user1'
go

alter table dbo.ldoc014
   add last_date1 datetime not null default CONVERT(DATETIME,0)
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ldoc014', 'column', 'last_date1'
go


ALTER TABLE bitm001 ALTER COLUMN bitma19 nvarchar(20) not null
GO

ALTER TABLE arpt001 ADD arpta17 INT NOT NULL DEFAULT 0;
GO
execute sp_addextendedproperty 'MS_Description', 
   '排程印表結果文件ID;排程印表結果文件ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta17'
GO

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/4/27 AM 09:44:17                        */
/*==============================================================*/


alter table dbo.arpt001
   drop constraint PK_ARPT001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt001'))
drop table dbo.tmp_arpt001
go

execute sp_rename arpt001, tmp_arpt001
go

/*==============================================================*/
/* Table: arpt001                                               */
/*==============================================================*/
create table dbo.arpt001 (
   recid                uniqueidentifier     not null,
   arpta01              nvarchar(10)         not null,
   arpta02              int                  identity,
   arpta03              nvarchar(3)          not null default '',
   arpta04              nvarchar(10)         not null default '',
   arpta05              nvarchar(3)          not null default '',
   arpta06              nvarchar(256)        not null default '',
   arpta07              datetime             not null default CONVERT(DATETIME,0),
   arpta08              nvarchar(40)         not null default '',
   arpta10              nvarchar(10)         not null default '',
   arpta11              nvarchar(1)          not null default '',
   arpta12              datetime             not null default CONVERT(DATETIME,0),
   arpta13              datetime             not null default CONVERT(DATETIME,0),
   arpta14a             nvarchar(3)          not null default '',
   arpta14b             nvarchar(256)        not null default '',
   arpta15              datetime             not null default CONVERT(DATETIME,0),
   arpta16              varbinary(max)       null,
   arpta17              int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta01'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta02'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄公司;印表登錄公司',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta03'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄用戶;印表登錄用戶',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta04'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表軟體Portal;印表軟體Portal',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta05'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表Client ID;印表Client ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta06'
go

execute sp_addextendedproperty 'MS_Description', 
   '執行時間;執行時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta07'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式代號;印表格式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta08'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式版本號;印表格式版本號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta10'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表方式;印表方式',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta11'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始產生報表時間;開始產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta12'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成產生報表時間;完成產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta13'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態代碼;完成狀態代碼',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態描述;完成狀態描述',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排程創建時間;排程創建時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta15'
go

execute sp_addextendedproperty 'MS_Description', 
   '進階選中記錄;進階選中記錄',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta16'
go

execute sp_addextendedproperty 'MS_Description', 
   '排程印表結果文件ID;排程印表結果文件ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta17'
go

set identity_insert dbo.arpt001 on
go

insert into dbo.arpt001 (recid, arpta01, arpta02, arpta03, arpta04, arpta05, arpta06, arpta07, arpta08, arpta10, arpta11, arpta12, arpta13, arpta14a, arpta14b, arpta15, arpta16, arpta17)
select recid, arpta01, arpta02, arpta03, arpta04, arpta05, arpta06, arpta07, arpta08, arpta10, arpta11, arpta12, arpta13, arpta14a, arpta14b, arpta15, arpta16, arpta17
from dbo.tmp_arpt001
go

set identity_insert dbo.arpt001 off
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt001'))
drop table dbo.tmp_arpt001
go

alter table dbo.arpt001
   add constraint PK_ARPT001 primary key (arpta01, arpta02)
      on "PRIMARY"
go

/*
主從關系資料的刪除，通過在需要級聯刪除的表上綁定觸發器實現。
*/
IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = object_id(N'dbo.td_arpt001'))
   DROP TRIGGER dbo.td_arpt001
GO
CREATE TRIGGER dbo.td_arpt001 ON arpt001 
FOR DELETE
AS
BEGIN
	--報表執行記錄明細檔
	DELETE arpt002 
	FROM deleted AS d
	WHERE arpt002.arptb01 = d.arpta01 AND arpt002.arptb02 = d.arpta02;
	
	--報表排程通知
	DELETE arpt004 
	FROM deleted AS d
	WHERE arpt004.arptd01 = d.arpta01 AND arpt004.arptd02 = d.arpta02;
END
GO

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom011') and o.name = 'FK_BCOM011_REFERENCE_BCOM001')
alter table dbo.bcom011
   drop constraint FK_BCOM011_REFERENCE_BCOM001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.rptresult'))
drop table dbo.rptresult
go

/*==============================================================*/
/* Table: rptresult                                             */
/*==============================================================*/
create table dbo.rptresult (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   file_name            nvarchar(256)        not null default '',
   file_ext             nvarchar(20)         not null default '',
   file_size            nvarchar(20)         not null default '',
   file_summary         float                not null default 0,
   save_mode            nvarchar(1)          not null default '',
   file_path            nvarchar(400)        not null default ''
)
on "PRIMARY"
go

alter table dbo.rptresult
   add constraint PK_RPTRESULT primary key (pk_id)
      on "PRIMARY"
go

alter table dbo.arpt001
   add arpta18 nvarchar(10) NOT NULL DEFAULT  ''
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄角色;印表登錄角色',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta18'
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nrig004'))
drop table dbo.nrig004
go

/*==============================================================*/
/* Table: nrig004                                               */
/*==============================================================*/
create table dbo.nrig004 (
   recid                uniqueidentifier     not null,
   user_no              nvarchar(10)         not null,
   program_a            nvarchar(1)          not null default '',
   stopuser_a           nvarchar(1)          not null default '',
   program_b            nvarchar(1)          not null default '',
   stopuser_b           nvarchar(1)          not null default '',
   program_c            nvarchar(1)          not null default '',
   stopuser_c           nvarchar(1)          not null default '',
   program_d            nvarchar(1)          not null default '',
   stopuser_d           nvarchar(1)          not null default '',
   program_e            nvarchar(1)          not null default '',
   stopuser_e           nvarchar(1)          not null default '',
   program_f            nvarchar(1)          not null default '',
   stopuser_f           nvarchar(1)          not null default '',
   program_g            nvarchar(1)          not null default '',
   stopuser_g           nvarchar(1)          not null default '',
   program_h            nvarchar(1)          not null default '',
   stopuser_h           nvarchar(1)          not null default '',
   program_i            nvarchar(1)          not null default '',
   stopuser_i           nvarchar(1)          not null default '',
   program_j            nvarchar(1)          not null default '',
   stopuser_j           nvarchar(1)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '決策支援管理者用戶編號;決策支援管理者用戶編號',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許行程總覽;是/否允許行程總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_a'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程資料查詢是/否包含停用用戶;行程資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_a'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許工作總覽;是/否允許工作總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_b'
go

execute sp_addextendedproperty 'MS_Description', 
   '工作資料查詢是/否包含停用用戶;工作資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_b'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許事件總覽;是/否允許事件總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_c'
go

execute sp_addextendedproperty 'MS_Description', 
   '事件資料查詢是/否包含停用用戶;事件資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_c'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許訊息總覽;是/否允許訊息總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_d'
go

execute sp_addextendedproperty 'MS_Description', 
   '訊息資料查詢是/否包含停用用戶;訊息資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_d'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許日報總覽;是/否允許日報總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_e'
go

execute sp_addextendedproperty 'MS_Description', 
   '日報資料查詢是/否包含停用用戶;日報資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_e'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否允許郵件總覽;是/否允許郵件總覽',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_f'
go

execute sp_addextendedproperty 'MS_Description', 
   '郵件資料查詢是/否包含停用用戶;郵件資料查詢是/否包含停用用戶',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_f'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留1);(預留1)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_g'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留2);(預留2)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_g'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留3);(預留3)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_h'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留4);(預留4)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_h'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留5);(預留5)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_i'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留6);(預留6)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_i'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留7);(預留7)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'program_j'
go

execute sp_addextendedproperty 'MS_Description', 
   '(預留8);(預留8)',
   'schema', 'dbo', 'table', 'nrig004', 'column', 'stopuser_j'
go

alter table dbo.nrig004
   add constraint PK_NRIG004 primary key (user_no)
      on "PRIMARY"
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nrig005'))
drop table dbo.nrig005
go

/*==============================================================*/
/* Table: nrig005                                               */
/*==============================================================*/
create table dbo.nrig005 (
   recid                uniqueidentifier     not null,
   user_no              nvarchar(10)         not null,
   program              nvarchar(1)          not null,
   role_type            nvarchar(1)          not null,
   role_code            nvarchar(10)         not null,
   cover_lower          int                  not null default 0,
   cover_upper          int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '決策支援管理者用戶編號;決策支援管理者用戶編號',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'user_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '決策支援項目編號;決策支援項目編號',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'program'
go

execute sp_addextendedproperty 'MS_Description', 
   '瀏覽對象系統角色類別;瀏覽對象系統角色類別',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'role_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '瀏覽對象系統角色編號;瀏覽對象系統角色編號',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'role_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否包含下級部門;是否包含下級部門',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'cover_lower'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否包含上級部門;是否包含上級部門',
   'schema', 'dbo', 'table', 'nrig005', 'column', 'cover_upper'
go

alter table dbo.nrig005
   add constraint PK_NRIG005 primary key (user_no, program, role_type, role_code)
      on "PRIMARY"
go


ALTER TABLE tsys001 ADD tsysa08 DATETIME not null default CONVERT(DATETIME,0)
go
execute sp_addextendedproperty 'MS_Description', 
   '最後操作時間;最後操作時間',
   'schema', 'dbo', 'table', 'tsys001', 'column', 'tsysa08'
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tsys007'))
drop table dbo.tsys007
go

/*==============================================================*/
/* Table: tsys007                                               */
/*==============================================================*/
create table dbo.tsys007 (
   tsysg01              nvarchar(10)         not null,
   tsysg02              nvarchar(10)         not null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   '关联表名;关联表名',
   'schema', 'dbo', 'table', 'tsys007', 'column', 'tsysg01'
go

execute sp_addextendedproperty 'MS_Description', 
   '程式名;程式名',
   'schema', 'dbo', 'table', 'tsys007', 'column', 'tsysg02'
go

alter table dbo.tsys007
   add constraint PK_TSYS007 primary key (tsysg01, tsysg02)
      on "PRIMARY"
GO
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tsys008'))
drop table dbo.tsys008
go

/*==============================================================*/
/* Table: tsys008                                               */
/*==============================================================*/
create table dbo.tsys008 (
   tsysh01              nvarchar(10)         not null,
   tsysh02              nvarchar(10)         not null,
   tsysh03              nvarchar(10)         not null,
   tsysh04              nvarchar(100)        null,
   tsysh05              nvarchar(100)        null,
   tsysh06              nvarchar(100)        null,
   tsysh07              nvarchar(10)         null,
   tsysh08              int                  null,
   tsysh09              nvarchar(1)          null,
   tsysh10              nvarchar(10)         null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   '关联表名;关联表名',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh01'
go

execute sp_addextendedproperty 'MS_Description', 
   '程式名;程式名',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh02'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段名;字段名',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh03'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段描述(繁体);字段描述(繁体)',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh04'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段描述(英文);字段描述(英文)',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh05'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段描述(简体);字段描述(简体)',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh06'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段类型;字段类型',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh07'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段长度;字段长度',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh08'
go

execute sp_addextendedproperty 'MS_Description', 
   '必输栏位;必输栏位',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh09'
go

execute sp_addextendedproperty 'MS_Description', 
   '预设值;预设值',
   'schema', 'dbo', 'table', 'tsys008', 'column', 'tsysh10'
go

alter table dbo.tsys008
   add constraint PK_TSYS008 primary key (tsysh01, tsysh02, tsysh03)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tsys009'))
drop table dbo.tsys009
go

/*==============================================================*/
/* Table: tsys009                                               */
/*==============================================================*/
create table dbo.tsys009 (
   tsysi01              nvarchar(10)         not null,
   tsysi02              nvarchar(10)         not null,
   tsysi03              nvarchar(10)         not null,
   tsysi04              nvarchar(100)        not null,
   tsysi05              nvarchar(100)        null,
   tsysi06              nvarchar(100)        null,
   tsysi07              nvarchar(100)        null,
   tsysi08              nvarchar(1)          null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   '关联表名;关联表名',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi01'
go

execute sp_addextendedproperty 'MS_Description', 
   '程式名;程式名',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi02'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段名;字段名',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi03'
go

execute sp_addextendedproperty 'MS_Description', 
   '字段取值;字段取值',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi04'
go

execute sp_addextendedproperty 'MS_Description', 
   '取值描述(繁体);取值描述(繁体)',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi05'
go

execute sp_addextendedproperty 'MS_Description', 
   '取值描述(英文);取值描述(英文)',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi06'
go

execute sp_addextendedproperty 'MS_Description', 
   '取值描述(简体);取值描述(简体)',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi07'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否默认值;是否默认值',
   'schema', 'dbo', 'table', 'tsys009', 'column', 'tsysi08'
go

alter table dbo.tsys009
   add constraint PK_TSYS009 primary key (tsysi01, tsysi02, tsysi03, tsysi04)
      on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/6/5 下午 03:35:23                         */
/*==============================================================*/
alter table dbo.bcom010
   drop constraint PK_BCOM010
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bcom010'))
drop table dbo.tmp_bcom010
go

execute sp_rename bcom010, tmp_bcom010
go

/*==============================================================*/
/* Table: bcom010                                               */
/*==============================================================*/
create table dbo.bcom010 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   bcomj01              nvarchar(10)         not null,
   bcomj02              nvarchar(2)          not null,
   bcomj03              nvarchar(2)          not null default '',
   bcomj04              nvarchar(30)         not null default '',
   bcomj04a             nvarchar(30)         not null default '',
   bcomj05              nvarchar(1)          not null default '',
   bcomj06              nvarchar(8)          not null default '',
   bcomj07              int                  not null default 0,
   bcomj08              int                  not null default 0,
   bcomj09              nvarchar(6)          not null default '',
   bcomj10              int                  not null default 0,
   bcomj11              nvarchar(8)          not null default '',
   bcomj12              nvarchar(1)          not null default '',
   bcomj13              nvarchar(1)          not null default '',
   bcomj14              nvarchar(1)          not null default '',
   bcomj15              nvarchar(1)          not null default '',
   bcomj16              nvarchar(20)         not null default '',
   bcomj17              nvarchar(10)         not null default '',
   bcomj18              nvarchar(1)          not null default '',
   bcomj19              numeric(9,5)         not null default 0,
   bcomj20              numeric(9,5)         not null default 0,
   bcomj21              int                  not null default 0,
   bcomj22              int                  not null default 0,
   bcomj23              nvarchar(1)          not null default '',
   user_text1           nvarchar(30)         not null default '',
   user_text2           nvarchar(30)         not null default '',
   user_text3           nvarchar(30)         not null default '',
   user_num1            numeric(19,8)        not null default 0,
   user_num2            numeric(19,8)        not null default 0,
   user_num3            numeric(19,8)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'RecID;RecID',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司;公司',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '程式代號;程式代號',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj02'
go

execute sp_addextendedproperty 'MS_Description', 
   '隸屬模組或系統;隸屬模組或系統',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj03'
go

execute sp_addextendedproperty 'MS_Description', 
   '中文報表標題;中文報表標題',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj04'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文報表標題;英文報表標題',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '每頁印表頭否;每頁印表頭否',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj05'
go

execute sp_addextendedproperty 'MS_Description', 
   '表頭檔案;表頭檔案',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj06'
go

execute sp_addextendedproperty 'MS_Description', 
   '表頭行數;表頭行數',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj07'
go

execute sp_addextendedproperty 'MS_Description', 
   '整頁報表行數;整頁報表行數',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj08'
go

execute sp_addextendedproperty 'MS_Description', 
   '預設描述類型;預設描述類型',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj09'
go

execute sp_addextendedproperty 'MS_Description', 
   '表尾行數;表尾行數',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj10'
go

execute sp_addextendedproperty 'MS_Description', 
   '表尾檔案;表尾檔案',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj11'
go

execute sp_addextendedproperty 'MS_Description', 
   '每頁印表尾否;每頁印表尾否',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj12'
go

execute sp_addextendedproperty 'MS_Description', 
   '零的印法;零的印法',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj13'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字comma;數字comma',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj14'
go

execute sp_addextendedproperty 'MS_Description', 
   '列印業務用語;列印業務用語',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj15'
go

execute sp_addextendedproperty 'MS_Description', 
   'ISO編號;ISO編號',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj16'
go

execute sp_addextendedproperty 'MS_Description', 
   '有效期;有效期',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj17'
go

execute sp_addextendedproperty 'MS_Description', 
   '預設紙張;預設紙張',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj18'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定紙張的長(單位mm);自定紙張的長(單位mm)',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj19'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定紙張的寬(單位mm);自定紙張的寬(單位mm)',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj20'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定紙張的每頁Rows數;自定紙張的每頁Rows數',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj21'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定紙張的每頁Columns數;自定紙張的每頁Columns數',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj22'
go

execute sp_addextendedproperty 'MS_Description', 
   '日期格式;日期格式',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'bcomj23'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄一;文字自定欄一',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄二;文字自定欄二',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄三;文字自定欄三',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄一;數字自定欄一',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄二;數字自定欄二',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄三;數字自定欄三',
   'schema', 'dbo', 'table', 'bcom010', 'column', 'user_num3'
go

insert into dbo.bcom010 (recid, doc_comp, bcomj01, bcomj02, bcomj03, bcomj04, bcomj05, bcomj06, bcomj07, bcomj08, bcomj09, bcomj10, bcomj11, bcomj12, bcomj13, bcomj14, bcomj15, bcomj16, bcomj17, bcomj18, bcomj19, bcomj20, bcomj21, bcomj22, bcomj23, user_text1, user_text2, user_text3, user_num1, user_num2, user_num3)
select recid, doc_comp, bcomj01, bcomj02, bcomj03, bcomj04, bcomj05, bcomj06, bcomj07, bcomj08, bcomj09, bcomj10, bcomj11, bcomj12, bcomj13, bcomj14, bcomj15, bcomj16, bcomj17, bcomj18, bcomj19, bcomj20, bcomj21, bcomj22, bcomj23, user_text1, user_text2, user_text3, user_num1, user_num2, user_num3
from dbo.tmp_bcom010
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bcom010'))
drop table dbo.tmp_bcom010
go

alter table dbo.bcom010
   add constraint PK_BCOM010 primary key (doc_comp, bcomj01, bcomj02)
      on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/7/8 上午 10:58:34                         */
/*==============================================================*/
alter table dbo.arpt003
   drop constraint PK_ARPT003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

execute sp_rename arpt003, tmp_arpt003
go

/*==============================================================*/
/* Table: arpt003                                               */
/*==============================================================*/
create table dbo.arpt003 (
   recid                uniqueidentifier     not null,
   arptc01              nvarchar(10)         not null,
   arptc02              nvarchar(10)         not null,
   arptc03              nvarchar(1)          not null default '',
   arptc04              nvarchar(10)         not null,
   num                  float                not null default 0,
   arptc05              nvarchar(40)         not null default '',
   arptc06              varbinary(max)       null,
   arptc07              nvarchar(20)         not null default '',
   arptc08              nvarchar(2)          not null default '',
   arptc09              nvarchar(1)          not null default '',
   arptc10              nvarchar(256)        not null default '',
   arptc11              nvarchar(1)          not null default '',
   arptc12              nvarchar(5)          not null default '',
   arptc13              nvarchar(256)        not null default '',
   arptc14              datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '多語言別;多語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '版本代號;版本代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式名稱;格式名稱',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc05'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式設定檔;格式設定檔',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔用戶;建檔用戶',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '應用狀態;應用狀態',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc08'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入標誌;載入標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '數據來源方案;數據來源方案',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統標誌;系統標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入語言別;載入語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件名;格式檔文件名',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件日期;格式檔文件日期',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc14'
go

insert into dbo.arpt003 (recid, arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12)
select recid, arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12
from dbo.tmp_arpt003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

alter table dbo.arpt003
   add constraint PK_ARPT003 primary key (arptc01, arptc02, arptc04)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/7/8 上午 11:43:12                         */
/*==============================================================*/
alter table dbo.arpt003
   drop constraint PK_ARPT003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

execute sp_rename arpt003, tmp_arpt003
go

/*==============================================================*/
/* Table: arpt003                                               */
/*==============================================================*/
create table dbo.arpt003 (
   recid                uniqueidentifier     not null,
   portal_id            nvarchar(3)          not null,
   arptc01              nvarchar(10)         not null,
   arptc02              nvarchar(10)         not null,
   arptc03              nvarchar(1)          not null default '',
   arptc04              nvarchar(10)         not null,
   num                  float                not null default 0,
   arptc05              nvarchar(40)         not null default '',
   arptc06              varbinary(max)       null,
   arptc07              nvarchar(20)         not null default '',
   arptc08              nvarchar(2)          not null default '',
   arptc09              nvarchar(1)          not null default '',
   arptc10              nvarchar(256)        not null default '',
   arptc11              nvarchar(1)          not null default '',
   arptc12              nvarchar(5)          not null default '',
   arptc13              nvarchar(256)        not null default '',
   arptc14              datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'recid'
GO

execute sp_addextendedproperty 'MS_Description', 
   '區分產品別;區分產品別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'portal_id'
GO

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '多語言別;多語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '版本代號;版本代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式名稱;格式名稱',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc05'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式設定檔;格式設定檔',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔用戶;建檔用戶',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '應用狀態;應用狀態',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc08'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入標誌;載入標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '數據來源方案;數據來源方案',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統標誌;系統標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入語言別;載入語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件名;格式檔文件名',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件日期;格式檔文件日期',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc14'
go


insert into dbo.arpt003 (recid, portal_id, arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12, arptc13, arptc14)
select recid, N'ES', arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12, arptc13, arptc14
from dbo.tmp_arpt003
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
GO

alter table dbo.arpt003
   add constraint PK_ARPT003 primary key (portal_id, arptc01, arptc02, arptc04)
      on "PRIMARY"
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/6/29 上午 11:20:34                        */
/*==============================================================*/
alter table dbo.dinv001
   drop constraint PK_DINV001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv001'))
drop table dbo.tmp_dinv001
go

execute sp_rename dinv001, tmp_dinv001
go
/*==============================================================*/
/* Table: dinv001                                               */
/*==============================================================*/
create table dbo.dinv001 (
   recid                uniqueidentifier     not null,
   dinva01a             nvarchar(2)          not null,
   dinva01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   dinva02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   dinva03              nvarchar(60)         not null default '',
   dinva04              nvarchar(20)         not null default '',
   dinva04a             nvarchar(20)         not null default '',
   dinva05a             nvarchar(20)         not null default '',
   dinva05b             nvarchar(20)         not null default '',
   dinva05c             nvarchar(20)         not null default '',
   dinva05d             nvarchar(7)          not null default '',
   dinva05e             nvarchar(27)         not null default '',
   dinva06a             nvarchar(80)         not null default '',
   dinva06b             nvarchar(200)        not null default '',
   dinva07              nvarchar(1)          not null default '',
   dinva08              numeric(9,5)         not null default 0,
   dinva09              nvarchar(1)          not null default '',
   dinva10a             datetime             not null default CONVERT(DATETIME,0),
   dinva10b             datetime             not null default CONVERT(DATETIME,0),
   dinva10c             datetime             not null default CONVERT(DATETIME,0),
   dinva10d             datetime             not null default CONVERT(DATETIME,0),
   dinva11              nvarchar(20)         not null default '',
   dinva12              nvarchar(20)         not null default '',
   dinva13a             nvarchar(1)          not null default '',
   dinva13b             nvarchar(10)         not null default '',
   dinva14a             nvarchar(1)          not null default '',
   dinva14b             nvarchar(10)         not null default '',
   dinva15a             nvarchar(1)          not null default '',
   dinva15b             nvarchar(10)         not null default '',
   dinva15c             nvarchar(1)          null default '',
   dinva15d             nvarchar(10)         null default '',
   dinva15e             nvarchar(6)          null default '',
   dinva15f             nvarchar(80)         null default '',
   dinva16a             nvarchar(1)          not null default '',
   dinva16b             nvarchar(10)         not null default '',
   dinva17a             nvarchar(1)          not null default '',
   dinva17b             nvarchar(10)         not null default '',
   dinva18a             nvarchar(1)          not null default '',
   dinva18b             nvarchar(10)         not null default '',
   dinva19              nvarchar(10)         not null default '',
   dinva19a             nvarchar(1)          not null default '',
   dinva19b             nvarchar(2)          not null default '',
   dinva20              nvarchar(20)         not null default '',
   dinva21a             nvarchar(1)          not null default '',
   dinva21b             nvarchar(10)         not null default '',
   dinva21c             nvarchar(80)         not null default '',
   dinva22a             nvarchar(1)          not null default '',
   dinva22b             nvarchar(10)         not null default '',
   dinva22c             nvarchar(80)         not null default '',
   dinva23              datetime             not null default CONVERT(DATETIME,0),
   dinva26              nvarchar(6)          not null default '',
   dinva26a             nvarchar(30)         not null default '',
   dinva26b             nvarchar(20)         not null default '',
   dinva26c             nvarchar(20)         not null default '',
   dinva26d             nvarchar(20)         not null default '',
   dinva26e             nvarchar(40)         not null default '',
   dinva27              nvarchar(2)          not null default '',
   dinva24              nvarchar(10)         not null default '',
   dinva25              nvarchar(10)         not null default '',
   dinva28              nvarchar(1)          not null default '',
   dinva29a             nvarchar(40)         not null default '',
   dinva29b             nvarchar(40)         not null default '',
   dinva29c             nvarchar(40)         not null default '',
   dinva30a             nvarchar(2)          not null default '',
   dinva30b             nvarchar(16)         not null default '',
   dinva31a             nvarchar(2)          not null default '',
   dinva31b             nvarchar(16)         not null default '',
   dinva31c             int                  not null default 0,
   dinva31d             nvarchar(20)         not null default '',
   dinva31e             nvarchar(2)          not null default '',
   dinva32a             nvarchar(2)          not null default '',
   dinva32b             nvarchar(16)         not null default '',
   dinva32c             int                  not null default 0,
   dinva32d             nvarchar(20)         not null default '',
   dinva33              nvarchar(6)          not null default '',
   dinva34              nvarchar(6)          not null default '',
   doc_dig1             int                  not null default 0,
   doc_dig2             int                  not null default 0,
   doc_dig3             int                  not null default 0,
   comp_dig1            int                  not null default 0,
   comp_dig2            int                  not null default 0,
   comp_dig3            int                  not null default 0,
   dinva35a             nvarchar(1)          not null default '',
   dinva35b             numeric(9,5)         not null default 0,
   dinva35c             nvarchar(1)          not null default '',
   dinva36a             nvarchar(20)         not null default '',
   dinva36b             nvarchar(20)         not null default '',
   dinva37a             nvarchar(6)          not null default '',
   dinva37b             nvarchar(80)         not null default '',
   dinva37c             int                  not null default 0,
   dinva37d             numeric(9,5)         not null default 0,
   dinva37e             int                  not null default 0,
   dinva37f             numeric(9,5)         not null default 0,
   dinva38a             nvarchar(1)          not null default '',
   dinva38b             nvarchar(1)          not null default '',
   dinva38c             nvarchar(1)          not null default '',
   dinva38d             nvarchar(1)          not null default '',
   dinva38e             nvarchar(1)          not null default '',
   dinva38f             nvarchar(1)          not null default '',
   dinva38g             nvarchar(1)          not null default '',
   dinva38h             nvarchar(1)          not null default '',
   dinva40              numeric(19,5)        not null default 0,
   dinva41              numeric(19,5)        not null default 0,
   dinva42              numeric(19,5)        not null default 0,
   dinva43              numeric(19,5)        not null default 0,
   dinva44              numeric(19,5)        not null default 0,
   dinva45              numeric(19,5)        not null default 0,
   dinva46              numeric(19,5)        not null default 0,
   dinva47              numeric(19,5)        not null default 0,
   dinva50              numeric(19,5)        not null default 0,
   dinva51              numeric(19,5)        not null default 0,
   dinva52              numeric(19,5)        not null default 0,
   dinva53              numeric(19,5)        not null default 0,
   dinva54              numeric(19,5)        not null default 0,
   dinva55              numeric(19,5)        not null default 0,
   dinva56              numeric(19,5)        not null default 0,
   dinva57              numeric(19,5)        not null default 0,
   dinva58              numeric(19,5)        not null default 0,
   dinva59              numeric(19,5)        not null default 0,
   user_text1           nvarchar(20)         not null default '',
   user_text2           nvarchar(20)         not null default '',
   user_text3           nvarchar(20)         not null default '',
   user_text4           nvarchar(20)         not null default '',
   user_text5           nvarchar(20)         not null default '',
   user_num1            numeric(19,5)        not null default 0,
   user_num2            numeric(19,5)        not null default 0,
   user_num3            numeric(19,5)        not null default 0,
   user_num4            numeric(19,5)        not null default 0,
   user_num5            numeric(19,5)        not null default 0,
   dinva60b             int                  not null default 0,
   dinva60c             int                  not null default 0,
   dinva61b             int                  not null default 0,
   dinva61c             int                  not null default 0,
   dinva62b             int                  not null default 0,
   dinva62c             int                  not null default 0,
   dinva63b             int                  not null default 0,
   dinva63c             int                  not null default 0,
   dinva64b             int                  not null default 0,
   dinva64c             int                  not null default 0,
   dinva65b             int                  not null default 0,
   dinva65c             int                  not null default 0,
   dinva66b             int                  not null default 0,
   dinva66c             int                  not null default 0,
   dinva67a             nvarchar(20)         not null default '',
   dinva67b             int                  not null default 0,
   dinva67c             int                  not null default 0,
   dinva68a             nvarchar(20)         not null default '',
   dinva68b             int                  not null default 0,
   dinva68c             int                  not null default 0,
   dinva69a             nvarchar(20)         not null default '',
   dinva69b             int                  not null default 0,
   dinva69c             int                  not null default 0,
   dinva70a             nvarchar(20)         not null default '',
   dinva70b             int                  not null default 0,
   dinva70c             int                  not null default 0,
   dinva71a             nvarchar(20)         not null default '',
   dinva71b             int                  not null default 0,
   dinva71c             int                  not null default 0,
   dinva73a             nvarchar(1)          not null default '',
   dinva73b             nvarchar(10)         not null default '',
   dinva74              nvarchar(1)          not null default '',
   dinva75              datetime             not null default CONVERT(DATETIME,0),
   dinva76a             numeric(19,5)        not null default 0,
   dinva76b             numeric(19,5)        not null default 0,
   dinva77a             numeric(9,5)         not null default 0,
   dinva77b             numeric(9,5)         not null default 0,
   dinva78a             numeric(9,5)         not null default 0,
   dinva78b             numeric(9,5)         not null default 0,
   dinva79              nvarchar(1)          not null default '',
   dinva81              int                  not null default 0,
   dinva82a             nvarchar(1)          not null default '',
   dinva82b             datetime             not null default CONVERT(DATETIME,0),
   dinva83a             nvarchar(1)          not null default '',
   dinva83b             datetime             not null default CONVERT(DATETIME,0),
   dinva84a             nvarchar(1)          not null default '',
   dinva84b             datetime             not null default CONVERT(DATETIME,0),
   dinva85a             nvarchar(1)          not null default '',
   dinva85b             datetime             not null default CONVERT(DATETIME,0),
   dinva86              nvarchar(4)          not null default '',
   dinva87              int                  not null default 0,
   dinva88              datetime             not null default CONVERT(DATETIME,0),
   dinva89              datetime             not null default CONVERT(DATETIME,0),
   dinva90a             datetime             not null default CONVERT(DATETIME,0),
   dinva90b             datetime             not null default CONVERT(DATETIME,0),
   dinva91a             nvarchar(1)          not null default '',
   dinva91b             nvarchar(1)          not null default '',
   dinva91c             nvarchar(10)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status1          nvarchar(1)          not null default '',
   last_user1           nvarchar(10)         not null default '',
   last_date1           datetime             not null default CONVERT(DATETIME,0),
   doc_status2          nvarchar(1)          not null default '',
   last_user2           nvarchar(10)         not null default '',
   last_date2           datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   'vessel;vessel',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva03'
go

execute sp_addextendedproperty 'MS_Description', 
   '專案代號;專案代號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva04'
go

execute sp_addextendedproperty 'MS_Description', 
   '對方單號;對方單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva04a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Code;Price Term Code',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05d'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Desc;Price Term Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva05e'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象名稱(用於印表);對象名稱(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象地址(用於印表);對象地址(用於印表)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '佣金交易;佣金交易',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva07'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValue%;UnderValue%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva08'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱數計算依;箱數計算依',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva09'
go

execute sp_addextendedproperty 'MS_Description', 
   'On Board Date;On Board Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Close Date;Close Date',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計出貨日;預計出貨日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10c'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計到達日;預計到達日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva10d'
go

execute sp_addextendedproperty 'MS_Description', 
   '原產地;原產地',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva11'
go

execute sp_addextendedproperty 'MS_Description', 
   'S/O No.;S/O No.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva12'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象別;報關行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13a'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關行對象編號;報關行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象別;收款對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款對象編號;收款對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象別;交貨對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨對象編號;交貨對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象別;交貨地點對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15c'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象編號;交貨地點對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15d'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點序號;交貨地點序號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15e'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點描述;交貨地點描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva15f'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象別;Agent對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent對象編號;Agent對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva16b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象別;Consignee對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee對象編號;Consignee對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva17b'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象別;A/Notify對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18a'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify對象編號;A/Notify對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva18b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU出貨轉單方案;OBU出貨轉單方案',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉產生標記;OBU拋轉產生標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19a'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉狀態標記;OBU拋轉狀態標記',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排櫃單號;排櫃單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva20'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象別;接櫃人對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21a'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人對象編號;接櫃人對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21b'
go

execute sp_addextendedproperty 'MS_Description', 
   '接櫃人描述;接櫃人描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva21c'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象別;放櫃處對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處對象編號;放櫃處對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22b'
go

execute sp_addextendedproperty 'MS_Description', 
   '放櫃處描述;放櫃處描述',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva22c'
go

execute sp_addextendedproperty 'MS_Description', 
   '離廠日;離廠日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva23'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡人代碼;聯絡人代碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一;聯絡電話一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二;聯絡電話二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真;聯絡傳真',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email;聯絡email',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva26e'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭編號;嘜頭編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva27'
go

execute sp_addextendedproperty 'MS_Description', 
   '驗貨人;驗貨人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva24'
go

execute sp_addextendedproperty 'MS_Description', 
   '船務;船務',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva25'
go

execute sp_addextendedproperty 'MS_Description', 
   '本單Packing和Invoice聯動;本單Packing和Invoice聯動',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva28'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 1;Invoice of …… 1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 2;Invoice of …… 2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice of …… 3;Invoice of …… 3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva29c'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單別;合約單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單號;合約單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva30b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31d'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單類別;來源單類別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva31e'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva33'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva34'
go

execute sp_addextendedproperty 'MS_Description', 
   '單價小數位;單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '小計小數位;小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '總計小數位;總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣單價小數位;換算公司幣單價小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣小計小數位;換算公司幣小計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣總計小數位;換算公司幣總計小數位',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'comp_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動取位設定;啟動取位設定',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35a'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位設定基數;取位設定基數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35b'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位不整除;取位不整除',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva35c'
go

execute sp_addextendedproperty 'MS_Description', 
   '經海關証明文件編號;經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36a'
go

execute sp_addextendedproperty 'MS_Description', 
   '非經海關証明文件編號;非經海關証明文件編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment code;payment code',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37a'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment desc.;payment desc.',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37b'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)幾天內;現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37c'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)扣幾%;現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37d'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)幾天內;現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37e'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)扣幾%;現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva37f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況1-產生Packing;更檔狀況1-產生Packing',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38a'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況2-產生Invoice;更檔狀況2-產生Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38b'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況3-產生產品來源;更檔狀況3-產生產品來源',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38c'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況4-確認訂單出貨;更檔狀況4-確認訂單出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38d'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況5-確認採購出貨;更檔狀況5-確認採購出貨',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38e'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況6-產生應收帳款;更檔狀況6-產生應收帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38f'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況7-產生應付帳款;更檔狀況7-產生應付帳款',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38g'
go

execute sp_addextendedproperty 'MS_Description', 
   '更檔狀況8-應收L/C押匯;更檔狀況8-應收L/C押匯',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva38h'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva40'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva41'
go

execute sp_addextendedproperty 'MS_Description', 
   '總箱數;總箱數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva42'
go

execute sp_addextendedproperty 'MS_Description', 
   '總棧板數;總棧板數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva43'
go

execute sp_addextendedproperty 'MS_Description', 
   '總淨重;總淨重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva44'
go

execute sp_addextendedproperty 'MS_Description', 
   '總毛重;總毛重',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva45'
go

execute sp_addextendedproperty 'MS_Description', 
   '總體積;總體積',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva46'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量(含分開包裝);總數量(含分開包裝)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva47'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice未稅總額;Invoice未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva50'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice含稅總額;Invoice含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva51'
go

execute sp_addextendedproperty 'MS_Description', 
   'Invoice UnderValude 總額;Invoice UnderValude 總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva52'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款未稅總額;加扣款未稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva53'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款含稅總額;加扣款含稅總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva54'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金總額;稅金總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva55'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款總額;代收款總額',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva56'
go

execute sp_addextendedproperty 'MS_Description', 
   '商品採購成本未稅總額(公司幣別);商品採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva57'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配採購成本未稅總額(公司幣別);贈配採購成本未稅總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva58'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估費用總額(公司幣別);預估費用總額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva59'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值一;自定義文字欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值二;自定義文字欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值三;自定義文字欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值四;自定義文字欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值五;自定義文字欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值一;自定義數值欄值一',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值二;自定義數值欄值二',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值三;自定義數值欄值三',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值四;自定義數值欄值四',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值五;自定義數值欄值五',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Commerical Invoice;原稿份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Commerical Invoice;拷貝份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva60c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Customs Invoice;原稿份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Customs Invoice;拷貝份數 Customs Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva61c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Bill of Lading;原稿份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Bill of Lading;拷貝份數 Bill of Lading',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva62c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Packing List;原稿份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Packing List;拷貝份數 Packing List',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva63c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Insur. Certificate;原稿份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Insur. Certificate;拷貝份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva64c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Certificate Origin;原稿份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Certificate Origin;拷貝份數 Certificate Origin',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva65c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Consular Invoice;原稿份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Consular Invoice;拷貝份數 Consular Invoice',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva66c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other1 Desc;Other1 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other1;原稿份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other1;拷貝份數 Other1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva67c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other2 Desc;Other2 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other2;原稿份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other2;拷貝份數 Other2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva68c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other3 Desc;Other3 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other3;原稿份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other3;拷貝份數 Other3',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva69c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other4 Desc;Other4 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other4;原稿份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other4;拷貝份數 Other4',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva70c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other5 Desc;Other5 Desc',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other5;原稿份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other5;拷貝份數 Other5',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva71c'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象別;押匯銀行對象別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯銀行對象編號;押匯銀行對象編號',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva73b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出口L/C帳款金額選擇;出口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva74'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯日期;押匯日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva75'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(單據幣別);押匯總金額(單據幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯總金額(公司幣別);押匯總金額(公司幣別)',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva76b'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-公司幣別;押匯匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77a'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯匯率-系統幣別;押匯匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva77b'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-公司幣別;結關匯率-公司幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78a'
go

execute sp_addextendedproperty 'MS_Description', 
   '結關匯率-系統幣別;結關匯率-系統幣別',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva78b'
go

execute sp_addextendedproperty 'MS_Description', 
   '進口L/C帳款金額選擇;進口L/C帳款金額選擇',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva79'
go

execute sp_addextendedproperty 'MS_Description', 
   'Revised 修改次數;Revised 修改次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva81'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日選中;實際出口日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82a'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際出口日;實際出口日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva82b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日選中;交件安裝日選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交件安裝日;交件安裝日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva83b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1選中;追蹤項目1選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1;追蹤項目1',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva84b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2選中;追蹤項目2選中',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2;追蹤項目2',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva85b'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨倉庫;出貨倉庫',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva86'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據列印次數;單據列印次數',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva87'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據到期日;票據到期日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva88'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計收款日;預計收款日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva89'
go

execute sp_addextendedproperty 'MS_Description', 
   '立帳日期;立帳日期',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90a'
go

execute sp_addextendedproperty 'MS_Description', 
   '帳款月份;帳款月份',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva90b'
go

execute sp_addextendedproperty 'MS_Description', 
   '隨貨開立發票否？;隨貨開立發票否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91a'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票全部開立否？;發票全部開立否？',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91b'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票號碼;發票號碼',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'dinva91c'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯覆核/作廢;押匯覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態人;押匯最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user1'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯最後更改狀態日;押匯最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date1'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉覆核/作廢;拋轉覆核/作廢',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'doc_status2'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態人;拋轉最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_user2'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉最後更改狀態日;拋轉最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv001', 'column', 'last_date2'
go

insert into dbo.dinv001 (recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva04a, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva15c, dinva15d, dinva15e, dinva15f, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1, doc_status2, last_user2, last_date2)
select recid, dinva01a, dinva01b, doc_comp, dinva02, doc_date, biz_type, biz_no, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, dinva03, dinva04, dinva04a, dinva05a, dinva05b, dinva05c, dinva06a, dinva06b, dinva07, dinva08, dinva09, dinva10a, dinva10b, dinva10c, dinva10d, dinva11, dinva12, dinva13a, dinva13b, dinva14a, dinva14b, dinva15a, dinva15b, dinva15c, dinva15d, dinva15e, dinva15f, dinva16a, dinva16b, dinva17a, dinva17b, dinva18a, dinva18b, dinva19, dinva19a, dinva19b, dinva20, dinva21a, dinva21b, dinva21c, dinva22a, dinva22b, dinva22c, dinva23, dinva26, dinva26a, dinva26b, dinva26c, dinva26d, dinva26e, dinva27, dinva24, dinva25, dinva28, dinva29a, dinva29b, dinva29c, dinva30a, dinva30b, dinva31a, dinva31b, dinva31c, dinva31d, dinva31e, dinva32a, dinva32b, dinva32c, dinva32d, dinva33, dinva34, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, dinva35a, dinva35b, dinva35c, dinva36a, dinva36b, dinva37a, dinva37b, dinva37c, dinva37d, dinva37e, dinva37f, dinva38a, dinva38b, dinva38c, dinva38d, dinva38e, dinva38f, dinva38g, dinva38h, dinva40, dinva41, dinva42, dinva43, dinva44, dinva45, dinva46, dinva47, dinva50, dinva51, dinva52, dinva53, dinva54, dinva55, dinva56, dinva57, dinva58, dinva59, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, dinva60b, dinva60c, dinva61b, dinva61c, dinva62b, dinva62c, dinva63b, dinva63c, dinva64b, dinva64c, dinva65b, dinva65c, dinva66b, dinva66c, dinva67a, dinva67b, dinva67c, dinva68a, dinva68b, dinva68c, dinva69a, dinva69b, dinva69c, dinva70a, dinva70b, dinva70c, dinva71a, dinva71b, dinva71c, dinva73a, dinva73b, dinva74, dinva75, dinva76a, dinva76b, dinva77a, dinva77b, dinva78a, dinva78b, dinva79, dinva81, dinva82a, dinva82b, dinva83a, dinva83b, dinva84a, dinva84b, dinva85a, dinva85b, dinva86, dinva87, dinva88, dinva89, dinva90a, dinva90b, dinva91a, dinva91b, dinva91c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date, doc_status1, last_user1, last_date1, doc_status2, last_user2, last_date2
from dbo.tmp_dinv001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv001'))
drop table dbo.tmp_dinv001
go

alter table dbo.dinv001
   add constraint PK_DINV001 primary key (dinva01a, dinva01b)
      on "PRIMARY"
go


if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nsch001'))
drop table dbo.nsch001
go

/*==============================================================*/
/* Table: nsch001                                               */
/*==============================================================*/
create table dbo.nsch001 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   function_id          nvarchar(2)          not null default '',
   sch_class            int                  not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   ref_browse           int                  not null default 0,
   title                nvarchar(256)        not null default '',
   content              nvarchar(max)        not null default '',
   cont_format          int                  not null default 0,
   sch_place            nvarchar(256)        not null default '',
   sch_type             nvarchar(20)         not null default '',
   sch_start            datetime             not null default CONVERT(DATETIME,0),
   sch_end              datetime             not null default CONVERT(DATETIME,0),
   is_allday            int                  not null default 0,
   cycle_id             int                  not null default 0,
   is_intending         int                  not null default 0,
   is_private           int                  not null default 0,
   need_confirm         int                  not null default 0,
   clock_remind         int                  not null default 0,
   is_closed            int                  not null default 0,
   close_user           nvarchar(10)         not null default '',
   close_date           datetime             not null default CONVERT(DATETIME,0),
   visit_type           nvarchar(1)          not null default '',
   visit_no             nvarchar(10)         not null default '',
   attn_name            nvarchar(30)         not null default '',
   attn_title           nvarchar(20)         not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程資料ID;行程資料ID',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'function_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程類型;行程類型',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'sch_class'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人用戶編號;最後更改狀態人用戶編號',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料狀態;資料狀態',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否允許關聯訪問擴充瀏覽者範圍;是否允許關聯訪問擴充瀏覽者範圍',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'ref_browse'
go

execute sp_addextendedproperty 'MS_Description', 
   '主旨;主旨',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'title'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容;內容',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'content'
go

execute sp_addextendedproperty 'MS_Description', 
   '內容格式;內容格式',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'cont_format'
go

execute sp_addextendedproperty 'MS_Description', 
   '地點;地點',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'sch_place'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程類別;行程類別',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'sch_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程開始日期時間;行程開始日期時間',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'sch_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程結束日期時間;行程結束日期時間',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'sch_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程時間是/否為全日;行程時間是/否為全日',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'is_allday'
go

execute sp_addextendedproperty 'MS_Description', 
   '週期性設定ID;週期性設定ID',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'cycle_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否為預排行程;是/否為預排行程',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'is_intending'
go

execute sp_addextendedproperty 'MS_Description', 
   '是/否為私人行程;是/否為私人行程',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'is_private'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程邀約是/否需要確認;行程邀約是/否需要確認',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'need_confirm'
go

execute sp_addextendedproperty 'MS_Description', 
   '鬧鐘提醒提前時間;鬧鐘提醒提前時間',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'clock_remind'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否結案;是否結案',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'is_closed'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案人用戶編號;結案人用戶編號',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'close_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '結案日期;結案日期',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'close_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象類別;拜訪對象類別',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'visit_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象編號;拜訪對象編號',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'visit_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象聯絡人名稱;拜訪對象聯絡人名稱',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'attn_name'
go

execute sp_addextendedproperty 'MS_Description', 
   '拜訪對象聯絡人職稱;拜訪對象聯絡人職稱',
   'schema', 'dbo', 'table', 'nsch001', 'column', 'attn_title'
go

alter table dbo.nsch001
   add constraint PK_NSCH001 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nsch001_1                                         */
/*==============================================================*/
create unique index idx_nsch001_1 on dbo.nsch001 (
is_closed ASC,
sch_start ASC,
sch_end ASC,
sch_class ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nsch001_2                                         */
/*==============================================================*/
create unique index idx_nsch001_2 on dbo.nsch001 (
function_id ASC,
sch_class ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nsch001_3                                         */
/*==============================================================*/
create unique index idx_nsch001_3 on dbo.nsch001 (
sch_type ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nsch001_4                                         */
/*==============================================================*/
create unique index idx_nsch001_4 on dbo.nsch001 (
cycle_id ASC,
pk_id ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_nsch001_5                                         */
/*==============================================================*/
create unique index idx_nsch001_5 on dbo.nsch001 (
visit_type ASC,
visit_no ASC,
pk_id ASC
)
on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nsch002'))
drop table dbo.nsch002
go

/*==============================================================*/
/* Table: nsch002                                               */
/*==============================================================*/
create table dbo.nsch002 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   user_type            nvarchar(1)          not null,
   role_type            nvarchar(1)          not null,
   role_code            nvarchar(10)          not null,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   confirm_status       nvarchar(1)          not null default '',
   confirm_note         nvarchar(100)        not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '交辦工作資料ID;交辦工作資料ID',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程人員類別;行程人員類別',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'user_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程角色類別;行程角色類別',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'role_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程角色編號;行程角色編號',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'role_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '與會人員確認狀態;與會人員確認狀態',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'confirm_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '與會人員確認原因;與會人員確認原因',
   'schema', 'dbo', 'table', 'nsch002', 'column', 'confirm_note'
go

alter table dbo.nsch002
   add constraint PK_NSCH002 primary key (pk_id, user_type, role_type, role_code)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.nsch003'))
drop table dbo.nsch003
go

/*==============================================================*/
/* Table: nsch003                                               */
/*==============================================================*/
create table dbo.nsch003 (
   recid                uniqueidentifier     not null,
   pk_id                int                  not null,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   cycle_area           int                  not null default 0,
   cycle_start          nvarchar(8)          not null default '',
   cycle_end            nvarchar(8)          not null default '',
   cycle_times          int                  not null default 0,
   cycle_mode           int                  not null default 0,
   day_period           int                  not null default 0,
   week_period          int                  not null default 0,
   week_sunday          nvarchar(1)          not null default '',
   week_monday          nvarchar(1)          not null default '',
   week_tuesday         nvarchar(1)          not null default '',
   week_wednesday       nvarchar(1)          not null default '',
   week_thursday        nvarchar(1)          not null default '',
   week_friday          nvarchar(1)          not null default '',
   week_saturday        nvarchar(1)          not null default '',
   month_mode           int                  not null default 0,
   m_day_period         int                  not null default 0,
   m_day_date           int                  not null default 0,
   m_week_period        int                  not null default 0,
   m_week_index         int                  not null default 0,
   m_week_date          int                  not null default 0,
   year_mode            int                  not null default 0,
   y_day_month          int                  not null default 0,
   y_day_date           int                  not null default 0,
   y_week_month         int                  not null default 0,
   y_week_index         int                  not null default 0,
   y_week_date          int                  not null default 0,
   sch_days             int                  not null default 0,
   time_start           nvarchar(6)          not null default '',
   time_end             nvarchar(6)          not null default '',
   is_allday            int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '週期性設定ID;週期性設定ID',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環範圍模式;循環範圍模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_area'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環開始日期;循環開始日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環結束日期;循環結束日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環次數;循環次數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_times'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始日期循環模式;開始日期循環模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每天模式"的循環間隔天數;"每天模式"的循環間隔天數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'day_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每週模式"的循環間隔週數;"每週模式"的循環間隔週數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期日";"每週模式"的"星期日',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_sunday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期一";"每週模式"的"星期一',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_monday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期二";"每週模式"的"星期二',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_tuesday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期三";"每週模式"的"星期三',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_wednesday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期四";"每週模式"的"星期四',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_thursday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期五";"每週模式"的"星期五',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_friday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期六";"每週模式"的"星期六',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_saturday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式";"每月模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'month_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份日期"的循環間隔月數;"每月模式-指定月份日期"的循環間隔月數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_day_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份日期"的日期;"每月模式-指定月份日期"的日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_day_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份星期"的循環間隔月數;"每月模式-指定月份星期"的循環間隔月數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式-指定月份星期的第幾週;每月模式-指定月份星期的第幾週',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_index'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式-指定月份星期的星期幾;每月模式-指定月份星期的星期幾',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '每年模式";"每年模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'year_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份日期"的月份;"每年模式-指定月份日期"的月份',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_day_month'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份日期"的日期;"每年模式-指定月份日期"的日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_day_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份星期"的月份;"每年模式-指定月份星期"的月份',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_month'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份"星期的第幾週;"每年模式-指定月份"星期的第幾週',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_index'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份"星期的星期幾;"每年模式-指定月份"星期的星期幾',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程天數;行程天數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'sch_days'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程開始時間;行程開始時間',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'time_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程結束時間;行程結束時間',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'time_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程時間是/否為全日;行程時間是/否為全日',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'is_allday'
go

alter table dbo.nsch003
   add constraint PK_NSCH003 primary key (pk_id)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/8/4 下午 03:48:03                         */
/*==============================================================*/
alter table dbo.epur001
   drop constraint PK_EPUR001
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_epur001'))
drop table dbo.tmp_epur001
go

execute sp_rename epur001, tmp_epur001
go
/*==============================================================*/
/* Table: epur001                                               */
/*==============================================================*/
create table dbo.epur001 (
   recid                uniqueidentifier     not null,
   epura01a             nvarchar(2)          not null,
   epura01b             nvarchar(16)         not null,
   doc_comp             nvarchar(3)          not null default '',
   epura02              nvarchar(2)          not null default '',
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   epura03a             nvarchar(2)          not null default '',
   epura03b             nvarchar(16)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   epura04a             nvarchar(2)          not null default '',
   epura04b             nvarchar(16)         not null default '',
   epura04c             int                  not null default 0,
   epura04d             nvarchar(20)         not null default '',
   epura05a             nvarchar(2)          not null default '',
   epura05b             nvarchar(16)         not null default '',
   epura05c             int                  not null default 0,
   epura05d             nvarchar(20)         not null default '',
   epura06              nvarchar(6)          not null default '',
   epura06a             nvarchar(30)         not null default '',
   epura06b             nvarchar(20)         not null default '',
   epura06c             nvarchar(20)         not null default '',
   epura06d             nvarchar(20)         not null default '',
   epura06e             nvarchar(40)         not null default '',
   epura07              nvarchar(20)         not null default '',
   epura08a             nvarchar(20)         not null default '',
   epura08b             nvarchar(20)         not null default '',
   epura08c             nvarchar(20)         not null default '',
   epura09              nvarchar(20)         not null default '',
   epura11a             datetime             not null default CONVERT(DATETIME,0),
   epura11b             nvarchar(80)         not null default '',
   epura13a             nvarchar(6)          not null default '',
   epura13b             nvarchar(80)         not null default '',
   epura13c             int                  not null default 0,
   epura13d             numeric(9,5)         not null default 0,
   epura13e             int                  not null default 0,
   epura13f             numeric(9,5)         not null default 0,
   epura14              nvarchar(80)         not null default '',
   epura15              nvarchar(2)          not null default '',
   epura19a             nvarchar(1)          not null default '',
   epura19b             nvarchar(10)         not null default '',
   epura20a             nvarchar(1)          not null default '',
   epura20b             nvarchar(10)         not null default '',
   epura20c             nvarchar(6)          not null default '',
   epura20d             uniqueidentifier     not null,
   epura20e             nvarchar(80)         not null default '',
   wh_no                nvarchar(4)          not null default '',
   epura21              nvarchar(10)         not null default '',
   epura21a             nvarchar(1)          not null default '',
   epura21b             nvarchar(10)         not null default '',
   epura21c             nvarchar(1)          not null default '',
   epura23b             nvarchar(6)          not null default '',
   epura23c             nvarchar(6)          not null default '',
   doc_dig1             int                  not null default 0,
   doc_dig2             int                  not null default 0,
   doc_dig3             int                  not null default 0,
   comp_dig1            int                  not null default 0,
   comp_dig2            int                  not null default 0,
   comp_dig3            int                  not null default 0,
   epura24a             nvarchar(1)          not null default '',
   epura24b             numeric(9,5)         not null default 0,
   epura24c             nvarchar(1)          not null default '',
   epura25a             nvarchar(7)          not null default '',
   epura25b             nvarchar(27)         not null default '',
   epura26              numeric(9,5)         not null default 0,
   epura32              numeric(19,5)        not null default 0,
   epura33              numeric(19,5)        not null default 0,
   epura34              numeric(19,5)        not null default 0,
   epura35              numeric(19,5)        not null default 0,
   epura37              numeric(19,5)        not null default 0,
   epura38              numeric(19,5)        not null default 0,
   epura39              numeric(19,5)        not null default 0,
   epura40              numeric(19,5)        not null default 0,
   epura41              numeric(19,5)        not null default 0,
   epura42              numeric(19,5)        not null default 0,
   epura43              numeric(19,5)        not null default 0,
   epura44              numeric(19,5)        not null default 0,
   epura45a             nvarchar(1)          not null default '',
   epura45b             datetime             not null default CONVERT(DATETIME,0),
   epura46a             nvarchar(1)          not null default '',
   epura46b             datetime             not null default CONVERT(DATETIME,0),
   epura47              int                  not null default 0,
   user_text1           nvarchar(20)         not null default '',
   user_text2           nvarchar(20)         not null default '',
   user_text3           nvarchar(20)         not null default '',
   user_text4           nvarchar(20)         not null default '',
   user_text5           nvarchar(20)         not null default '',
   user_num1            numeric(19,5)        not null default 0,
   user_num2            numeric(19,5)        not null default 0,
   user_num3            numeric(19,5)        not null default 0,
   user_num4            numeric(19,5)        not null default 0,
   user_num5            numeric(19,5)        not null default 0,
   epura55              int                  not null default 0,
   epura56a             nvarchar(1)          not null default '',
   epura56b             datetime             not null default CONVERT(DATETIME,0),
   epura57a             nvarchar(1)          not null default '',
   epura57b             datetime             not null default CONVERT(DATETIME,0),
   epura58a             nvarchar(1)          not null default '',
   epura58b             datetime             not null default CONVERT(DATETIME,0),
   epura61              datetime             not null default CONVERT(DATETIME,0),
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'epur001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura02'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據日期;單據日期',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單別;合約單別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '合約單號;合約單號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'epur001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'epur001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'epur001', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura04b'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號(int);來源單號(int)',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura04c'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號產生方式;來源單號產生方式',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura04d'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單別;首階單別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura05a'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號;首階單號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura05b'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號(int);首階單號(int)',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura05c'
go

execute sp_addextendedproperty 'MS_Description', 
   '首階單號產生方式;首階單號產生方式',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura05d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡人代碼;聯絡人代碼',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡對象;聯絡對象',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話一;聯絡電話一',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06b'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡電話二;聯絡電話二',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06c'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡傳真;聯絡傳真',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06d'
go

execute sp_addextendedproperty 'MS_Description', 
   '聯絡email;聯絡email',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura06e'
go

execute sp_addextendedproperty 'MS_Description', 
   '對方單號;對方單號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura07'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura08a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura08b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura08c'
go

execute sp_addextendedproperty 'MS_Description', 
   '專案代號;專案代號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura09'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計交貨日;預計交貨日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura11a'
go

execute sp_addextendedproperty 'MS_Description', 
   '預計交貨日描述;預計交貨日描述',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura11b'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment code;payment code',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13a'
go

execute sp_addextendedproperty 'MS_Description', 
   'payment desc.;payment desc.',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13b'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)幾天內;現金扣%: (1)幾天內',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13c'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (1)扣幾%;現金扣%: (1)扣幾%',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13d'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)幾天內;現金扣%: (2)幾天內',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13e'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金扣%: (2)扣幾%;現金扣%: (2)扣幾%',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura13f'
go

execute sp_addextendedproperty 'MS_Description', 
   'shipment 描述;shipment 描述',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura14'
go

execute sp_addextendedproperty 'MS_Description', 
   '嘜頭編號;嘜頭編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura15'
go

execute sp_addextendedproperty 'MS_Description', 
   '付款對象別;付款對象別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura19a'
go

execute sp_addextendedproperty 'MS_Description', 
   '付款對象編號;付款對象編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura19b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象別;交貨地點對象別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura20a'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點對象編號;交貨地點對象編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點序號;交貨地點序號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura20c'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點ID;交貨地點ID',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura20d'
go

execute sp_addextendedproperty 'MS_Description', 
   '交貨地點描述;交貨地點描述',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura20e'
go

execute sp_addextendedproperty 'MS_Description', 
   '預設交貨倉庫編號;預設交貨倉庫編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'wh_no'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU轉單方案;OBU轉單方案',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura21'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源對象別;來源對象別',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura21a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源對象編號;來源對象編號',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura21b'
go

execute sp_addextendedproperty 'MS_Description', 
   'OBU拋轉產生標記;OBU拋轉產生標記',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura21c'
go

execute sp_addextendedproperty 'MS_Description', 
   '重量單位;重量單位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura23b'
go

execute sp_addextendedproperty 'MS_Description', 
   '體積單位;體積單位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura23c'
go

execute sp_addextendedproperty 'MS_Description', 
   '單價小數位;單價小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '小計小數位;小計小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '總計小數位;總計小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣單價小數位;換算公司幣單價小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'comp_dig1'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣小計小數位;換算公司幣小計小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'comp_dig2'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算公司幣總計小數位;換算公司幣總計小數位',
   'schema', 'dbo', 'table', 'epur001', 'column', 'comp_dig3'
go

execute sp_addextendedproperty 'MS_Description', 
   '啟動取位設定;啟動取位設定',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura24a'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位設定基數;取位設定基數',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura24b'
go

execute sp_addextendedproperty 'MS_Description', 
   '取位不整除;取位不整除',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura24c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Code;Price Term Code',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura25a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Desc;Price Term Desc',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura25b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Commision%;Commision%',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura26'
go

execute sp_addextendedproperty 'MS_Description', 
   '總件數;總件數',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura32'
go

execute sp_addextendedproperty 'MS_Description', 
   '總數量;總數量',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura33'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total G.W.(KG);Total G.W.(KG)',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura34'
go

execute sp_addextendedproperty 'MS_Description', 
   'Total Measm''t(Cu''ft);Total Measm''t(Cu''ft)',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura35'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品未稅總額;產品未稅總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura37'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品含稅總額;產品含稅總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura38'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款未稅總額;加扣款未稅總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura39'
go

execute sp_addextendedproperty 'MS_Description', 
   '加扣款含稅總額;加扣款含稅總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura40'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金總額;稅金總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura41'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品文件價總額;產品文件價總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura42'
go

execute sp_addextendedproperty 'MS_Description', 
   '預估佣金總額;預估佣金總額',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura43'
go

execute sp_addextendedproperty 'MS_Description', 
   '應付訂金總額(採購單幣別);應付訂金總額(採購單幣別)',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura44'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1選中;追蹤項目1選中',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura45a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目1;追蹤項目1',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura45b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2選中;追蹤項目2選中',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura46a'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤項目2;追蹤項目2',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura46b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Revised 修改次數;Revised 修改次數',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura47'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值一;自定義文字欄值一',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值二;自定義文字欄值二',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值三;自定義文字欄值三',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值四;自定義文字欄值四',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義文字欄值五;自定義文字欄值五',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值一;自定義數值欄值一',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值二;自定義數值欄值二',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值三;自定義數值欄值三',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值四;自定義數值欄值四',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定義數值欄值五;自定義數值欄值五',
   'schema', 'dbo', 'table', 'epur001', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '單據已列印次數;單據已列印次數',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura55'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤跟催日否;追蹤跟催日否',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura56a'
go

execute sp_addextendedproperty 'MS_Description', 
   '跟催日;跟催日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura56b'
go

execute sp_addextendedproperty 'MS_Description', 
   '追蹤廠商簽回日否;追蹤廠商簽回日否',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura57a'
go

execute sp_addextendedproperty 'MS_Description', 
   '廠商簽回日;廠商簽回日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura57b'
go

execute sp_addextendedproperty 'MS_Description', 
   'P/I回應日選中;P/I回應日選中',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura58a'
go

execute sp_addextendedproperty 'MS_Description', 
   'P/I回應日;P/I回應日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura58b'
go

execute sp_addextendedproperty 'MS_Description', 
   '立帳日期;立帳日期',
   'schema', 'dbo', 'table', 'epur001', 'column', 'epura61'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'epur001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'epur001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'epur001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'epur001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'epur001', 'column', 'modify_date'
go
alter table dbo.epur001
   add constraint PK_EPUR001 primary key (epura01a, epura01b)
      on "PRIMARY"
GO

insert into dbo.epur001 (recid, epura01a, epura01b, doc_comp, epura02, doc_date, biz_type, biz_no, epura03a, epura03b, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, epura04a, epura04b, epura04c, epura04d, epura05a, epura05b, epura05c, epura05d, epura06, epura06a, epura06b, epura06c, epura06d, epura06e, epura07, epura08a, epura08b, epura08c, epura09, epura11a, epura11b, epura13a, epura13b, epura13c, epura13d, epura13e, epura13f, epura14, epura15, epura19a, epura19b, epura20a, epura20b, epura20c, epura20d, epura20e, wh_no, epura21, epura21a, epura21b, epura21c,epura23b,epura23c, doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, epura24a, epura24b, epura24c, epura25a, epura25b, epura26, epura32, epura33, epura34, epura35, epura37, epura38, epura39, epura40, epura41, epura42, epura43, epura44, epura45a, epura45b, epura46a, epura46b, epura47, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, epura55, epura56a, epura56b, epura57a, epura57b, epura58a, epura58b, epura61, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, epura01a, epura01b, doc_comp, epura02, doc_date, biz_type, biz_no, epura03a, epura03b, doc_staff, staff_group, doc_curr, comp_exrate, sys_exrate, tax_type, tax_rate, epura04a, epura04b, epura04c, epura04d, epura05a, epura05b, epura05c, epura05d, epura06, epura06a, epura06b, epura06c, epura06d, epura06e, epura07, epura08a, epura08b, epura08c, epura09, epura11a, epura11b, epura13a, epura13b, epura13c, epura13d, epura13e, epura13f, epura14, epura15, epura19a, epura19b, epura20a, epura20b, epura20c, epura20d, epura20e, wh_no, epura21, epura21a, epura21b, epura21c,N'Kg',N'Cu''ft' ,doc_dig1, doc_dig2, doc_dig3, comp_dig1, comp_dig2, comp_dig3, epura24a, epura24b, epura24c, epura25a, epura25b, epura26, epura32, epura33, epura34, epura35, epura37, epura38, epura39, epura40, epura41, epura42, epura43, epura44, epura45a, epura45b, epura46a, epura46b, epura47, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, epura55, epura56a, epura56b, epura57a, epura57b, epura58a, epura58b, epura61, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_epur001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_epur001'))
drop table dbo.tmp_epur001
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/8/17 上午 09:05:46                        */
/*==============================================================*/

alter table dbo.nsch003
   drop constraint PK_NSCH003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_nsch003'))
drop table dbo.tmp_nsch003
go

execute sp_rename nsch003, tmp_nsch003
go

/*==============================================================*/
/* Table: nsch003                                               */
/*==============================================================*/
create table dbo.nsch003 (
   recid                uniqueidentifier     not null,
   pk_id                int                  identity,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   cycle_area           int                  not null default 0,
   cycle_start          nvarchar(8)          not null default '',
   cycle_end            nvarchar(8)          not null default '',
   cycle_times          int                  not null default 0,
   cycle_mode           int                  not null default 0,
   day_period           int                  not null default 0,
   week_period          int                  not null default 0,
   week_sunday          nvarchar(1)          not null default '',
   week_monday          nvarchar(1)          not null default '',
   week_tuesday         nvarchar(1)          not null default '',
   week_wednesday       nvarchar(1)          not null default '',
   week_thursday        nvarchar(1)          not null default '',
   week_friday          nvarchar(1)          not null default '',
   week_saturday        nvarchar(1)          not null default '',
   month_mode           int                  not null default 0,
   m_day_period         int                  not null default 0,
   m_day_date           int                  not null default 0,
   m_week_period        int                  not null default 0,
   m_week_index         int                  not null default 0,
   m_week_date          int                  not null default 0,
   year_mode            int                  not null default 0,
   y_day_month          int                  not null default 0,
   y_day_date           int                  not null default 0,
   y_week_month         int                  not null default 0,
   y_week_index         int                  not null default 0,
   y_week_date          int                  not null default 0,
   sch_days             int                  not null default 0,
   time_start           nvarchar(6)          not null default '',
   time_end             nvarchar(6)          not null default '',
   is_allday            int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '週期性設定ID;週期性設定ID',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'pk_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人用戶編號;建檔人用戶編號',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人用戶編號;最後修改人用戶編號',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環範圍模式;循環範圍模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_area'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環開始日期;循環開始日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環結束日期;循環結束日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '循環次數;循環次數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_times'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始日期循環模式;開始日期循環模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'cycle_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每天模式"的循環間隔天數;"每天模式"的循環間隔天數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'day_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每週模式"的循環間隔週數;"每週模式"的循環間隔週數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期日";"每週模式"的"星期日',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_sunday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期一";"每週模式"的"星期一',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_monday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期二";"每週模式"的"星期二',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_tuesday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期三";"每週模式"的"星期三',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_wednesday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期四";"每週模式"的"星期四',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_thursday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期五";"每週模式"的"星期五',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_friday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每週模式"的"星期六";"每週模式"的"星期六',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'week_saturday'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式";"每月模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'month_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份日期"的循環間隔月數;"每月模式-指定月份日期"的循環間隔月數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_day_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份日期"的日期;"每月模式-指定月份日期"的日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_day_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每月模式-指定月份星期"的循環間隔月數;"每月模式-指定月份星期"的循環間隔月數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_period'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式-指定月份星期的第幾週;每月模式-指定月份星期的第幾週',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_index'
go

execute sp_addextendedproperty 'MS_Description', 
   '每月模式-指定月份星期的星期幾;每月模式-指定月份星期的星期幾',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'm_week_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '每年模式";"每年模式',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'year_mode'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份日期"的月份;"每年模式-指定月份日期"的月份',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_day_month'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份日期"的日期;"每年模式-指定月份日期"的日期',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_day_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份星期"的月份;"每年模式-指定月份星期"的月份',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_month'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份"星期的第幾週;"每年模式-指定月份"星期的第幾週',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_index'
go

execute sp_addextendedproperty 'MS_Description', 
   '"每年模式-指定月份"星期的星期幾;"每年模式-指定月份"星期的星期幾',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'y_week_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程天數;行程天數',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'sch_days'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程開始時間;行程開始時間',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'time_start'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程結束時間;行程結束時間',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'time_end'
go

execute sp_addextendedproperty 'MS_Description', 
   '行程時間是/否為全日;行程時間是/否為全日',
   'schema', 'dbo', 'table', 'nsch003', 'column', 'is_allday'
go

alter table dbo.nsch003
   add constraint PK_NSCH003 primary key (pk_id)
      on "PRIMARY"
go

set identity_insert dbo.nsch003 on
go

insert into dbo.nsch003 (recid, pk_id, create_user, create_date, modify_user, modify_date, cycle_area, cycle_start, cycle_end, cycle_times, cycle_mode, day_period, week_period, week_sunday, week_monday, week_tuesday, week_wednesday, week_thursday, week_friday, week_saturday, month_mode, m_day_period, m_day_date, m_week_period, m_week_index, m_week_date, year_mode, y_day_month, y_day_date, y_week_month, y_week_index, y_week_date, sch_days, time_start, time_end, is_allday)
select recid, pk_id, create_user, create_date, modify_user, modify_date, cycle_area, cycle_start, cycle_end, cycle_times, cycle_mode, day_period, week_period, week_sunday, week_monday, week_tuesday, week_wednesday, week_thursday, week_friday, week_saturday, month_mode, m_day_period, m_day_date, m_week_period, m_week_index, m_week_date, year_mode, y_day_month, y_day_date, y_week_month, y_week_index, y_week_date, sch_days, time_start, time_end, is_allday
from dbo.tmp_nsch003
go

set identity_insert dbo.nsch003 off
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_nsch003'))
drop table dbo.tmp_nsch003
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/5/20 上午 11:12:11                        */
/*==============================================================*/

declare @sql varchar(200)
IF EXISTS(SELECT * FROM sys.columns WHERE [object_id] = OBJECT_ID('dbo.bbus002') AND [name] = 'bbusb39f')
BEGIN
	set @sql = 'alter table bbus002 drop constraint '+ (select o.name  from syscolumns c,sysobjects o where c.id  = object_id('bbus002') and c.name = 'bbusb39f'  and c.cdefault = o.id)
	exec(@sql)
	alter table dbo.bbus002
	   drop column bbusb39f
END
go

alter table dbo.bbus003
   drop constraint PK_BBUS003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bbus003'))
drop table dbo.tmp_bbus003
go

execute sp_rename bbus003, tmp_bbus003
go

/*==============================================================*/
/* Table: bbus003                                               */
/*==============================================================*/
create table dbo.bbus003 (
   recid                uniqueidentifier     not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   bbusc02              nvarchar(80)         not null default '',
   bbusc03              nvarchar(16)         not null default '',
   bbusc04              datetime             not null default CONVERT(DATETIME,0),
   doc_staff            nvarchar(10)         not null default '',
   bbusc06              nvarchar(1)          not null default '',
   bbusc07              datetime             not null default CONVERT(DATETIME,0),
   bbusc08              nvarchar(30)         not null default '',
   bbusc09              nvarchar(80)         not null default '',
   bbusc10              nvarchar(80)         not null default '',
   bbusc11              nvarchar(10)         not null default '',
   bbusc12              nvarchar(10)         not null default '',
   bbusc13              nvarchar(10)         not null default '',
   bbusc14              nvarchar(10)         not null default '',
   bbusc15a             nvarchar(10)         not null default '',
   bbusc15b             nvarchar(10)         not null default '',
   bbusc15c             nvarchar(10)         not null default '',
   bbusc16              nvarchar(5)          not null default '',
   bbusc17              nvarchar(1)          not null default '',
   bbusc18              nvarchar(1)          not null default '',
   bbusc19              nvarchar(1)          not null default '',
   bbusc20              nvarchar(1)          not null default '',
   bbusc21              nvarchar(10)         not null default '',
   bbusc22              nvarchar(10)         not null default '',
   bbusc23              int                  not null default 0,
   bbusc24              int                  not null default 0,
   bbusc25              nvarchar(6)          not null default '',
   bbusc26              nvarchar(80)         not null default '',
   bbusc31              nvarchar(1)          not null default '',
   bbusc32              nvarchar(2)          not null default '',
   bbusc33              nvarchar(10)         not null default '',
   bbusc34              nvarchar(10)         not null default '',
   bbusc35              nvarchar(10)         not null default '',
   bbusc36              nvarchar(10)         not null default '',
   bbusc37              nvarchar(6)          not null default '',
   bbusc38              nvarchar(30)         not null default '',
   bbusc39a             nvarchar(6)          not null default '',
   bbusc39b             nvarchar(6)          not null default '',
   bbusc39c             nvarchar(6)          not null default '',
   bbusc39d             nvarchar(6)          not null default '',
   bbusc39e             nvarchar(6)          not null default '',
   bbusc39f             nvarchar(6)          not null default '',
   bbusc40              nvarchar(6)          not null default '',
   bbusc53a             nvarchar(2)          not null default '',
   bbusc53b             nvarchar(16)         not null default '',
   bbusc54              nvarchar(20)         not null default '',
   bbusc55              nvarchar(1)          not null default '',
   bbusc56a             numeric(9,5)         not null default 0,
   bbusc56b             numeric(9,5)         not null default 0,
   user_text1           nvarchar(30)         not null default '',
   user_text2           nvarchar(30)         not null default '',
   user_text3           nvarchar(30)         not null default '',
   user_text4           nvarchar(30)         not null default '',
   user_text5           nvarchar(30)         not null default '',
   user_num1            numeric(19,8)        not null default 0,
   user_num2            numeric(19,8)        not null default 0,
   user_num3            numeric(19,8)        not null default 0,
   user_num4            numeric(19,8)        not null default 0,
   user_num5            numeric(19,8)        not null default 0,
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'RecID;RecID',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '區別碼;區別碼',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶/廠商 編號;客戶/廠商 編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司名稱;公司名稱',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '簡稱;簡稱',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '起始往來日;起始往來日',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要承辦人;主要承辦人',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '暫停往來否;暫停往來否',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '暫停往來否的最後更動日;暫停往來否的最後更動日',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '負責人;負責人',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc08'
go

execute sp_addextendedproperty 'MS_Description', 
   'E-Mail;E-Mail',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '網頁網址;網頁網址',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '地區;地區',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '分類;分類',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '等級;等級',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格等級;價格等級',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc14'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定等級一;自定等級一',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc15a'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定等級二;自定等級二',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc15b'
go

execute sp_addextendedproperty 'MS_Description', 
   '自定等級三;自定等級三',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc15c'
go

execute sp_addextendedproperty 'MS_Description', 
   '常用幣別;常用幣別',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc16'
go

execute sp_addextendedproperty 'MS_Description', 
   '交易預設稅別;交易預設稅別',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc17'
go

execute sp_addextendedproperty 'MS_Description', 
   '有不同的交貨客戶否;有不同的交貨客戶否',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc18'
go

execute sp_addextendedproperty 'MS_Description', 
   '允許分批交/進貨否;允許分批交/進貨否',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc19'
go

execute sp_addextendedproperty 'MS_Description', 
   '完單收/付款否;完單收/付款否',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc20'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計對象;統計對象',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc21'
go

execute sp_addextendedproperty 'MS_Description', 
   '收/付款對象;收/付款對象',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc22'
go

execute sp_addextendedproperty 'MS_Description', 
   '應收/付帳款截止日(每月);應收/付帳款截止日(每月)',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc23'
go

execute sp_addextendedproperty 'MS_Description', 
   '請款截止日(每月);請款截止日(每月)',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc24'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款方式的代碼;收款方式的代碼',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc25'
go

execute sp_addextendedproperty 'MS_Description', 
   '收款方式的說明;收款方式的說明',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc26'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票開立方式;發票開立方式',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc31'
go

execute sp_addextendedproperty 'MS_Description', 
   '發票聯式;發票聯式',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc32'
go

execute sp_addextendedproperty 'MS_Description', 
   'Agent;Agent',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc33'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc34'
go

execute sp_addextendedproperty 'MS_Description', 
   'Notify;Notify',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc35'
go

execute sp_addextendedproperty 'MS_Description', 
   'Forwarder;Forwarder',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc36'
go

execute sp_addextendedproperty 'MS_Description', 
   '常用的 Price Term Code;常用的 Price Term Code',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc37'
go

execute sp_addextendedproperty 'MS_Description', 
   '常用的 Price Term Desc.;常用的 Price Term Desc',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc38'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-業務的編號;主要連絡人-業務的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39a'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-船務的編號;主要連絡人-船務的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39b'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-倉管的編號;主要連絡人-倉管的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39c'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-採購的編號;主要連絡人-採購的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39d'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-帳款的編號;主要連絡人-帳款的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39e'
go

execute sp_addextendedproperty 'MS_Description', 
   '主要連絡人-生管的編號;主要連絡人-生管的編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc39f'
go

execute sp_addextendedproperty 'MS_Description', 
   '常用送貨地址;常用送貨地址',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc40'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料來源之單別;資料來源之單別',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc53a'
go

execute sp_addextendedproperty 'MS_Description', 
   '資料來源之編號;資料來源之編號',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc53b'
go

execute sp_addextendedproperty 'MS_Description', 
   '國別碼;國別碼',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc54'
go

execute sp_addextendedproperty 'MS_Description', 
   '依本檔設增值/營業稅率否;依本檔設增值/營業稅率否',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc55'
go

execute sp_addextendedproperty 'MS_Description', 
   '增值性稅率(國稅局);增值性稅率(國稅局)',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc56a'
go

execute sp_addextendedproperty 'MS_Description', 
   '營業性稅率(地稅局);營業性稅率(地稅局)',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'bbusc56b'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄一;文字自定欄一',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_text1'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄二;文字自定欄二',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_text2'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄三;文字自定欄三',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_text3'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄四;文字自定欄四',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_text4'
go

execute sp_addextendedproperty 'MS_Description', 
   '文字自定欄五;文字自定欄五',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_text5'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄一;數字自定欄一',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_num1'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄二;數字自定欄二',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_num2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄三;數字自定欄三',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_num3'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄四;數字自定欄四',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_num4'
go

execute sp_addextendedproperty 'MS_Description', 
   '數字自定欄五;數字自定欄五',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'user_num5'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '狀態(覆核、作廢否);狀態(覆核、作廢否)',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'bbus003', 'column', 'last_date'
go

alter table dbo.bbus003
   add constraint PK_BBUS003 primary key (biz_type, biz_no)
      on "PRIMARY"
go

insert into dbo.bbus003 (recid, biz_type, biz_no, bbusc02, bbusc03, bbusc04, doc_staff, bbusc06, bbusc07, bbusc08, bbusc09, bbusc10, bbusc11, bbusc12, bbusc13, bbusc14, bbusc15a, bbusc15b, bbusc15c, bbusc16, bbusc17, bbusc18, bbusc19, bbusc20, bbusc21, bbusc22, bbusc23, bbusc24, bbusc25, bbusc26, bbusc31, bbusc32, bbusc33, bbusc34, bbusc35, bbusc36, bbusc37, bbusc38, bbusc39a, bbusc39b, bbusc39c, bbusc39d, bbusc39e, bbusc40, bbusc53a, bbusc53b, bbusc54, bbusc55, bbusc56a, bbusc56b, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date)
select recid, biz_type, biz_no, bbusc02, bbusc03, bbusc04, doc_staff, bbusc06, bbusc07, bbusc08, bbusc09, bbusc10, bbusc11, bbusc12, bbusc13, bbusc14, bbusc15a, bbusc15b, bbusc15c, bbusc16, bbusc17, bbusc18, bbusc19, bbusc20, bbusc21, bbusc22, bbusc23, bbusc24, bbusc25, bbusc26, bbusc31, bbusc32, bbusc33, bbusc34, bbusc35, bbusc36, bbusc37, bbusc38, bbusc39a, bbusc39b, bbusc39c, bbusc39d, bbusc39e, bbusc40, bbusc53a, bbusc53b, bbusc54, bbusc55, bbusc56a, bbusc56b, user_text1, user_text2, user_text3, user_text4, user_text5, user_num1, user_num2, user_num3, user_num4, user_num5, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date
from dbo.tmp_bbus003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_bbus003'))
drop table dbo.tmp_bbus003
go


/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/8/21 上午 09:02:20                        */
/*==============================================================*/

alter table dbo.arpt001
   drop constraint PK_ARPT001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt001'))
drop table dbo.tmp_arpt001
go

execute sp_rename arpt001, tmp_arpt001
go

/*==============================================================*/
/* Table: arpt001                                               */
/*==============================================================*/
create table dbo.arpt001 (
   recid                uniqueidentifier     not null,
   arpta01              nvarchar(10)         not null,
   arpta02              int                  identity,
   arpta03              nvarchar(3)          not null default '',
   arpta04              nvarchar(10)         not null default '',
   arpta05              nvarchar(3)          not null default '',
   arpta06              nvarchar(256)        not null default '',
   arpta07              datetime             not null default CONVERT(DATETIME,0),
   arpta08              nvarchar(40)         not null default '',
   arpta10              nvarchar(10)         not null default '',
   arpta11              nvarchar(1)          not null default '',
   arpta12              datetime             not null default CONVERT(DATETIME,0),
   arpta13              datetime             not null default CONVERT(DATETIME,0),
   arpta14a             nvarchar(3)          not null default '',
   arpta14b             nvarchar(256)        not null default '',
   arpta15              datetime             not null default CONVERT(DATETIME,0),
   arpta16              varbinary(max)       null,
   arpta17              int                  not null default 0,
   arpta18              nvarchar(10)         not null default '',
   page_num             int                  not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta01'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta02'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄公司;印表登錄公司',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta03'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄用戶;印表登錄用戶',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta04'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表軟體Portal;印表軟體Portal',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta05'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表Client ID;印表Client ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta06'
go

execute sp_addextendedproperty 'MS_Description', 
   '執行時間;執行時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta07'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式代號;印表格式代號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta08'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表格式版本號;印表格式版本號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta10'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表方式;印表方式',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta11'
go

execute sp_addextendedproperty 'MS_Description', 
   '開始產生報表時間;開始產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta12'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成產生報表時間;完成產生報表時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta13'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態代碼;完成狀態代碼',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14a'
go

execute sp_addextendedproperty 'MS_Description', 
   '完成狀態描述;完成狀態描述',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta14b'
go

execute sp_addextendedproperty 'MS_Description', 
   '排程創建時間;排程創建時間',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta15'
go

execute sp_addextendedproperty 'MS_Description', 
   '進階選中記錄;進階選中記錄',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta16'
go

execute sp_addextendedproperty 'MS_Description', 
   '排程印表結果文件ID;排程印表結果文件ID',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta17'
go

execute sp_addextendedproperty 'MS_Description', 
   '印表登錄角色;印表登錄角色',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'arpta18'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面序號;頁面序號',
   'schema', 'dbo', 'table', 'arpt001', 'column', 'page_num'
go

set identity_insert dbo.arpt001 on
go

insert into dbo.arpt001 (recid, arpta01, arpta02, arpta03, arpta04, arpta05, arpta06, arpta07, arpta08, arpta10, arpta11, arpta12, arpta13, arpta14a, arpta14b, arpta15, arpta16, arpta17, arpta18)
select recid, arpta01, arpta02, arpta03, arpta04, arpta05, arpta06, arpta07, arpta08, arpta10, arpta11, arpta12, arpta13, arpta14a, arpta14b, arpta15, arpta16, arpta17, arpta18
from dbo.tmp_arpt001
go

set identity_insert dbo.arpt001 off
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt001'))
drop table dbo.tmp_arpt001
go

alter table dbo.arpt001
   add constraint PK_ARPT001 primary key (arpta01, arpta02)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/8/20 下午 04:38:01                        */
/*==============================================================*/
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.asys002') and o.name = 'FK_ASYS002_REFERENCE_ASYS001')
alter table dbo.asys002
   drop constraint FK_ASYS002_REFERENCE_ASYS001
go


alter table dbo.arpt003
   drop constraint PK_ARPT003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

execute sp_rename arpt003, tmp_arpt003
go
/*==============================================================*/
/* Table: arpt003                                               */
/*==============================================================*/
create table dbo.arpt003 (
   recid                uniqueidentifier     not null,
   portal_id            nvarchar(3)          not null,
   arptc01              nvarchar(10)         not null,
   arptc02              nvarchar(10)         not null,
   page_num             int                  not null default 0,
   arptc03              nvarchar(1)          not null default '',
   arptc04              nvarchar(10)         not null,
   num                  float                not null default 0,
   arptc05              nvarchar(40)         not null default '',
   arptc06              varbinary(max)       null,
   arptc07              nvarchar(20)         not null default '',
   arptc08              nvarchar(2)          not null default '',
   arptc09              nvarchar(1)          not null default '',
   arptc10              nvarchar(256)        not null default '',
   arptc11              nvarchar(1)          not null default '',
   arptc12              nvarchar(5)          not null default '',
   arptc13              nvarchar(256)        not null default '',
   arptc14              datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '區分產品別;區分產品別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'portal_id'
go

execute sp_addextendedproperty 'MS_Description', 
   '報表程式代號;報表程式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc01'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式代號;格式代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc02'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面序號;頁面序號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'page_num'
go

execute sp_addextendedproperty 'MS_Description', 
   '多語言別;多語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '版本代號;版本代號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式名稱;格式名稱',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc05'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式設定檔;格式設定檔',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc06'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔用戶;建檔用戶',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc07'
go

execute sp_addextendedproperty 'MS_Description', 
   '應用狀態;應用狀態',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc08'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入標誌;載入標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc09'
go

execute sp_addextendedproperty 'MS_Description', 
   '數據來源方案;數據來源方案',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統標誌;系統標誌',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '載入語言別;載入語言別',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件名;格式檔文件名',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '格式檔文件日期;格式檔文件日期',
   'schema', 'dbo', 'table', 'arpt003', 'column', 'arptc14'
go

insert into dbo.arpt003 (recid, portal_id, arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12, arptc13, arptc14)
select recid, portal_id, arptc01, arptc02, arptc03, arptc04, num, arptc05, arptc06, arptc07, arptc08, arptc09, arptc10, arptc11, arptc12, arptc13, arptc14
from dbo.tmp_arpt003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_arpt003'))
drop table dbo.tmp_arpt003
go

alter table dbo.arpt003
   add constraint PK_ARPT003 primary key (portal_id, arptc01, arptc02, arptc04)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_arpt003_1                                         */
/*==============================================================*/
create index idx_arpt003_1 on dbo.arpt003 (
portal_id ASC,
arptc01 ASC,
page_num ASC,
arptc02 ASC,
arptc04 ASC
)
on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.asys002'))
drop table dbo.asys002
go

/*==============================================================*/
/* Table: asys002                                               */
/*==============================================================*/
create table dbo.asys002 (
   recid                uniqueidentifier     not null,
   asysb01              nvarchar(10)         not null,
   page_num             int                  not null,
   asysb02a             nvarchar(30)         not null default '',
   asysb02b             nvarchar(30)         not null default '',
   asysb02c             nvarchar(30)         not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'asys002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '程式代號;程式代號',
   'schema', 'dbo', 'table', 'asys002', 'column', 'asysb01'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面序號;頁面序號',
   'schema', 'dbo', 'table', 'asys002', 'column', 'page_num'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面描述(繁體);頁面描述(繁體)',
   'schema', 'dbo', 'table', 'asys002', 'column', 'asysb02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面描述(英文);頁面描述(英文)',
   'schema', 'dbo', 'table', 'asys002', 'column', 'asysb02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '頁面描述(簡體);頁面描述(簡體)',
   'schema', 'dbo', 'table', 'asys002', 'column', 'asysb02c'
go

alter table dbo.asys002
   add constraint PK_ASYS002 primary key (asysb01, page_num)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.asys016'))
drop table dbo.asys016
go

/*==============================================================*/
/* Table: asys016                                               */
/*==============================================================*/
create table dbo.asys016 (
   recid                uniqueidentifier     not null,
   asysp01              nvarchar(3)          not null,
   asysp02              nvarchar(10)         not null,
   asysp03a             nvarchar(1)          not null default '',
   asysp03b             nvarchar(1)          not null default '',
   asysp03c             nvarchar(1)          not null default '',
   asysp03d             nvarchar(1)          not null default '',
   asysp03e             nvarchar(1)          not null default '',
   asysp03f             nvarchar(1)          not null default '',
   asysp03g             nvarchar(1)          not null default '',
   asysp03h             nvarchar(1)          not null default '',
   asysp03i             nvarchar(1)          not null default '',
   asysp03j             nvarchar(1)          not null default '',
   asysp04a             nvarchar(1)          not null default '',
   asysp04b             nvarchar(1)          not null default '',
   asysp04c             nvarchar(1)          not null default '',
   asysp04d             nvarchar(1)          not null default '',
   asysp04e             nvarchar(1)          not null default '',
   asysp04f             nvarchar(1)          not null default '',
   asysp04g             nvarchar(1)          not null default '',
   asysp04h             nvarchar(1)          not null default '',
   asysp04i             nvarchar(1)          not null default '',
   asysp04j             nvarchar(1)          not null default ''
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'asys016', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp01'
go

execute sp_addextendedproperty 'MS_Description', 
   '代碼;代碼',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp02'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式1 - 資料生效;已覆核控管方式1 - 資料生效',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式2;已覆核控管方式2',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式3;已覆核控管方式3',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03c'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式4;已覆核控管方式4',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03d'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式5;已覆核控管方式5',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03e'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式6;已覆核控管方式6',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03f'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式7;已覆核控管方式7',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03g'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式8;已覆核控管方式8',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03h'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式9;已覆核控管方式9',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03i'
go

execute sp_addextendedproperty 'MS_Description', 
   '已覆核控管方式10;已覆核控管方式10',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp03j'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式1;未覆核控管方式1',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04a'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式2;未覆核控管方式2',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04b'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式3;未覆核控管方式3',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04c'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式4;未覆核控管方式4',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04d'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式5;未覆核控管方式5',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04e'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式6;未覆核控管方式6',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04f'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式7;未覆核控管方式7',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04g'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式8;未覆核控管方式8',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04h'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式9;未覆核控管方式9',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04i'
go

execute sp_addextendedproperty 'MS_Description', 
   '未覆核控管方式10;未覆核控管方式10',
   'schema', 'dbo', 'table', 'asys016', 'column', 'asysp04j'
go

alter table dbo.asys016
   add constraint PK_ASYS016 primary key (asysp01, asysp02)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta000'))
drop table dbo.lsta000
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta001'))
drop table dbo.lsta001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta002'))
drop table dbo.lsta002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta003'))
drop table dbo.lsta003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta004'))
drop table dbo.lsta004
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta005'))
drop table dbo.lsta005
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta006'))
drop table dbo.lsta006
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta007'))
drop table dbo.lsta007
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta008'))
drop table dbo.lsta008
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta009'))
drop table dbo.lsta009
go

/*==============================================================*/
/* Table: lsta000                                               */
/*==============================================================*/
create table dbo.lsta000 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   doc_staff            nvarchar(10)         not null,
   staff_group          nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 nvarchar(4)          not null,
   doc_curr             nvarchar(6)          not null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門編號;部門編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_curr'
go

alter table dbo.lsta000
   add constraint PK_LSTA000 primary key (doc_comp, biz_type, biz_no, doc_staff, staff_group, item_no, year, doc_curr)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta001                                               */
/*==============================================================*/
create table dbo.lsta001 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'really'
go

alter table dbo.lsta001
   add constraint PK_LSTA001 primary key (doc_comp, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta002                                               */
/*==============================================================*/
create table dbo.lsta002 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   item_no              nvarchar(20)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'really'
go

alter table dbo.lsta002
   add constraint PK_LSTA002 primary key (doc_comp, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta003                                               */
/*==============================================================*/
create table dbo.lsta003 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'really'
go

alter table dbo.lsta003
   add constraint PK_LSTA003 primary key (doc_comp, biz_type, biz_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta004                                               */
/*==============================================================*/
create table dbo.lsta004 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   doc_staff            nvarchar(10)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'really'
go

alter table dbo.lsta004
   add constraint PK_LSTA004 primary key (doc_comp, doc_staff, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta005                                               */
/*==============================================================*/
create table dbo.lsta005 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   staff_group          nvarchar(10)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門別;部門別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'really'
go

alter table dbo.lsta005
   add constraint PK_LSTA005 primary key (doc_comp, staff_group, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta006                                               */
/*==============================================================*/
create table dbo.lsta006 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'really'
go

alter table dbo.lsta006
   add constraint PK_LSTA006 primary key (doc_comp, biz_type, biz_no, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta007                                               */
/*==============================================================*/
create table dbo.lsta007 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   doc_staff            nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'really'
go

alter table dbo.lsta007
   add constraint PK_LSTA007 primary key (doc_comp, doc_staff, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta008                                               */
/*==============================================================*/
create table dbo.lsta008 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   staff_group          nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門別;部門別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'really'
go

alter table dbo.lsta008
   add constraint PK_LSTA008 primary key (doc_comp, staff_group, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta009                                               */
/*==============================================================*/
create table dbo.lsta009 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   year                 nvarchar(4)          not null,
   month                nvarchar(2)          not null,
   doc_curr             nvarchar(5)          not null,
   lstai01              numeric(19,5)        not null default 0,
   lstai02              numeric(19,5)        not null default 0,
   lstai03              numeric(19,5)        not null default 0,
   lstai04              numeric(19,5)        not null default 0,
   lstai05              numeric(19,5)        not null default 0,
   lstai06              numeric(19,5)        not null default 0,
   lstai07              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金統計;現金統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai01'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據統計;票據統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai02'
go

execute sp_addextendedproperty 'MS_Description', 
   '其他統計;其他統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai03'
go

execute sp_addextendedproperty 'MS_Description', 
   '折讓統計;折讓統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai04'
go

execute sp_addextendedproperty 'MS_Description', 
   '抵帳統計;抵帳統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai05'
go

execute sp_addextendedproperty 'MS_Description', 
   '掛帳統計;掛帳統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai06'
go

execute sp_addextendedproperty 'MS_Description', 
   '溢收/付統計;溢收/付統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai07'
go

alter table dbo.lsta009
   add constraint PK_LSTA009 primary key (doc_comp, biz_type, biz_no, year, month, doc_curr)
      on "PRIMARY"
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta000'))
drop table dbo.lsta000
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta001'))
drop table dbo.lsta001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta002'))
drop table dbo.lsta002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta003'))
drop table dbo.lsta003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta004'))
drop table dbo.lsta004
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta005'))
drop table dbo.lsta005
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta006'))
drop table dbo.lsta006
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta007'))
drop table dbo.lsta007
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta008'))
drop table dbo.lsta008
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.lsta009'))
drop table dbo.lsta009
go

/*==============================================================*/
/* Table: lsta000                                               */
/*==============================================================*/
create table dbo.lsta000 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   doc_staff            nvarchar(10)         not null,
   staff_group          nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 int          not null,
   doc_curr             nvarchar(6)          not null
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門編號;部門編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta000', 'column', 'doc_curr'
go

alter table dbo.lsta000
   add constraint PK_LSTA000 primary key (doc_comp, biz_type, biz_no, doc_staff, staff_group, item_no, year, doc_curr)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta001                                               */
/*==============================================================*/
create table dbo.lsta001 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta001', 'column', 'really'
go

alter table dbo.lsta001
   add constraint PK_LSTA001 primary key (doc_comp, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta002                                               */
/*==============================================================*/
create table dbo.lsta002 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   item_no              nvarchar(20)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta002', 'column', 'really'
go

alter table dbo.lsta002
   add constraint PK_LSTA002 primary key (doc_comp, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta003                                               */
/*==============================================================*/
create table dbo.lsta003 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta003', 'column', 'really'
go

alter table dbo.lsta003
   add constraint PK_LSTA003 primary key (doc_comp, biz_type, biz_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta004                                               */
/*==============================================================*/
create table dbo.lsta004 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   doc_staff            nvarchar(10)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta004', 'column', 'really'
go

alter table dbo.lsta004
   add constraint PK_LSTA004 primary key (doc_comp, doc_staff, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta005                                               */
/*==============================================================*/
create table dbo.lsta005 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   staff_group          nvarchar(10)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門別;部門別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta005', 'column', 'really'
go

alter table dbo.lsta005
   add constraint PK_LSTA005 primary key (doc_comp, staff_group, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta006                                               */
/*==============================================================*/
create table dbo.lsta006 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta006', 'column', 'really'
go

alter table dbo.lsta006
   add constraint PK_LSTA006 primary key (doc_comp, biz_type, biz_no, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta007                                               */
/*==============================================================*/
create table dbo.lsta007 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   doc_staff            nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務編號;業務編號',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta007', 'column', 'really'
go

alter table dbo.lsta007
   add constraint PK_LSTA007 primary key (doc_comp, doc_staff, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta008                                               */
/*==============================================================*/
create table dbo.lsta008 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   staff_group          nvarchar(10)         not null,
   item_no              nvarchar(20)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(6)          not null,
   sta_type             nvarchar(5)          not null,
   budget               numeric(19,5)        not null default 0,
   really               numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '部門別;部門別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別/數量單位;幣別/數量單位',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計單別;統計單別',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'sta_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '預算值;預算值',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'budget'
go

execute sp_addextendedproperty 'MS_Description', 
   '實際值;實際值',
   'schema', 'dbo', 'table', 'lsta008', 'column', 'really'
go

alter table dbo.lsta008
   add constraint PK_LSTA008 primary key (doc_comp, staff_group, item_no, year, month, doc_curr, sta_type)
      on "PRIMARY"
go

/*==============================================================*/
/* Table: lsta009                                               */
/*==============================================================*/
create table dbo.lsta009 (
   recid                uniqueidentifier     not null,
   doc_comp             nvarchar(3)          not null,
   biz_type             nvarchar(1)          not null,
   biz_no               nvarchar(10)         not null,
   year                 int          not null,
   month                int          not null,
   doc_curr             nvarchar(5)          not null,
   lstai01              numeric(19,5)        not null default 0,
   lstai02              numeric(19,5)        not null default 0,
   lstai03              numeric(19,5)        not null default 0,
   lstai04              numeric(19,5)        not null default 0,
   lstai05              numeric(19,5)        not null default 0,
   lstai06              numeric(19,5)        not null default 0,
   lstai07              numeric(19,5)        not null default 0
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '統計年度;統計年度',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'year'
go

execute sp_addextendedproperty 'MS_Description', 
   '月份;月份',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'month'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '現金統計;現金統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai01'
go

execute sp_addextendedproperty 'MS_Description', 
   '票據統計;票據統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai02'
go

execute sp_addextendedproperty 'MS_Description', 
   '其他統計;其他統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai03'
go

execute sp_addextendedproperty 'MS_Description', 
   '折讓統計;折讓統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai04'
go

execute sp_addextendedproperty 'MS_Description', 
   '抵帳統計;抵帳統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai05'
go

execute sp_addextendedproperty 'MS_Description', 
   '掛帳統計;掛帳統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai06'
go

execute sp_addextendedproperty 'MS_Description', 
   '溢收/付統計;溢收/付統計',
   'schema', 'dbo', 'table', 'lsta009', 'column', 'lstai07'
go

alter table dbo.lsta009
   add constraint PK_LSTA009 primary key (doc_comp, biz_type, biz_no, year, month, doc_curr)
      on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2009/9/25 下午 05:00:24                        */
/*==============================================================*/
alter table dbo.abas011
   drop constraint PK_ABAS011
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_abas011'))
drop table dbo.tmp_abas011
go
execute sp_rename abas011, tmp_abas011
go
/*==============================================================*/
/* Table: abas011                                               */
/*==============================================================*/
create table dbo.abas011 (
   recid                uniqueidentifier     not null,
   abask01              nvarchar(2)          not null,
   abask02              nvarchar(20)         not null,
   abask03              nvarchar(20)         not null,
   abask04              nvarchar(30)         not null default '',
   abask05              nvarchar(30)         not null default '',
   abask06              nvarchar(1)          not null default '',
   abask07              int                  not null default 0,
   abask08              nvarchar(20)         not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'RecID;RecID',
   'schema', 'dbo', 'table', 'abas011', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '設定項目;設定項目',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask01'
go

execute sp_addextendedproperty 'MS_Description', 
   '上層母分類編碼;上層母分類編碼',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask02'
go

execute sp_addextendedproperty 'MS_Description', 
   '次(子)分類編號;次(子)分類編號',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask03'
go

execute sp_addextendedproperty 'MS_Description', 
   '名稱;名稱',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask04'
go

execute sp_addextendedproperty 'MS_Description', 
   '定義＆備註;定義＆備註',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask05'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後一層否;最後一層否',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask06'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號碼數;流水號碼數',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask07'
go

execute sp_addextendedproperty 'MS_Description', 
   '上層母+次(子)分類編碼;上層母+次(子)分類編碼',
   'schema', 'dbo', 'table', 'abas011', 'column', 'abask08'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'abas011', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'abas011', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'abas011', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日期;最後修改日期',
   'schema', 'dbo', 'table', 'abas011', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '狀態(覆核、作廢否);狀態(覆核、作廢否)',
   'schema', 'dbo', 'table', 'abas011', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'abas011', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'abas011', 'column', 'last_date'
go
alter table dbo.abas011
   add constraint PK_ABAS011 primary key (abask01, abask02, abask03)
      on "PRIMARY"
go
insert into dbo.abas011 (recid, abask01, abask02, abask03, abask04, abask05, abask06, abask07, abask08)
select recid, abask01, abask02, abask03, abask04, abask05, abask06, abask07, abask08
from dbo.tmp_abas011
go


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom014') and o.name = 'FK_BCOM014_REFERENCE_BCOM001')
alter table dbo.bcom014
   drop constraint FK_BCOM014_REFERENCE_BCOM001
go

alter table arig002 alter column arigb19 nvarchar(50) not null 
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2010-1-11 17:07:31                           */
/*==============================================================*/


use NewErp
go

alter table dbo.dinv003
   drop constraint PK_DINV003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv003'))
drop table dbo.tmp_dinv003
go

execute sp_rename dinv003, tmp_dinv003
go

use NewErp
go

/*==============================================================*/
/* Table: dinv003                                               */
/*==============================================================*/
create table dbo.dinv003 (
   recid                uniqueidentifier     not null,
   dinvcid              uniqueidentifier     not null,
   dinvc01a             nvarchar(2)          not null default '',
   dinvc01b             nvarchar(16)         not null default '',
   dinvc02a             nvarchar(2)          not null default '',
   dinvc02b             nvarchar(16)         not null default '',
   dinvc03              float                not null default 0,
   dinvc04              int                  not null default 0,
   dinvc10              nvarchar(2)          not null default '',
   dinvc11              int                  not null default 0,
   dinvc12              int                  not null default 0,
   dinvc13              int                  not null default 0,
   dinvc14              nvarchar(2)          not null default '',
   dinvc15              int                  not null default 0,
   dinvc16              int                  not null default 0,
   dinvc17              int                  not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   dinvc20              nvarchar(10)         not null default '',
   dinvc21              nvarchar(1)          not null default '',
   dinvc22              nvarchar(6)          not null default '',
   dinvc23a             numeric(19,5)        not null default 0,
   dinvc23b             numeric(19,5)        not null default 0,
   dinvc24              numeric(19,5)        not null default 0,
   dinvc25              numeric(19,5)        not null default 0,
   dinvc26              numeric(19,5)        not null default 0,
   dinvc27              numeric(19,5)        not null default 0,
   dinvc28              numeric(19,5)        not null default 0,
   dinvc29              nvarchar(6)          not null default '',
   dinvc30              nvarchar(20)         not null default '',
   dinvc31              nvarchar(10)         not null default '',
   dinvc32              nvarchar(6)          not null default '',
   dinvc33a             numeric(19,5)        not null default 0,
   dinvc33b             numeric(19,5)        not null default 0,
   remark               nvarchar(30)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局ID;全局ID',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvcid'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單別;出貨單別',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單號;出貨單號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單別;訂單單別',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單號;訂單單號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '貨櫃序號;貨櫃序號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號Char;箱號Char',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號From;箱號From',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號To;箱號To',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱數;箱數',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號Char;棧板號Char',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc14'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號From;棧板號From',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc15'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號To;棧板號To',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc16'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板數;棧板數',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc17'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc20'
go

execute sp_addextendedproperty 'MS_Description', 
   'S/P Code;S/P Code',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc21'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位;單位',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc22'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc23a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc23b'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量/箱;數量/箱',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc24'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨數量 Shipped Q''ty;出貨數量 Shipped Q''ty',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc25'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱凈重 N.W./CTN;每箱凈重 N.W./CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc26'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱毛重 G.W./CTN;每箱毛重 G.W./CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc27'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱材積 Meas''t/CTN;每箱材積 Meas''t/CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc28'
go

execute sp_addextendedproperty 'MS_Description', 
   'DEPT#;DEPT#',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc29'
go

execute sp_addextendedproperty 'MS_Description', 
   'ORDER#;ORDER#',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc30'
go

execute sp_addextendedproperty 'MS_Description', 
   'STORE#   ;STORE#   ',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc31'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位;外包裝單位',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc32'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分子;外包裝單位轉換分子',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc33a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分母;外包裝單位轉換分母',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc33b'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'modify_date'
go

insert into dbo.dinv003 (recid, dinvcid, dinvc01a, dinvc01b, dinvc02a, dinvc02b, dinvc03, dinvc04, dinvc10, dinvc11, dinvc12, dinvc13, dinvc14, dinvc15, dinvc16, dinvc17, item_no, item_sub, biz_item_no, dinvc20, dinvc21, dinvc22, dinvc23a, dinvc23b, dinvc24, dinvc25, dinvc26, dinvc27, dinvc28, dinvc29, dinvc30, dinvc31, remark, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, dinvcid, dinvc01a, dinvc01b, dinvc02a, dinvc02b, dinvc03, dinvc04, dinvc10, dinvc11, dinvc12, dinvc13, dinvc14, dinvc15, dinvc16, dinvc17, item_no, item_sub, biz_item_no, dinvc20, dinvc21, dinvc22, dinvc23a, dinvc23b, dinvc24, dinvc25, dinvc26, dinvc27, dinvc28, dinvc29, dinvc30, dinvc31, remark, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_dinv003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv003'))
drop table dbo.tmp_dinv003
go

alter table dbo.dinv003
   add constraint PK_DINV003 primary key nonclustered (dinvcid)
      on "PRIMARY"
go

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique clustered index Index_1 on dbo.dinv003 (
dinvc01a ASC,
dinvc01b ASC,
dinvc02a ASC,
dinvc02b ASC,
dinvc03 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2010-1-7 15:52:33                            */
/*==============================================================*/
alter table dbo.dinv003
   drop constraint PK_DINV003
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv003'))
drop table dbo.tmp_dinv003
go

execute sp_rename dinv003, tmp_dinv003
go

alter table dbo.dinv004
   drop constraint PK_DINV004
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv004'))
drop table dbo.tmp_dinv004
go

execute sp_rename dinv004, tmp_dinv004
go

alter table dbo.dord002
   drop constraint PK_DORD002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord002'))
drop table dbo.tmp_dord002
go

execute sp_rename dord002, tmp_dord002
go

alter table dbo.dord005
   drop constraint PK_DORD005
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord005'))
drop table dbo.tmp_dord005
go

execute sp_rename dord005, tmp_dord005
go

alter table dbo.dquo002
   drop constraint PK_DQUO002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dquo002'))
drop table dbo.tmp_dquo002
go

execute sp_rename dquo002, tmp_dquo002
go

alter table dbo.epur002
   drop constraint PK_EPUR002
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_epur002'))
drop table dbo.tmp_epur002
go

execute sp_rename epur002, tmp_epur002
go

/*==============================================================*/
/* Table: dinv003                                               */
/*==============================================================*/
create table dbo.dinv003 (
   recid                uniqueidentifier     not null,
   dinvcid              uniqueidentifier     not null,
   dinvc01a             nvarchar(2)          not null default '',
   dinvc01b             nvarchar(16)         not null default '',
   dinvc02a             nvarchar(2)          not null default '',
   dinvc02b             nvarchar(16)         not null default '',
   dinvc03              float                not null default 0,
   dinvc04              int                  not null default 0,
   dinvc10              nvarchar(2)          not null default '',
   dinvc11              int                  not null default 0,
   dinvc12              int                  not null default 0,
   dinvc13              int                  not null default 0,
   dinvc14              nvarchar(2)          not null default '',
   dinvc15              int                  not null default 0,
   dinvc16              int                  not null default 0,
   dinvc17              int                  not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   dinvc20              nvarchar(10)         not null default '',
   dinvc21              nvarchar(1)          not null default '',
   dinvc22              nvarchar(6)          not null default '',
   dinvc23a             numeric(19,5)        not null default 0,
   dinvc23b             numeric(19,5)        not null default 0,
   dinvc24              numeric(19,5)        not null default 0,
   dinvc25              numeric(19,5)        not null default 0,
   dinvc26              numeric(19,5)        not null default 0,
   dinvc27              numeric(19,5)        not null default 0,
   dinvc28              numeric(19,5)        not null default 0,
   dinvc29              nvarchar(6)          not null default '',
   dinvc30              nvarchar(20)         not null default '',
   dinvc31              nvarchar(10)         not null default '',
   remark               nvarchar(30)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局ID;全局ID',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvcid'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單別;出貨單別',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單號;出貨單號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單別;訂單單別',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單號;訂單單號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc03'
go

execute sp_addextendedproperty 'MS_Description', 
   '貨櫃序號;貨櫃序號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc04'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號Char;箱號Char',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc10'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號From;箱號From',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc11'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號To;箱號To',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc12'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱數;箱數',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc13'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號Char;棧板號Char',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc14'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號From;棧板號From',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc15'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號To;棧板號To',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc16'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板數;棧板數',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc17'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc20'
go

execute sp_addextendedproperty 'MS_Description', 
   'S/P Code;S/P Code',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc21'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位;單位',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc22'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc23a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc23b'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量/箱;數量/箱',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc24'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨數量 Shipped Q''ty;出貨數量 Shipped Q''ty',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc25'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱凈重 N.W./CTN;每箱凈重 N.W./CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc26'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱毛重 G.W./CTN;每箱毛重 G.W./CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc27'
go

execute sp_addextendedproperty 'MS_Description', 
   '每箱材積 Meas''t/CTN;每箱材積 Meas''t/CTN',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc28'
go

execute sp_addextendedproperty 'MS_Description', 
   'DEPT#;DEPT#',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc29'
go

execute sp_addextendedproperty 'MS_Description', 
   'ORDER#;ORDER#',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc30'
go

execute sp_addextendedproperty 'MS_Description', 
   'STORE#   ;STORE#   ',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'dinvc31'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv003', 'column', 'modify_date'
go

insert into dbo.dinv003 (recid, dinvcid, dinvc01a, dinvc01b, dinvc02a, dinvc02b, dinvc03, dinvc04, dinvc10, dinvc11, dinvc12, dinvc13, dinvc14, dinvc15, dinvc16, dinvc17, item_no, item_sub, biz_item_no, dinvc20, dinvc21, dinvc22, dinvc23a, dinvc23b, dinvc24, dinvc25, dinvc26, dinvc27, dinvc28, dinvc29, dinvc30, dinvc31, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, dinvcid, dinvc01a, dinvc01b, dinvc02a, dinvc02b, dinvc03, dinvc04, dinvc10, dinvc11, dinvc12, dinvc13, dinvc14, dinvc15, dinvc16, dinvc17, item_no, item_sub, biz_item_no, dinvc20, dinvc21, dinvc22, dinvc23a, dinvc23b, dinvc24, dinvc25, dinvc26, dinvc27, dinvc28, dinvc29, dinvc30, dinvc31, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_dinv003
go
alter table dbo.dinv003
   add constraint PK_DINV003 primary key nonclustered (dinvcid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv003'))
drop table dbo.tmp_dinv003
go

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique clustered index Index_1 on dbo.dinv003 (
dinvc01a ASC,
dinvc01b ASC,
dinvc02a ASC,
dinvc02b ASC,
dinvc03 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Table: dinv004                                               */
/*==============================================================*/
create table dbo.dinv004 (
   recid                uniqueidentifier     not null,
   dinvdid              uniqueidentifier     not null,
   dinvd01a             nvarchar(2)          not null default '',
   dinvd01b             nvarchar(16)         not null default '',
   dinvd02a             nvarchar(2)          not null default '',
   dinvd02b             nvarchar(16)         not null default '',
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   dinvd03              nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   bar_code             nvarchar(20)         not null default '',
   oem_no               nvarchar(30)         not null default '',
   hs_code              nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   item_desce1          nvarchar(30)         not null default '',
   item_desce2          nvarchar(30)         not null default '',
   dinvd04              nvarchar(1)          not null default '',
   dinvd05              uniqueidentifier     not null,
   dinvd06              nvarchar(6)          not null default '',
   dinvd07              numeric(19,5)        not null default 0,
   dinvd08              numeric(19,5)        not null default 0,
   dinvd09              numeric(19,5)        not null default 0,
   dinvd10              nvarchar(6)          not null default '',
   dinvd11              numeric(19,5)        not null default 0,
   dinvd12              numeric(19,5)        not null default 0,
   dinvd13              numeric(19,5)        not null default 0,
   dinvd14              numeric(19,5)        not null default 0,
   dinvd15              numeric(19,5)        not null default 0,
   dinvd16              nvarchar(6)          not null default '',
   dinvd17              nvarchar(20)         not null default '',
   dinvd18              nvarchar(10)         not null default '',
   dinvd20              numeric(19,5)        not null default 0,
   remark               nvarchar(30)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局ID;全局ID',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvdid'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單別;出貨單別',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨單號;出貨單號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單/索樣單別;訂單/索樣單別',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd02a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單/索樣單號;訂單/索樣單號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd02b'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd03'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品條碼;產品條碼',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'bar_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品自定義碼(OEM);產品自定義碼(OEM)',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'oem_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品進口稅則代碼(H.S. Code);產品進口稅則代碼(H.S. Code)',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'hs_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1(英文);產品名稱1(英文)',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_desce1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2(英文);產品名稱2(英文)',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'item_desce2'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd04'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配來源流水號;贈配來源流水號',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd05'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位;計量單位',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd06'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位轉換分子;計量單位轉換分子',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd07'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位轉換分母;計量單位轉換分母',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd08'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量;數量',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd09'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd10'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分子;計價單位轉換分子',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd11'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分母;計價單位轉換分母',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd12'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd13'
go

execute sp_addextendedproperty 'MS_Description', 
   '出貨Invoice單價;出貨Invoice單價',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd14'
go

execute sp_addextendedproperty 'MS_Description', 
   'Under Value;Under Value',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd15'
go

execute sp_addextendedproperty 'MS_Description', 
   'DEPT#;DEPT#',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd16'
go

execute sp_addextendedproperty 'MS_Description', 
   'ORDER#;ORDER#',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd17'
go

execute sp_addextendedproperty 'MS_Description', 
   'STORE#   ;STORE#   ',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd18'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款單價;代收款單價',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'dinvd20'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dinv004', 'column', 'modify_date'
go

insert into dbo.dinv004 (recid, dinvdid, dinvd01a, dinvd01b, dinvd02a, dinvd02b, auto_seq, num, item_no, item_sub, dinvd03, biz_item_no, bar_code, oem_no, hs_code, item_desc1, item_desc2, item_desce1, item_desce2, dinvd04, dinvd05, dinvd06, dinvd07, dinvd08, dinvd09, dinvd10, dinvd11, dinvd12, dinvd13, dinvd14, dinvd15, dinvd16, dinvd17, dinvd18, dinvd20, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, dinvdid, dinvd01a, dinvd01b, dinvd02a, dinvd02b, auto_seq, num, item_no, item_sub, dinvd03, biz_item_no, bar_code, oem_no, hs_code, item_desc1, item_desc2, item_desce1, item_desce2, dinvd04, dinvd05, dinvd06, dinvd07, dinvd08, dinvd09, dinvd10, dinvd11, dinvd12, dinvd13, dinvd14, dinvd15, dinvd16, dinvd17, dinvd18, dinvd20, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_dinv004
go
alter table dbo.dinv004
   add constraint PK_DINV004 primary key nonclustered (dinvdid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dinv004'))
drop table dbo.tmp_dinv004
go

/*==============================================================*/
/* Index: idx_dinv004_1                                         */
/*==============================================================*/
create unique clustered index idx_dinv004_1 on dbo.dinv004 (
dinvd01a ASC,
dinvd01b ASC,
dinvd02a ASC,
dinvd02b ASC,
auto_seq ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Table: dord002                                               */
/*==============================================================*/
create table dbo.dord002 (
   recid                uniqueidentifier     not null,
   dordbid              uniqueidentifier     not null,
   dordb01a             nvarchar(2)          not null,
   dordb01b             nvarchar(16)         not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   dordb02              nvarchar(1)          not null default '',
   dordb03              uniqueidentifier     not null,
   dordb04              nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   bar_code             nvarchar(30)         not null default '',
   oem_no               nvarchar(30)         not null default '',
   hs_code              nvarchar(20)         not null default '',
   cata_code            nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   item_desce1          nvarchar(30)         not null default '',
   item_desce2          nvarchar(30)         not null default '',
   dordb05              numeric(19,5)        not null default 0,
   dordb06              nvarchar(6)          not null default '',
   dordb07a             numeric(19,5)        not null default 0,
   dordb07b             numeric(19,5)        not null default 0,
   dordb08              numeric(19,5)        not null default 0,
   dordb09              nvarchar(6)          not null default '',
   dordb10a             numeric(19,5)        not null default 0,
   dordb10b             numeric(19,5)        not null default 0,
   dordb11              numeric(19,5)        not null default 0,
   dordb15              numeric(19,5)        not null default 0,
   dordb16a             nvarchar(1)          not null default '',
   dordb16b             nvarchar(10)         not null default '',
   dordb17              int                  not null default 0,
   dordb18              nvarchar(5)          not null default '',
   dordb19              numeric(9,5)         not null default 0,
   dordb20              numeric(19,5)        not null default 0,
   dordb20a             numeric(9,5)         not null default 0,
   dordb20b             numeric(9,5)         not null default 0,
   dordb21              numeric(19,5)        not null default 0,
   dordb22a             numeric(19,5)        not null default 0,
   dordb22b             numeric(19,5)        not null default 0,
   dordb23              numeric(19,5)        not null default 0,
   dordb24              numeric(19,5)        not null default 0,
   dordb25a             numeric(9,5)         not null default 0,
   dordb25b             numeric(19,5)        not null default 0,
   dordb28              nvarchar(10)         not null default '',
   dordb30              nvarchar(6)          not null default '',
   dordb31a             numeric(9,5)         not null default 0,
   dordb31b             numeric(9,5)         not null default 0,
   dordb31c             numeric(9,5)         not null default 0,
   dordb32a             numeric(19,5)        not null default 0,
   dordb32b             nvarchar(6)          not null default '',
   dordb32d             numeric(19,5)        not null default 0,
   dordb32e             numeric(19,5)        not null default 0,
   dordb32c             nvarchar(6)          not null default '',
   dordb32f             numeric(19,5)        not null default 0,
   dordb32g             numeric(19,5)        not null default 0,
   dordb33a             numeric(19,5)        not null default 0,
   dordb33b             nvarchar(6)          not null default '',
   dordb33d             numeric(19,5)        not null default 0,
   dordb33e             numeric(19,5)        not null default 0,
   dordb33c             nvarchar(6)          not null default '',
   dordb33f             numeric(19,5)        not null default 0,
   dordb33g             numeric(19,5)        not null default 0,
   dordb34a             numeric(19,5)        not null default 0,
   dordb34b             nvarchar(6)          not null default '',
   dordb34d             numeric(19,5)        not null default 0,
   dordb34e             numeric(19,5)        not null default 0,
   dordb34c             nvarchar(6)          not null default '',
   dordb34f             numeric(19,5)        not null default 0,
   dordb34g             numeric(19,5)        not null default 0,
   dordb35a             nvarchar(6)          not null default '',
   dordb35b             numeric(19,5)        not null default 0,
   dordb36a             nvarchar(6)          not null default '',
   dordb36b             numeric(19,5)        not null default 0,
   dordb36c             numeric(19,5)        not null default 0,
   dordb37              numeric(19,5)        not null default 0,
   dordb40              numeric(19,5)        not null default 0,
   dordb41              numeric(19,5)        not null default 0,
   dordb42a             numeric(19,5)        not null default 0,
   dordb42b             numeric(19,5)        not null default 0,
   dordb43a             numeric(19,5)        not null default 0,
   dordb43b             numeric(19,5)        not null default 0,
   dordb44a             numeric(19,5)        not null default 0,
   dordb44b             numeric(19,5)        not null default 0,
   dordb45a             numeric(19,5)        not null default 0,
   dordb45b             numeric(19,5)        not null default 0,
   dordb46a             numeric(19,5)        not null default 0,
   dordb46b             numeric(19,5)        not null default 0,
   dordb47              numeric(19,5)        not null default 0,
   dordb50              numeric(19,5)        not null default 0,
   dordb51a             nvarchar(1)          not null default '',
   dordb51b             numeric(9,5)         not null default 0,
   dordb52              numeric(19,5)        not null default 0,
   dordb55a             nvarchar(2)          not null default '',
   dordb55b             nvarchar(16)         not null default '',
   dordb56              nvarchar(1)          not null default '',
   dordb57a             nvarchar(1)          not null default '',
   dordb57b             numeric(19,5)        not null default 0,
   dordb58              nvarchar(10)         not null default '',
   dordb60              numeric(19,5)        not null default 0,
   dordb61              numeric(9,5)         not null default 0,
   dordb62              numeric(19,5)        not null default 0,
   dordb63              numeric(19,5)        not null default 0,
   dordb64              numeric(19,5)        not null default 0,
   dordb65              numeric(19,5)        not null default 0,
   dordb66              numeric(19,5)        not null default 0,
   dordb67              numeric(9,5)         not null default 0,
   dordb68              numeric(19,5)        not null default 0,
   remark               nvarchar(30)         not null default '',
   dordb70              numeric(19,8)        not null default 0,
   dordb71              nvarchar(1)          not null default '',
   dordb72              nvarchar(20)         not null default '',
   dordb73              nvarchar(20)         not null default '',
   dordb74a             nvarchar(6)          not null default '',
   dordb74b             nvarchar(20)         not null default '',
   dordb74c             nvarchar(10)         not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dord002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordbid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb02'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配來源流水號;贈配來源流水號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb03'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb04'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品條碼;產品條碼',
   'schema', 'dbo', 'table', 'dord002', 'column', 'bar_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品自定義碼(OEM);產品自定義碼(OEM)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'oem_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品進口稅則代碼(H.S. Code);產品進口稅則代碼(H.S. Code)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'hs_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '型錄代號;型錄代號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'cata_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱1;英文產品名稱1',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_desce1'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱2;英文產品名稱2',
   'schema', 'dbo', 'table', 'dord002', 'column', 'item_desce2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量;數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb05'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位;計量單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb06'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb08'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb09'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分子;計價單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分母;計價單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '組合數量;組合數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb11'
go

execute sp_addextendedproperty 'MS_Description', 
   '附加件成本;附加件成本',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb15'
go

execute sp_addextendedproperty 'MS_Description', 
   '供貨對象別;供貨對象別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '供貨對象編號;供貨對象編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格序號;價格序號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb17'
go

execute sp_addextendedproperty 'MS_Description', 
   '成本幣別;成本幣別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb18'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算匯率-公司幣別;換算匯率-公司幣別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb19'
go

execute sp_addextendedproperty 'MS_Description', 
   '成本未稅單價;成本未稅單價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb20'
go

execute sp_addextendedproperty 'MS_Description', 
   '廠商增值稅率;廠商增值稅率',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb20a'
go

execute sp_addextendedproperty 'MS_Description', 
   '出口退稅率;出口退稅率',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價成本;計價成本',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb21'
go

execute sp_addextendedproperty 'MS_Description', 
   '製造利潤Profit1%;製造利潤Profit1%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷售利潤Profit2%;銷售利潤Profit2%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb22b'
go

execute sp_addextendedproperty 'MS_Description', 
   'FOB單價;FOB單價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb23'
go

execute sp_addextendedproperty 'MS_Description', 
   'TERM單價;TERM單價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb24'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValude%;UnderValude%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb25a'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValude$;UnderValude$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb25b'
go

execute sp_addextendedproperty 'MS_Description', 
   '廠商認證組;廠商認證組',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb28'
go

execute sp_addextendedproperty 'MS_Description', 
   'Dimension Unit(規格單位);Dimension Unit(規格單位)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb30'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度1(@L);外包裝規格長度1(@L)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度2(@W);外包裝規格長度2(@W)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度3(@H);外包裝規格長度3(@H)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝數量;內包裝數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位;內包裝計數單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分子;內包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分母;內包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32e'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位;內包裝單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分子;內包裝單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32f'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分母;內包裝單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb32g'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝數量;外包裝數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位;外包裝計數單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分子;外包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33d'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分母;外包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33e'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位;外包裝單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33c'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分子;外包裝單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33f'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分母;外包裝單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb33g'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板外包裝數量;棧板外包裝數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34a'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位;棧板計數單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34b'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分子;棧板計數單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34d'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分母;棧板計數單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34e'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位;棧板單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34c'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分子;棧板單位轉換分子',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34f'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分母;棧板單位轉換分母',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb34g'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t Unit 體積單位;Measm''t Unit 體積單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb35a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t 外包裝體積;Measm''t 外包裝體積',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb35b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Weight Unit 重量單位;Weight Unit 重量單位',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb36a'
go

execute sp_addextendedproperty 'MS_Description', 
   'N.W. 外包裝凈重;N.W. 外包裝凈重',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'G.W. 外包裝毛重;G.W. 外包裝毛重',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb36c'
go

execute sp_addextendedproperty 'MS_Description', 
   '每貨櫃基本單位數量;每貨櫃基本單位數量',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb37'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Freight;@Freight',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb40'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Insurance;@Insurance',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb41'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission%;@Commission%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb42a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission$;@Commission$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb42b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission1%;@Commission1%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb43a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission1$;@Commission1$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb43b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DA%;@DA%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb44a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DA$;@DA$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb44b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DU%;@DU%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb45a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DU$;@DU$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb45b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Misc. Charge%;@Misc. Charge%',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb46a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Misc. Charge$;@Misc. Charge$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb46b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Port2Door Charge$;@Port2Door Charge$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb47'
go

execute sp_addextendedproperty 'MS_Description', 
   '@稅基(CIF);@稅基(CIF)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb50'
go

execute sp_addextendedproperty 'MS_Description', 
   'H.S.Code計稅方式代碼;H.S.Code計稅方式代碼',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb51a'
go

execute sp_addextendedproperty 'MS_Description', 
   '計稅方式數值;計稅方式數值',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb51b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Tax$;@Tax$',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb52'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單別;相關來源單別',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb55a'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單號;相關來源單號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb55b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交易價格具參考價值否;交易價格具參考價值否',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb56'
go

execute sp_addextendedproperty 'MS_Description', 
   'L/C控制訂單產品超交否;L/C控制訂單產品超交否',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb57a'
go

execute sp_addextendedproperty 'MS_Description', 
   '控制超交數值;控制超交數值',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb57b'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品負責業務;產品負責業務',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb58'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂價;訂價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb60'
go

execute sp_addextendedproperty 'MS_Description', 
   '折數;折數',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb61'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅單價;未稅單價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb62'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅小計;未稅小計',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb63'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅單價;含稅單價',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb64'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅小計;含稅小計',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb65'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金;稅金',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb66'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb67'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款(健康捐);代收款(健康捐)',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb68'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'dord002', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '目前成本;目前成本',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb70'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格來源;價格來源',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb71'
go

execute sp_addextendedproperty 'MS_Description', 
   '組合關係版本編號;組合關係版本編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb72'
go

execute sp_addextendedproperty 'MS_Description', 
   '附加件版本編號;附加件版本編號',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb73'
go

execute sp_addextendedproperty 'MS_Description', 
   'DEPT#;DEPT#',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb74a'
go

execute sp_addextendedproperty 'MS_Description', 
   'ORDER#;ORDER#',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb74b'
go

execute sp_addextendedproperty 'MS_Description', 
   'STORE#   ;STORE#   ',
   'schema', 'dbo', 'table', 'dord002', 'column', 'dordb74c'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dord002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dord002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dord002', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dord002', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dord002', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dord002', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dord002', 'column', 'last_date'
go

insert into dbo.dord002 (recid, dordbid, dordb01a, dordb01b, auto_seq, num, item_no, item_sub, dordb02, dordb03, dordb04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, dordb05, dordb06, dordb07a, dordb07b, dordb08, dordb09, dordb10a, dordb10b, dordb11, dordb15, dordb16a, dordb16b, dordb17, dordb18, dordb19, dordb20, dordb20a, dordb20b, dordb21, dordb22a, dordb22b, dordb23, dordb24, dordb25a, dordb25b, dordb28, dordb30, dordb31a, dordb31b, dordb31c, dordb32a, dordb32b, dordb32d, dordb32e, dordb32c, dordb32f, dordb32g, dordb33a, dordb33b, dordb33d, dordb33e, dordb33c, dordb33f, dordb33g, dordb34a, dordb34b, dordb34d, dordb34e, dordb34c, dordb34f, dordb34g, dordb35a, dordb35b, dordb36a, dordb36b, dordb36c, dordb37, dordb40, dordb41, dordb42a, dordb42b, dordb43a, dordb43b, dordb44a, dordb44b, dordb45a, dordb45b, dordb46a, dordb46b, dordb47, dordb50, dordb51a, dordb51b, dordb52, dordb55a, dordb55b, dordb56, dordb57a, dordb57b, dordb58, dordb60, dordb61, dordb62, dordb63, dordb64, dordb65, dordb66, dordb67, dordb68, dordb70, dordb71, dordb72, dordb73, dordb74a, dordb74b, dordb74c, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date)
select recid, dordbid, dordb01a, dordb01b, auto_seq, num, item_no, item_sub, dordb02, dordb03, dordb04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, dordb05, dordb06, dordb07a, dordb07b, dordb08, dordb09, dordb10a, dordb10b, dordb11, dordb15, dordb16a, dordb16b, dordb17, dordb18, dordb19, dordb20, dordb20a, dordb20b, dordb21, dordb22a, dordb22b, dordb23, dordb24, dordb25a, dordb25b, dordb28, dordb30, dordb31a, dordb31b, dordb31c, dordb32a, dordb32b, dordb32d, dordb32e, dordb32c, dordb32f, dordb32g, dordb33a, dordb33b, dordb33d, dordb33e, dordb33c, dordb33f, dordb33g, dordb34a, dordb34b, dordb34d, dordb34e, dordb34c, dordb34f, dordb34g, dordb35a, dordb35b, dordb36a, dordb36b, dordb36c, dordb37, dordb40, dordb41, dordb42a, dordb42b, dordb43a, dordb43b, dordb44a, dordb44b, dordb45a, dordb45b, dordb46a, dordb46b, dordb47, dordb50, dordb51a, dordb51b, dordb52, dordb55a, dordb55b, dordb56, dordb57a, dordb57b, dordb58, dordb60, dordb61, dordb62, dordb63, dordb64, dordb65, dordb66, dordb67, dordb68, dordb70, dordb71, dordb72, dordb73, dordb74a, dordb74b, dordb74c, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date
from dbo.tmp_dord002
go
alter table dbo.dord002
   add constraint PK_DORD002 primary key nonclustered (dordbid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord002'))
drop table dbo.tmp_dord002
go

/*==============================================================*/
/* Index: idx_dord002_1                                         */
/*==============================================================*/
create unique clustered index idx_dord002_1 on dbo.dord002 (
dordb01a ASC,
dordb01b ASC,
auto_seq ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dord002_2                                         */
/*==============================================================*/
create unique index idx_dord002_2 on dbo.dord002 (
dordb01a ASC,
dordb01b ASC,
item_no ASC,
item_sub ASC,
dordb04 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Table: dord005                                               */
/*==============================================================*/
create table dbo.dord005 (
   recid                uniqueidentifier     not null,
   dordeid              uniqueidentifier     not null,
   dorde01              uniqueidentifier     not null,
   dorde02              nvarchar(10)         not null default '',
   auto_seq             float                not null default 0,
   dorde03a             nvarchar(2)          not null default '',
   dorde03b             nvarchar(16)         not null default '',
   dorde05              numeric(19,5)        not null default 0,
   dorde06              nvarchar(6)          not null default '',
   dorde07              numeric(19,5)        not null default 0,
   dorde08              numeric(19,5)        not null default 0,
   dorde09              datetime             not null default CONVERT(DATETIME,0),
   dorde10              numeric(19,5)        not null default 0,
   dorde11              nvarchar(30)         not null default '',
   remark               nvarchar(30)         not null default '',
   dorde15              uniqueidentifier     not null,
   dorde16              nvarchar(1)          not null default '',
   dorde30a             nvarchar(2)          not null default '',
   dorde30b             nvarchar(16)         not null default '',
   biz_no               nvarchar(10)         not null default '',
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   dorde31              nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'dord005', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局ID;全局ID',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dordeid'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單排程ID;訂單排程ID',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde01'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷代碼;衝銷代碼',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde02'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單別;來源單別',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde03a'
go

execute sp_addextendedproperty 'MS_Description', 
   '來源單號;來源單號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde03b'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷數量;衝銷數量',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde05'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷數量單位;衝銷數量單位',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde06'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷單位轉換分子;衝銷單位轉換分子',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde07'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷單位轉換分母;衝銷單位轉換分母',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde08'
go

execute sp_addextendedproperty 'MS_Description', 
   '衝銷日期;衝銷日期',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde09'
go

execute sp_addextendedproperty 'MS_Description', 
   '調整數量;調整數量',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde10'
go

execute sp_addextendedproperty 'MS_Description', 
   '調整原因;調整原因',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde11'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註說明;備註說明',
   'schema', 'dbo', 'table', 'dord005', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單產品明細ID;訂單產品明細ID',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde15'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統產生標記;系統產生標記',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde16'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單別;訂單單別',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde30a'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂單單號;訂單單號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde30b'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶編號;客戶編號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dord005', 'column', 'dorde31'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dord005', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dord005', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dord005', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dord005', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'dord005', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'dord005', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dord005', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dord005', 'column', 'modify_date'
go


insert into dbo.dord005 (recid, dordeid, dorde01, dorde02, auto_seq, dorde03a, dorde03b, dorde05, dorde06, dorde07, dorde08, dorde09, dorde10,dorde11,dorde15, dorde16, dorde30a, dorde30b, biz_no, item_no, item_sub, dorde31, biz_item_no, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, dordeid, dorde01, dorde02, auto_seq, dorde03a, dorde03b, dorde05, dorde06, dorde07, dorde08, dorde09, dorde10, dorde11,dorde15, dorde16, dorde30a, dorde30b, biz_no, item_no, item_sub, dorde31, biz_item_no, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_dord005
go

alter table dbo.dord005
   add constraint PK_DORD005 primary key nonclustered (dordeid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dord005'))
drop table dbo.tmp_dord005
go
/*==============================================================*/
/* Index: idx_dord005_1                                         */
/*==============================================================*/
create clustered index idx_dord005_1 on dbo.dord005 (
dorde30a ASC,
dorde30b ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Index: idx_dord005_2                                         */
/*==============================================================*/
create unique index idx_dord005_2 on dbo.dord005 (
dorde01 ASC,
dorde02 ASC,
auto_seq ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Table: dquo002                                               */
/*==============================================================*/
create table dbo.dquo002 (
   recid                uniqueidentifier     not null,
   dquobid              uniqueidentifier     not null,
   dquob01a             nvarchar(2)          not null,
   dquob01b             nvarchar(16)         not null,
   num                  float                not null,
   item_no              nvarchar(20)         not null,
   item_sub             nvarchar(10)         not null,
   dquob02              nvarchar(1)          not null default '',
   dquob03              uniqueidentifier     not null,
   dquob04              nvarchar(10)         not null,
   biz_item_no          nvarchar(20)         not null default '',
   bar_code             nvarchar(30)         not null default '',
   oem_no               nvarchar(30)         not null default '',
   hs_code              nvarchar(20)         not null default '',
   cata_code            nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   item_desce1          nvarchar(30)         not null default '',
   item_desce2          nvarchar(30)         not null default '',
   dquob05              numeric(19,5)        not null default 0,
   dquob06              nvarchar(6)          not null default '',
   dquob07a             numeric(19,5)        not null default 0,
   dquob07b             numeric(19,5)        not null default 0,
   dquob08              numeric(19,5)        not null default 0,
   dquob09              nvarchar(6)          not null default '',
   dquob10a             numeric(19,5)        not null default 0,
   dquob10b             numeric(19,5)        not null default 0,
   dquob15              numeric(19,5)        not null default 0,
   dquob16a             nvarchar(1)          not null default '',
   dquob16b             nvarchar(10)         not null default '',
   dquob17              int                  not null default 0,
   dquob18              nvarchar(5)          not null default '',
   dquob19              numeric(9,5)         not null default 0,
   dquob20              numeric(19,5)        not null default 0,
   dquob20a             numeric(9,5)         not null default 0,
   dquob20b             numeric(9,5)         not null default 0,
   dquob21              numeric(19,5)        not null default 0,
   dquob22a             numeric(19,5)        not null default 0,
   dquob22b             numeric(19,5)        not null default 0,
   dquob23              numeric(19,5)        not null default 0,
   dquob24              numeric(19,5)        not null default 0,
   dquob25a             numeric(9,5)         not null default 0,
   dquob25b             numeric(19,5)        not null default 0,
   dquob30              nvarchar(6)          not null default '',
   dquob31a             numeric(9,5)         not null default 0,
   dquob31b             numeric(9,5)         not null default 0,
   dquob31c             numeric(9,5)         not null default 0,
   dquob32a             numeric(19,5)        not null default 0,
   dquob32b             nvarchar(6)          not null default '',
   dquob32c             nvarchar(6)          not null default '',
   dquob32d             numeric(19,5)        not null default 0,
   dquob32e             numeric(19,5)        not null default 0,
   dquob32f             numeric(19,5)        not null default 0,
   dquob32g             numeric(19,5)        not null default 0,
   dquob33a             numeric(19,5)        not null default 0,
   dquob33b             nvarchar(6)          not null default '',
   dquob33c             nvarchar(6)          not null default '',
   dquob33d             numeric(19,5)        not null default 0,
   dquob33e             numeric(19,5)        not null default 0,
   dquob33f             numeric(19,5)        not null default 0,
   dquob33g             numeric(19,5)        not null default 0,
   dquob34a             numeric(19,5)        not null default 0,
   dquob34b             nvarchar(6)          not null default '',
   dquob34c             nvarchar(6)          not null default '',
   dquob34d             numeric(19,5)        not null default 0,
   dquob34e             numeric(19,5)        not null default 0,
   dquob34f             numeric(19,5)        not null default 0,
   dquob34g             numeric(19,5)        not null default 0,
   dquob35a             nvarchar(6)          not null default '',
   dquob35b             numeric(19,5)        not null default 0,
   dquob36a             nvarchar(6)          not null default '',
   dquob36b             numeric(19,5)        not null default 0,
   dquob36c             numeric(19,5)        not null default 0,
   dquob37              numeric(19,5)        not null default 0,
   dquob40              numeric(19,5)        not null default 0,
   dquob41              numeric(19,5)        not null default 0,
   dquob42a             numeric(19,5)        not null default 0,
   dquob42b             numeric(19,5)        not null default 0,
   dquob43a             numeric(19,5)        not null default 0,
   dquob43b             numeric(19,5)        not null default 0,
   dquob44a             numeric(19,5)        not null default 0,
   dquob44b             numeric(19,5)        not null default 0,
   dquob45a             numeric(19,5)        not null default 0,
   dquob45b             numeric(19,5)        not null default 0,
   dquob46a             numeric(19,5)        not null default 0,
   dquob46b             numeric(19,5)        not null default 0,
   dquob47              numeric(19,5)        not null default 0,
   dquob50              numeric(19,5)        not null default 0,
   dquob51a             nvarchar(1)          not null default '',
   dquob51b             numeric(9,5)         not null default 0,
   dquob52              numeric(19,5)        not null default 0,
   dquob55a             nvarchar(2)          not null default '',
   dquob55b             nvarchar(16)         not null default '',
   dquob56              nvarchar(1)          not null default '',
   dquob60              numeric(19,5)        not null default 0,
   dquob61              numeric(9,5)         not null default 0,
   dquob62              numeric(19,5)        not null default 0,
   dquob63              numeric(19,5)        not null default 0,
   dquob64              numeric(19,5)        not null default 0,
   dquob65              numeric(19,5)        not null default 0,
   dquob66              numeric(19,5)        not null default 0,
   dquob67              numeric(9,5)         not null default 0,
   dquob68              numeric(19,5)        not null default 0,
   remark               nvarchar(30)         not null default '',
   dquob70              numeric(19,8)        not null default 0,
   dquob71              nvarchar(1)          not null default '',
   dquob72              nvarchar(20)         not null default '',
   dquob73              nvarchar(20)         not null default '',
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'RecID;RecID',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquobid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob02'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配來源流水號;贈配來源流水號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob03'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob04'
go

execute sp_addextendedproperty 'MS_Description', 
   '客戶產品編號;客戶產品編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品條碼;產品條碼',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'bar_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品自定義碼(OEM);產品自定義碼(OEM)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'oem_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品進口稅則代碼(H.S. Code);產品進口稅則代碼(H.S. Code)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'hs_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '型錄代號;型錄代號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'cata_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱1;英文產品名稱1',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_desce1'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱2;英文產品名稱2',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'item_desce2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量;數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob05'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位;計量單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob06'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob08'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob09'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分子;計價單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分母;計價單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '附加件成本;附加件成本',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob15'
go

execute sp_addextendedproperty 'MS_Description', 
   '供貨對象別;供貨對象別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob16a'
go

execute sp_addextendedproperty 'MS_Description', 
   '供貨對象編號;供貨對象編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob16b'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格序號;價格序號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob17'
go

execute sp_addextendedproperty 'MS_Description', 
   '成本幣別;成本幣別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob18'
go

execute sp_addextendedproperty 'MS_Description', 
   '換算匯率-公司幣別;換算匯率-公司幣別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob19'
go

execute sp_addextendedproperty 'MS_Description', 
   '成本未稅單價;成本未稅單價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob20'
go

execute sp_addextendedproperty 'MS_Description', 
   '廠商增值稅率;廠商增值稅率',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob20a'
go

execute sp_addextendedproperty 'MS_Description', 
   '出口退稅率;出口退稅率',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob20b'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價成本;計價成本',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob21'
go

execute sp_addextendedproperty 'MS_Description', 
   '製造利潤Profit1%;製造利潤Profit1%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob22a'
go

execute sp_addextendedproperty 'MS_Description', 
   '銷售利潤Profit2%;銷售利潤Profit2%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob22b'
go

execute sp_addextendedproperty 'MS_Description', 
   'FOB單價;FOB單價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob23'
go

execute sp_addextendedproperty 'MS_Description', 
   'TERM單價;TERM單價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob24'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValude%;UnderValude%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob25a'
go

execute sp_addextendedproperty 'MS_Description', 
   'UnderValude$;UnderValude$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob25b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Dimension Unit(規格單位);Dimension Unit(規格單位)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob30'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度1(@L);外包裝規格長度1(@L)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度2(@W);外包裝規格長度2(@W)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度3(@H);外包裝規格長度3(@H)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝數量;內包裝數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位;內包裝計數單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位;內包裝單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分子;內包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分母;內包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32e'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分子;內包裝單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32f'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分母;內包裝單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob32g'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝數量;外包裝數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位;外包裝計數單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位;外包裝單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33c'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分子;外包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33d'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分母;外包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33e'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分子;外包裝單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33f'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分母;外包裝單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob33g'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板外包裝數量;棧板外包裝數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34a'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位;棧板計數單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34b'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位;棧板單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34c'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分子;棧板計數單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34d'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分母;棧板計數單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34e'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分子;棧板單位轉換分子',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34f'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分母;棧板單位轉換分母',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob34g'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t Unit 體積單位;Measm''t Unit 體積單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob35a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t 外包裝體積;Measm''t 外包裝體積',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob35b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Weight Unit 重量單位;Weight Unit 重量單位',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob36a'
go

execute sp_addextendedproperty 'MS_Description', 
   'N.W. 外包裝凈重;N.W. 外包裝凈重',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'G.W. 外包裝毛重;G.W. 外包裝毛重',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob36c'
go

execute sp_addextendedproperty 'MS_Description', 
   '每貨櫃基本單位數量;每貨櫃基本單位數量',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob37'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Freight;@Freight',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob40'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Insurance;@Insurance',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob41'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission%;@Commission%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob42a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission$;@Commission$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob42b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission1%;@Commission1%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob43a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Commission1$;@Commission1$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob43b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DA%;@DA%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob44a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DA$;@DA$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob44b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DU%;@DU%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob45a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@DU$;@DU$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob45b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Misc. Charge%;@Misc. Charge%',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob46a'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Misc. Charge$;@Misc. Charge$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob46b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Port2Door Charge$;@Port2Door Charge$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob47'
go

execute sp_addextendedproperty 'MS_Description', 
   '@稅基(CIF);@稅基(CIF)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob50'
go

execute sp_addextendedproperty 'MS_Description', 
   'H.S.Code計稅方式代碼;H.S.Code計稅方式代碼',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob51a'
go

execute sp_addextendedproperty 'MS_Description', 
   '計稅方式數值;計稅方式數值',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob51b'
go

execute sp_addextendedproperty 'MS_Description', 
   '@Tax$;@Tax$',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob52'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單別;相關來源單別',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob55a'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單號;相關來源單號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob55b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交易價格具參考價值否;交易價格具參考價值否',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob56'
go

execute sp_addextendedproperty 'MS_Description', 
   '訂價;訂價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob60'
go

execute sp_addextendedproperty 'MS_Description', 
   '折數;折數',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob61'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅單價;未稅單價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob62'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅小計;未稅小計',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob63'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅單價;含稅單價',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob64'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅小計;含稅小計',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob65'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金;稅金',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob66'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob67'
go

execute sp_addextendedproperty 'MS_Description', 
   '代收款(健康捐);代收款(健康捐)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob68'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '目前成本;目前成本',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob70'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格來源;價格來源',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob71'
go

execute sp_addextendedproperty 'MS_Description', 
   '組合關係版本編號;組合關係版本編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob72'
go

execute sp_addextendedproperty 'MS_Description', 
   '附加件版本編號;附加件版本編號',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'dquob73'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日期;建檔日期',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'modify_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '狀態(覆核、作廢否);狀態(覆核、作廢否)',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'dquo002', 'column', 'last_date'
go

insert into dbo.dquo002 (recid, dquobid, dquob01a, dquob01b, num, item_no, item_sub, dquob02, dquob03, dquob04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, dquob05, dquob06, dquob07a, dquob07b, dquob08, dquob09, dquob10a, dquob10b, dquob15, dquob16a, dquob16b, dquob17, dquob18, dquob19, dquob20, dquob20a, dquob20b, dquob21, dquob22a, dquob22b, dquob23, dquob24, dquob25a, dquob25b, dquob30, dquob31a, dquob31b, dquob31c, dquob32a, dquob32b, dquob32c, dquob32d, dquob32e, dquob32f, dquob32g, dquob33a, dquob33b, dquob33c, dquob33d, dquob33e, dquob33f, dquob33g, dquob34a, dquob34b, dquob34c, dquob34d, dquob34e, dquob34f, dquob34g, dquob35a, dquob35b, dquob36a, dquob36b, dquob36c, dquob37, dquob40, dquob41, dquob42a, dquob42b, dquob43a, dquob43b, dquob44a, dquob44b, dquob45a, dquob45b, dquob46a, dquob46b, dquob47, dquob50, dquob51a, dquob51b, dquob52, dquob55a, dquob55b, dquob56, dquob60, dquob61, dquob62, dquob63, dquob64, dquob65, dquob66, dquob67, dquob68, dquob70, dquob71, dquob72, dquob73, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date)
select recid, dquobid, dquob01a, dquob01b, num, item_no, item_sub, dquob02, dquob03, dquob04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, dquob05, dquob06, dquob07a, dquob07b, dquob08, dquob09, dquob10a, dquob10b, dquob15, dquob16a, dquob16b, dquob17, dquob18, dquob19, dquob20, dquob20a, dquob20b, dquob21, dquob22a, dquob22b, dquob23, dquob24, dquob25a, dquob25b, dquob30, dquob31a, dquob31b, dquob31c, dquob32a, dquob32b, dquob32c, dquob32d, dquob32e, dquob32f, dquob32g, dquob33a, dquob33b, dquob33c, dquob33d, dquob33e, dquob33f, dquob33g, dquob34a, dquob34b, dquob34c, dquob34d, dquob34e, dquob34f, dquob34g, dquob35a, dquob35b, dquob36a, dquob36b, dquob36c, dquob37, dquob40, dquob41, dquob42a, dquob42b, dquob43a, dquob43b, dquob44a, dquob44b, dquob45a, dquob45b, dquob46a, dquob46b, dquob47, dquob50, dquob51a, dquob51b, dquob52, dquob55a, dquob55b, dquob56, dquob60, dquob61, dquob62, dquob63, dquob64, dquob65, dquob66, dquob67, dquob68, dquob70, dquob71, dquob72, dquob73, create_user, create_date, modify_user, modify_date, doc_status, last_user, last_date
from dbo.tmp_dquo002
go
alter table dbo.dquo002
   add constraint PK_DQUO002 primary key nonclustered (dquobid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_dquo002'))
drop table dbo.tmp_dquo002
go

/*==============================================================*/
/* Index: idx_dquo002_1                                         */
/*==============================================================*/
create unique clustered index idx_dquo002_1 on dbo.dquo002 (
dquob01a ASC,
dquob01b ASC,
item_no ASC,
item_sub ASC,
dquob04 ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Table: epur002                                               */
/*==============================================================*/
create table dbo.epur002 (
   recid                uniqueidentifier     not null,
   epurbid              uniqueidentifier     not null,
   epurb01a             nvarchar(2)          not null,
   epurb01b             nvarchar(16)         not null,
   auto_seq             float                not null default 0,
   num                  float                not null default 0,
   item_no              nvarchar(20)         not null default '',
   item_sub             nvarchar(10)         not null default '',
   epurb02              nvarchar(1)          not null default '',
   epurb03              uniqueidentifier     not null,
   epurb04              nvarchar(10)         not null default '',
   biz_item_no          nvarchar(20)         not null default '',
   bar_code             nvarchar(20)         not null default '',
   oem_no               nvarchar(30)         not null default '',
   hs_code              nvarchar(20)         not null default '',
   cata_code            nvarchar(20)         not null default '',
   item_desc1           nvarchar(30)         not null default '',
   item_desc2           nvarchar(30)         not null default '',
   item_desce1          nvarchar(30)         not null default '',
   item_desce2          nvarchar(30)         not null default '',
   epurb05              numeric(19,5)        not null default 0,
   epurb06              nvarchar(6)          not null default '',
   epurb07a             numeric(19,5)        not null default 0,
   epurb07b             numeric(19,5)        not null default 0,
   epurb08              numeric(19,5)        not null default 0,
   epurb09              nvarchar(6)          not null default '',
   epurb10a             numeric(19,5)        not null default 0,
   epurb10b             numeric(19,5)        not null default 0,
   epurb17              int                  not null default 0,
   epurb20              numeric(19,5)        not null default 0,
   tax_type             nvarchar(1)          not null default '',
   tax_rate             numeric(9,5)         not null default 0,
   epurb21              numeric(19,5)        not null default 0,
   epurb22              numeric(19,5)        not null default 0,
   epurb23              numeric(19,5)        not null default 0,
   epurb25              numeric(19,5)        not null default 0,
   epurb26              numeric(19,5)        not null default 0,
   epurb27              numeric(19,5)        not null default 0,
   epurb30              nvarchar(6)          not null default '',
   epurb31a             numeric(9,5)         not null default 0,
   epurb31b             numeric(9,5)         not null default 0,
   epurb31c             numeric(9,5)         not null default 0,
   epurb32a             numeric(19,5)        not null default 0,
   epurb32b             nvarchar(6)          not null default '',
   epurb32d             numeric(19,5)        not null default 0,
   epurb32e             numeric(19,5)        not null default 0,
   epurb32c             nvarchar(6)          not null default '',
   epurb32f             numeric(19,5)        not null default 0,
   epurb32g             numeric(19,5)        not null default 0,
   epurb33a             numeric(19,5)        not null default 0,
   epurb33b             nvarchar(6)          not null default '',
   epurb33d             numeric(19,5)        not null default 0,
   epurb33e             numeric(19,5)        not null default 0,
   epurb33c             nvarchar(6)          not null default '',
   epurb33f             numeric(19,5)        not null default 0,
   epurb33g             numeric(19,5)        not null default 0,
   epurb34a             numeric(19,5)        not null default 0,
   epurb34b             nvarchar(6)          not null default '',
   epurb34d             numeric(19,5)        not null default 0,
   epurb34e             numeric(19,5)        not null default 0,
   epurb34c             nvarchar(6)          not null default '',
   epurb34f             numeric(19,5)        not null default 0,
   epurb34g             numeric(19,5)        not null default 0,
   epurb35a             nvarchar(6)          not null default '',
   epurb35b             numeric(19,5)        not null default 0,
   epurb36a             nvarchar(6)          not null default '',
   epurb36b             numeric(19,5)        not null default 0,
   epurb36c             numeric(19,5)        not null default 0,
   epurb55a             nvarchar(2)          not null default '',
   epurb55b             nvarchar(16)         not null default '',
   epurb56              nvarchar(1)          not null default '',
   epurb57a             nvarchar(2)          not null default '',
   epurb57b             nvarchar(16)         not null default '',
   epurb57c             uniqueidentifier     not null,
   epurb60              nvarchar(2)          not null default '',
   epurb61              int                  not null default 0,
   epurb62              int                  not null default 0,
   epurb63              nvarchar(2)          not null default '',
   epurb64              int                  not null default 0,
   epurb65              int                  not null default 0,
   remark               nvarchar(30)         not null default '',
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'epur002', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '全局流水號;全局流水號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurbid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單號;單號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb01b'
go

execute sp_addextendedproperty 'MS_Description', 
   '流水號;流水號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'auto_seq'
go

execute sp_addextendedproperty 'MS_Description', 
   '序號;序號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'num'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品編號;產品編號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品副編號;產品副編號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_sub'
go

execute sp_addextendedproperty 'MS_Description', 
   '類別;類別',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb02'
go

execute sp_addextendedproperty 'MS_Description', 
   '贈配來源流水號;贈配來源流水號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb03'
go

execute sp_addextendedproperty 'MS_Description', 
   '項次;項次',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb04'
go

execute sp_addextendedproperty 'MS_Description', 
   '廠商產品編號;廠商產品編號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'biz_item_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品條碼;產品條碼',
   'schema', 'dbo', 'table', 'epur002', 'column', 'bar_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品自定義碼(OEM);產品自定義碼(OEM)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'oem_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品進口稅則代碼(H.S. Code);產品進口稅則代碼(H.S. Code)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'hs_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '型錄代號;型錄代號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'cata_code'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱1;產品名稱1',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_desc1'
go

execute sp_addextendedproperty 'MS_Description', 
   '產品名稱2;產品名稱2',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_desc2'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱1;英文產品名稱1',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_desce1'
go

execute sp_addextendedproperty 'MS_Description', 
   '英文產品名稱2;英文產品名稱2',
   'schema', 'dbo', 'table', 'epur002', 'column', 'item_desce2'
go

execute sp_addextendedproperty 'MS_Description', 
   '數量;數量',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb05'
go

execute sp_addextendedproperty 'MS_Description', 
   '計量單位;計量單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb06'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分子;單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '單位轉換分母;單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb07b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉換計價單位數量;轉換計價單位數量',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb08'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位;計價單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb09'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分子;計價單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb10a'
go

execute sp_addextendedproperty 'MS_Description', 
   '計價單位轉換分母;計價單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb10b'
go

execute sp_addextendedproperty 'MS_Description', 
   '價格序號;價格序號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb17'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅單價;未稅單價',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb20'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅別;稅別',
   'schema', 'dbo', 'table', 'epur002', 'column', 'tax_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅率;稅率',
   'schema', 'dbo', 'table', 'epur002', 'column', 'tax_rate'
go

execute sp_addextendedproperty 'MS_Description', 
   '稅金;稅金',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb21'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅單價;含稅單價',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb22'
go

execute sp_addextendedproperty 'MS_Description', 
   '代付款項;代付款項',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb23'
go

execute sp_addextendedproperty 'MS_Description', 
   '報關單價;報關單價',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb25'
go

execute sp_addextendedproperty 'MS_Description', 
   '未稅小計;未稅小計',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb26'
go

execute sp_addextendedproperty 'MS_Description', 
   '含稅小計;含稅小計',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb27'
go

execute sp_addextendedproperty 'MS_Description', 
   'Dimension Unit(規格單位);Dimension Unit(規格單位)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb30'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度1(@L);外包裝規格長度1(@L)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb31a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度2(@W);外包裝規格長度2(@W)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb31b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝規格長度3(@H);外包裝規格長度3(@H)',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb31c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝數量;內包裝數量',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32a'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位;內包裝計數單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32b'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分子;內包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32d'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝計數單位轉換分母;內包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32e'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位;內包裝單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32c'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分子;內包裝單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32f'
go

execute sp_addextendedproperty 'MS_Description', 
   '內包裝單位轉換分母;內包裝單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb32g'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝數量;外包裝數量',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33a'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位;外包裝計數單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33b'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分子;外包裝計數單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33d'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝計數單位轉換分母;外包裝計數單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33e'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位;外包裝單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33c'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分子;外包裝單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33f'
go

execute sp_addextendedproperty 'MS_Description', 
   '外包裝單位轉換分母;外包裝單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb33g'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板外包裝數量;棧板外包裝數量',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34a'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位;棧板計數單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34b'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分子;棧板計數單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34d'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板計數單位轉換分母;棧板計數單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34e'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位;棧板單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34c'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分子;棧板單位轉換分子',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34f'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板單位轉換分母;棧板單位轉換分母',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb34g'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t Unit 體積單位;Measm''t Unit 體積單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb35a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Measm''t 外包裝體積;Measm''t 外包裝體積',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb35b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Weight Unit 重量單位;Weight Unit 重量單位',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb36a'
go

execute sp_addextendedproperty 'MS_Description', 
   'N.W. 外包裝凈重;N.W. 外包裝凈重',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb36b'
go

execute sp_addextendedproperty 'MS_Description', 
   'G.W. 外包裝毛重;G.W. 外包裝毛重',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb36c'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單別;相關來源單別',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb55a'
go

execute sp_addextendedproperty 'MS_Description', 
   '相關來源單號;相關來源單號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb55b'
go

execute sp_addextendedproperty 'MS_Description', 
   '交易價格具參考價值否;交易價格具參考價值否',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb56'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉來源單別;拋轉來源單別',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb57a'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉來源單號;拋轉來源單號',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb57b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拋轉來源ID;拋轉來源ID',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb57c'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號Char;箱號Char',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb60'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號From;箱號From',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb61'
go

execute sp_addextendedproperty 'MS_Description', 
   '箱號To;箱號To',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb62'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號Char;棧板號Char',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb63'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號From;棧板號From',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb64'
go

execute sp_addextendedproperty 'MS_Description', 
   '棧板號To;棧板號To',
   'schema', 'dbo', 'table', 'epur002', 'column', 'epurb65'
go

execute sp_addextendedproperty 'MS_Description', 
   '備註;備註',
   'schema', 'dbo', 'table', 'epur002', 'column', 'remark'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'epur002', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'epur002', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'epur002', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'epur002', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'epur002', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'epur002', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'epur002', 'column', 'modify_date'
go

insert into dbo.epur002 (recid, epurbid, epurb01a, epurb01b, auto_seq, num, item_no, item_sub, epurb02, epurb03, epurb04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, epurb05, epurb06, epurb07a, epurb07b, epurb08, epurb09, epurb10a, epurb10b, epurb17, epurb20, tax_type, tax_rate, epurb21, epurb22, epurb23, epurb25, epurb26, epurb27, epurb30, epurb31a, epurb31b, epurb31c, epurb32a, epurb32b, epurb32d, epurb32e, epurb32c, epurb32f, epurb32g, epurb33a, epurb33b, epurb33d, epurb33e, epurb33c, epurb33f, epurb33g, epurb34a, epurb34b, epurb34d, epurb34e, epurb34c, epurb34f, epurb34g, epurb35a, epurb35b, epurb36a, epurb36b, epurb36c, epurb55a, epurb55b, epurb56, epurb57a, epurb57b, epurb57c, epurb60, epurb61, epurb62, epurb63, epurb64, epurb65, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, epurbid, epurb01a, epurb01b, auto_seq, num, item_no, item_sub, epurb02, epurb03, epurb04, biz_item_no, bar_code, oem_no, hs_code, cata_code, item_desc1, item_desc2, item_desce1, item_desce2, epurb05, epurb06, epurb07a, epurb07b, epurb08, epurb09, epurb10a, epurb10b, epurb17, epurb20, tax_type, tax_rate, epurb21, epurb22, epurb23, epurb25, epurb26, epurb27, epurb30, epurb31a, epurb31b, epurb31c, epurb32a, epurb32b, epurb32d, epurb32e, epurb32c, epurb32f, epurb32g, epurb33a, epurb33b, epurb33d, epurb33e, epurb33c, epurb33f, epurb33g, epurb34a, epurb34b, epurb34d, epurb34e, epurb34c, epurb34f, epurb34g, epurb35a, epurb35b, epurb36a, epurb36b, epurb36c, epurb55a, epurb55b, epurb56, epurb57a, epurb57b, epurb57c, epurb60, epurb61, epurb62, epurb63, epurb64, epurb65, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_epur002
go
alter table dbo.epur002
   add constraint PK_EPUR002 primary key nonclustered (epurbid)
      on "PRIMARY"
go
if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_epur002'))
drop table dbo.tmp_epur002
go

/*==============================================================*/
/* Index: idx_epur002_1                                         */
/*==============================================================*/
create unique clustered index idx_epur002_1 on dbo.epur002 (
epurb01a ASC,
epurb01b ASC,
auto_seq ASC
)
on "PRIMARY"
go

/*==============================================================*/
/* Database name:  NewErp                                       */
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     2010-1-6 10:32:05                            */
/*==============================================================*/
alter table dbo.ilce001
   drop constraint PK_ILCE001
go

if exists (select 1
            from  sys.tables
           where  object_id = object_id('dbo.tmp_ilce001'))
drop table dbo.tmp_ilce001
go

execute sp_rename ilce001, tmp_ilce001
go

/*==============================================================*/
/* Table: ilce001                                               */
/*==============================================================*/
create table dbo.ilce001 (
   recid                uniqueidentifier     not null,
   ilcea01a             nvarchar(2)          not null,
   ilcea01b             nvarchar(16)         not null,
   ilcea02              nvarchar(20)         not null default '',
   doc_comp             nvarchar(3)          not null default '',
   ilcea03              datetime             not null default CONVERT(DATETIME,0),
   doc_date             datetime             not null default CONVERT(DATETIME,0),
   biz_type             nvarchar(1)          not null default '',
   biz_no               nvarchar(10)         not null default '',
   doc_staff            nvarchar(10)         not null default '',
   staff_group          nvarchar(10)         not null default '',
   ilcea04              nvarchar(1)          not null default '',
   ilcea05              int                  not null default 0,
   doc_curr             nvarchar(5)          not null default '',
   comp_exrate          numeric(9,5)         not null default 0,
   sys_exrate           numeric(9,5)         not null default 0,
   ilcea06a             nvarchar(1)          not null default '',
   ilcea06b             numeric(9,5)         not null default 0,
   ilcea07a             int                  not null default 0,
   ilcea07b             nvarchar(1)          not null default '',
   ilcea10a             nvarchar(20)         not null default '',
   ilcea10b             nvarchar(80)         not null default '',
   ilcea11              nvarchar(80)         not null default '',
   ilcea12              nvarchar(80)         not null default '',
   ilcea12a             nvarchar(80)         not null default '',
   ilcea13              nvarchar(80)         not null default '',
   ilcea14              nvarchar(80)         not null default '',
   ilcea15              nvarchar(80)         not null default '',
   ilcea16              nvarchar(40)         not null default '',
   ilcea17a             nvarchar(1)          not null default '',
   ilcea17b             nvarchar(10)         not null default '',
   ilcea17c             nvarchar(80)         not null default '',
   ilcea18              nvarchar(80)         not null default '',
   ilcea20a             nvarchar(20)         not null default '',
   ilcea20b             nvarchar(20)         not null default '',
   ilcea20c             nvarchar(20)         not null default '',
   ilcea21a             nvarchar(7)          not null default '',
   ilcea21b             nvarchar(27)         not null default '',
   ilcea22              datetime             not null default CONVERT(DATETIME,0),
   ilcea23              datetime             not null default CONVERT(DATETIME,0),
   ilcea24              datetime             not null default CONVERT(DATETIME,0),
   ilcea25              datetime             not null default CONVERT(DATETIME,0),
   ilcea26              int                  not null default 0,
   ilcea27a             nvarchar(1)          not null default '',
   ilcea27b             nvarchar(1)          not null default '',
   ilcea27c             nvarchar(1)          not null default '',
   ilcea27d             nvarchar(1)          not null default '',
   ilcea28              numeric(19,5)        not null default 0,
   ilcea28a             numeric(19,5)        not null default 0,
   ilcea29              numeric(19,5)        not null default 0,
   ilcea29a             numeric(19,5)        not null default 0,
   ilcea30              numeric(19,5)        not null default 0,
   ilcea30a             numeric(19,5)        not null default 0,
   ilcea31              nvarchar(10)         not null default '',
   ilcea32              nvarchar(10)         not null default '',
   ilcea33a             nvarchar(1)          not null default '',
   ilcea33b             nvarchar(1)          not null default '',
   ilcea33c             nvarchar(10)         not null default '',
   ilcea33d             nvarchar(2)          not null default '',
   ilcea33e             nvarchar(16)         not null default '',
   ilcea35b             int                  not null default 0,
   ilcea35c             int                  not null default 0,
   ilcea36b             int                  not null default 0,
   ilcea36c             int                  not null default 0,
   ilcea37b             int                  not null default 0,
   ilcea37c             int                  not null default 0,
   ilcea38b             int                  not null default 0,
   ilcea38c             int                  not null default 0,
   ilcea39b             int                  not null default 0,
   ilcea39c             int                  not null default 0,
   ilcea40b             int                  not null default 0,
   ilcea40c             int                  not null default 0,
   ilcea41b             int                  not null default 0,
   ilcea41c             int                  not null default 0,
   ilcea42a             nvarchar(20)         not null default '',
   ilcea42b             int                  not null default 0,
   ilcea42c             int                  not null default 0,
   ilcea43a             nvarchar(20)         not null default '',
   ilcea43b             int                  not null default 0,
   ilcea43c             int                  not null default 0,
   ilcea44a             nvarchar(20)         not null default '',
   ilcea44b             int                  not null default 0,
   ilcea44c             int                  not null default 0,
   ilcea45a             nvarchar(20)         not null default '',
   ilcea45b             int                  not null default 0,
   ilcea45c             int                  not null default 0,
   ilcea46a             nvarchar(20)         not null default '',
   ilcea46b             int                  not null default 0,
   ilcea46c             int                  not null default 0,
   last_user            nvarchar(10)         not null default '',
   last_date            datetime             not null default CONVERT(DATETIME,0),
   create_user          nvarchar(10)         not null default '',
   create_date          datetime             not null default CONVERT(DATETIME,0),
   doc_status           nvarchar(1)          not null default '',
   modify_user          nvarchar(10)         not null default '',
   modify_date          datetime             not null default CONVERT(DATETIME,0)
)
on "PRIMARY"
go

execute sp_addextendedproperty 'MS_Description', 
   'Recid;Recid',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'recid'
go

execute sp_addextendedproperty 'MS_Description', 
   '單別;單別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea01a'
go

execute sp_addextendedproperty 'MS_Description', 
   '管理編號;管理編號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea01b'
go

execute sp_addextendedproperty 'MS_Description', 
   'L/C編號;L/C編號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea02'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司別;公司別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'doc_comp'
go

execute sp_addextendedproperty 'MS_Description', 
   '錄入日期;錄入日期',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea03'
go

execute sp_addextendedproperty 'MS_Description', 
   '開狀日期;開狀日期',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'doc_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象別;對象別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'biz_type'
go

execute sp_addextendedproperty 'MS_Description', 
   '對象編號;對象編號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'biz_no'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務員;業務員',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'doc_staff'
go

execute sp_addextendedproperty 'MS_Description', 
   '業務組別;業務組別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'staff_group'
go

execute sp_addextendedproperty 'MS_Description', 
   '付款方式;付款方式',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea04'
go

execute sp_addextendedproperty 'MS_Description', 
   '遠期天數;遠期天數',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea05'
go

execute sp_addextendedproperty 'MS_Description', 
   '幣別;幣別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'doc_curr'
go

execute sp_addextendedproperty 'MS_Description', 
   '公司匯率;公司匯率',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'comp_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '系統匯率;系統匯率',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'sys_exrate'
go

execute sp_addextendedproperty 'MS_Description', 
   '可多出貨;可多出貨',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea06a'
go

execute sp_addextendedproperty 'MS_Description', 
   '多出貨百分數;多出貨百分數',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea06b'
go

execute sp_addextendedproperty 'MS_Description', 
   'doc. date;doc. date',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea07a'
go

execute sp_addextendedproperty 'MS_Description', 
   '無效標記;無效標記',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea07b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Advice No.;Advice No.',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea10a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Advice  Bank X(40)×2;Advice  Bank X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea10b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Issuing Bank X(40)×2;Issuing Bank X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea11'
go

execute sp_addextendedproperty 'MS_Description', 
   'Nego.   Bank X(40)×2;Nego.   Bank X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea12'
go

execute sp_addextendedproperty 'MS_Description', 
   '押匯往來銀行編號;押匯往來銀行編號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea12a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Paying  Bank X(40)×2;Paying  Bank X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea13'
go

execute sp_addextendedproperty 'MS_Description', 
   'Beneficiary  X(40)×2;Beneficiary  X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea14'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipping Co. X(40)×2;Shipping Co. X(40)×2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea15'
go

execute sp_addextendedproperty 'MS_Description', 
   'Appoint Vessel;Appoint Vessel',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea16'
go

execute sp_addextendedproperty 'MS_Description', 
   'forwarder type;forwarder type',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea17a'
go

execute sp_addextendedproperty 'MS_Description', 
   'forwarder no.;forwarder no.',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea17b'
go

execute sp_addextendedproperty 'MS_Description', 
   'forwarder desc.;forwarder desc.',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea17c'
go

execute sp_addextendedproperty 'MS_Description', 
   'form A;form A',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea18'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment from;Shipment from',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea20a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment to;Shipment to',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea20b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Shipment via;Shipment via',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea20c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Code;Price Term Code',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea21a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Price Term Desc;Price Term Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea21b'
go

execute sp_addextendedproperty 'MS_Description', 
   '到期日;到期日',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea22'
go

execute sp_addextendedproperty 'MS_Description', 
   '接收日期;接收日期',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea23'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後出貨日;最後出貨日',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea24'
go

execute sp_addextendedproperty 'MS_Description', 
   'Amend 最後日期;Amend 最後日期',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea25'
go

execute sp_addextendedproperty 'MS_Description', 
   'Amend Accumulate Times;Amend Accumulate Times',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea26'
go

execute sp_addextendedproperty 'MS_Description', 
   '運費支付方式;運費支付方式',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea27a'
go

execute sp_addextendedproperty 'MS_Description', 
   'L/C Transfer Allow;L/C Transfer Allow',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea27b'
go

execute sp_addextendedproperty 'MS_Description', 
   'Transhipment Allow;Transhipment Allow',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea27c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Partial Shipment Allow;Partial Shipment Allow',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea27d'
go

execute sp_addextendedproperty 'MS_Description', 
   'L/C總金額;L/C總金額',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea28'
go

execute sp_addextendedproperty 'MS_Description', 
   'L/C總金額-稅金;L/C總金額-稅金',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea28a'
go

execute sp_addextendedproperty 'MS_Description', 
   '已分配總金額;已分配總金額',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea29'
go

execute sp_addextendedproperty 'MS_Description', 
   '已分配總金額-稅金;已分配總金額-稅金',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea29a'
go

execute sp_addextendedproperty 'MS_Description', 
   '已押匯總金額;已押匯總金額',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea30'
go

execute sp_addextendedproperty 'MS_Description', 
   '已押匯總金額-稅金;已押匯總金額-稅金',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea30a'
go

execute sp_addextendedproperty 'MS_Description', 
   'Consignee No.;Consignee No.',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea31'
go

execute sp_addextendedproperty 'MS_Description', 
   'A/Notify No.;A/Notify No.',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea32'
go

execute sp_addextendedproperty 'MS_Description', 
   '是否轉開L/C;是否轉開L/C',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea33a'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉開對象別;轉開對象別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea33b'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉開對象編號;轉開對象編號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea33c'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉開採購單別;轉開採購單別',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea33d'
go

execute sp_addextendedproperty 'MS_Description', 
   '轉開採購單號;轉開採購單號',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea33e'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Commerical Invoice;原稿份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea35b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Commerical Invoice;拷貝份數 Commerical Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea35c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Customs Invoice;原稿份數 Customs Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea36b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Customs Invoice;拷貝份數 Customs Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea36c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Bill of Lading;原稿份數 Bill of Lading',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea37b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Bill of Lading;拷貝份數 Bill of Lading',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea37c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Packing List;原稿份數 Packing List',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea38b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Packing List;拷貝份數 Packing List',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea38c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Insur. Certificate;原稿份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea39b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Insur. Certificate;拷貝份數 Insur. Certificate',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea39c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Certificate Origin;原稿份數 Certificate Origin',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea40b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Certificate Origin;拷貝份數 Certificate Origin',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea40c'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Consular Invoice;原稿份數 Consular Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea41b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Consular Invoice;拷貝份數 Consular Invoice',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea41c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other1 Desc;Other1 Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea42a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other1;原稿份數 Other1',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea42b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other1;拷貝份數 Other1',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea42c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other2 Desc;Other2 Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea43a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other2;原稿份數 Other2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea43b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other2;拷貝份數 Other2',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea43c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other3 Desc;Other3 Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea44a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other3;原稿份數 Other3',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea44b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other3;拷貝份數 Other3',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea44c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other4 Desc;Other4 Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea45a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other4;原稿份數 Other4',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea45b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other4;拷貝份數 Other4',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea45c'
go

execute sp_addextendedproperty 'MS_Description', 
   'Other5 Desc;Other5 Desc',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea46a'
go

execute sp_addextendedproperty 'MS_Description', 
   '原稿份數 Other5;原稿份數 Other5',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea46b'
go

execute sp_addextendedproperty 'MS_Description', 
   '拷貝份數 Other5;拷貝份數 Other5',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'ilcea46c'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態人;最後更改狀態人',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'last_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後更改狀態日;最後更改狀態日',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'last_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔人;建檔人',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'create_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '建檔日;建檔日',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'create_date'
go

execute sp_addextendedproperty 'MS_Description', 
   '覆核/作廢;覆核/作廢',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'doc_status'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改人;最後修改人',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'modify_user'
go

execute sp_addextendedproperty 'MS_Description', 
   '最後修改日;最後修改日',
   'schema', 'dbo', 'table', 'ilce001', 'column', 'modify_date'
go

insert into dbo.ilce001 (recid, ilcea01a, ilcea01b, ilcea02, doc_comp, ilcea03, doc_date, biz_type, biz_no, doc_staff, staff_group, ilcea04, ilcea05, doc_curr, comp_exrate, sys_exrate, ilcea06a, ilcea06b, ilcea07a, ilcea07b, ilcea10a, ilcea10b, ilcea11, ilcea12, ilcea13, ilcea14, ilcea15, ilcea16, ilcea17a, ilcea17b, ilcea17c, ilcea18, ilcea20a, ilcea20b, ilcea20c, ilcea21a, ilcea21b, ilcea22, ilcea23, ilcea24, ilcea25, ilcea26, ilcea27a, ilcea27b, ilcea27c, ilcea27d, ilcea28, ilcea28a, ilcea29, ilcea29a, ilcea30, ilcea30a, ilcea31, ilcea32, ilcea33a, ilcea33b, ilcea33c, ilcea33d, ilcea33e, ilcea35b, ilcea35c, ilcea36b, ilcea36c, ilcea37b, ilcea37c, ilcea38b, ilcea38c, ilcea39b, ilcea39c, ilcea40b, ilcea40c, ilcea41b, ilcea41c, ilcea42a, ilcea42b, ilcea42c, ilcea43a, ilcea43b, ilcea43c, ilcea44a, ilcea44b, ilcea44c, ilcea45a, ilcea45b, ilcea45c, ilcea46a, ilcea46b, ilcea46c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date)
select recid, ilcea01a, ilcea01b, ilcea02, doc_comp, ilcea03, doc_date, biz_type, biz_no, doc_staff, staff_group, ilcea04, ilcea05, doc_curr, comp_exrate, sys_exrate, ilcea06a, ilcea06b, ilcea07a, ilcea07b, ilcea10a, ilcea10b, ilcea11, ilcea12, ilcea13, ilcea14, ilcea15, ilcea16, ilcea17a, ilcea17b, ilcea17c, ilcea18, ilcea20a, ilcea20b, ilcea20c, ilcea21a, ilcea21b, ilcea22, ilcea23, ilcea24, ilcea25, ilcea26, ilcea27a, ilcea27b, ilcea27c, ilcea27d, ilcea28, ilcea28a, ilcea29, ilcea29a, ilcea30, ilcea30a, ilcea31, ilcea32, ilcea33a, ilcea33b, ilcea33c, ilcea33d, ilcea33e, ilcea35b, ilcea35c, ilcea36b, ilcea36c, ilcea37b, ilcea37c, ilcea38b, ilcea38c, ilcea39b, ilcea39c, ilcea40b, ilcea40c, ilcea41b, ilcea41c, ilcea42a, ilcea42b, ilcea42c, ilcea43a, ilcea43b, ilcea43c, ilcea44a, ilcea44b, ilcea44c, ilcea45a, ilcea45b, ilcea45c, ilcea46a, ilcea46b, ilcea46c, last_user, last_date, create_user, create_date, doc_status, modify_user, modify_date
from dbo.tmp_ilce001
go

alter table dbo.ilce001
   add constraint PK_ILCE001 primary key (ilcea01a, ilcea01b)
      on "PRIMARY"
go
/*==============================================================*/
/* Index: idx_ilce001_1                                         */
/*==============================================================*/
create index idx_ilce001_1 on dbo.ilce001 (
ilcea02 ASC
)
on "PRIMARY"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcit002') and o.name = 'FK_BCIT002_REFERENCE_BCOM001')
alter table dbo.bcit002
   drop constraint FK_BCIT002_REFERENCE_BCOM001
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom003') and o.name = 'FK_BCOM003_REFERENCE_BCOM001')
alter table dbo.bcom003
   drop constraint FK_BCOM003_REFERENCE_BCOM001
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom009') and o.name = 'FK_BCOM009_REFERENCE_BCOM001')
alter table dbo.bcom009
   drop constraint FK_BCOM009_REFERENCE_BCOM001
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom012') and o.name = 'FK_BCOM012_REFERENCE_BCOM001')
alter table dbo.bcom012
   drop constraint FK_BCOM012_REFERENCE_BCOM001
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom013') and o.name = 'FK_BCOM013_REFERENCE_BCOM001')
alter table dbo.bcom013
   drop constraint FK_BCOM013_REFERENCE_BCOM001
go
if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bcom014') and o.name = 'FK_BCOM014_REFERENCE_BCOM001')
alter table dbo.bcom014
   drop constraint FK_BCOM014_REFERENCE_BCOM001
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('dbo.bitm009') and o.name = 'FK_BITM009_REFERENCE_BITE004')
alter table dbo.bitm009
   drop constraint FK_BITM009_REFERENCE_BITE004
go

alter table dbo.bitm009
   add constraint FK_BITM009_REFERENCE_BITE004 foreign key (item_sub)
      references dbo.bite004 (item_sub)
	on delete cascade
go

