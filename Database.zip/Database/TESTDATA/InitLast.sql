exec [usp_CreateSysRoleUser] ''
GO

--exec [usp_GetExtendProperty]
--GO

